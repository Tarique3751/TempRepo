export class AuthenticationStub {
    getBearerToken () {
        return 'test_token';
    }
}
