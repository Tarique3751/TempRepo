import { HovereffectDirective } from './hovereffect.directive';

// This is the auto generated test file for hovereffect directive
describe('HovereffectDirective', () => {
  it('should create an instance', () => {
    //const directive = new HovereffectDirective();
    //expect(directive).toBeTruthy();
  });
});
