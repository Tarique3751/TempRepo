import { TestBed } from '@angular/core/testing';
import { NotesService } from '../src/app/services/notes.service';
import { AuthenticationService } from '../src/app/services/authentication.service';
import { AuthenticationStub } from './authentication-stub';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Note } from '../src/app/note';

/* Unit test for notes service
author JeffinJude
*/

// Jasmine is the unit testing framework and karma is used to automatically run the unit tests in a chrome browser

// In describe we define the test suite. If describe is appended with f then only that test suite will run,
// if appended with x then except that all other will run.
describe('NotesService', () => {
    let service: NotesService;
    let httpMock: HttpTestingController;

    // Prepare our mock dummy data
    const dummyNote = new Note();
    dummyNote.id = 1;
    dummyNote.title = 'Dummy Title';
    dummyNote.text = 'Dummy Text';
    dummyNote.state = 'Dummy State';
    const dummyNoteArr = new Array<Note>();
    dummyNoteArr.push(dummyNote);

    // Executes before each test case
    beforeEach(() => {
        // In test bed we  specify the services and imported required to test the note service
        TestBed.configureTestingModule({
            // We injecta stub class for AuthenticationService. So where ever AuthenticationService is used stub class is called
            providers: [NotesService, { provide: AuthenticationService, useClass: AuthenticationStub }],
            imports: [HttpClientTestingModule]
        });

        // An instance of NotesService is injected befote each test case, so we can call NotesService methods inside them
        service = TestBed.get(NotesService);
        httpMock = TestBed.get(HttpTestingController);

        // This intercepts the api call in fetchNotesFromServer method called from notes service constructor
        const request = httpMock.expectOne({
            url: 'http://localhost:3000/api/v1/notes',
            method: 'GET'
        });
    });

    it('should be created', () => {
        expect(service).toBeTruthy(); // Check if service is getting injected
    });

    it('fetchNotesFromServer should be making the right api call and updates the notes subject', () => {
        // Testing the fetchNotesFromServer method
        service.fetchNotesFromServer();

        // This intercepts the api call in fetchNotesFromServer method
        const request = httpMock.expectOne({
            url: 'http://localhost:3000/api/v1/notes',
            method: 'GET'
        });

        // Return dummyNoteArr as response for the above call
        request.flush(dummyNoteArr);

        service.getNotes().subscribe(notes => {
            // Assert the response of the subscribe method to equal the dummy notes array
            expect(notes).toEqual(dummyNoteArr);
        });
    });

    it('addNotes should be calling the right api with right params and also update the notes subject', () => {
        const dummyNote2 = new Note();
        dummyNote2.id = 2;
        dummyNote2.title = 'Dummy Title2';
        dummyNote2.text = 'Dummy Text2';
        dummyNote2.state = 'Dummy State2';
        const dummyNoteArr2 = new Array<Note>();
        dummyNoteArr2.push(dummyNote2);

        // Testing the addNote method
        service.addNote(dummyNote2).subscribe(note => {
            expect(note).toEqual(dummyNote2);
        });

        // Intercept and mock the api calls
        const postRequest = httpMock.expectOne({
            url: 'http://localhost:3000/api/v1/notes',
            method: 'POST'
        });

        // Return the mock response
        postRequest.flush(dummyNote2);

        // Check whether the note object is being passed through the request body
        expect(postRequest.request.body).toEqual(dummyNote2);

        // After note is added check whether notes subject is updated by calling the get notes method
        service.getNotes().subscribe(notes => {
            expect(notes).toEqual(dummyNoteArr2);
        });
    });

    afterEach(() => {
        // To check whether any http calls are not handled. If not handled the test suite will fail
        httpMock.verify();
    });
});
