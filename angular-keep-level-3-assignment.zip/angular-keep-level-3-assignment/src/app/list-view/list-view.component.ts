import { Component, OnInit } from '@angular/core';
import { Note } from '../note';
import { AuthenticationService } from '../services/authentication.service';
import { NotesService } from '../services/notes.service';

@Component({
  selector: 'app-list-view',
  templateUrl: './list-view.component.html',
  styleUrls: ['./list-view.component.css']
})
export class ListViewComponent implements OnInit {

  notStartedNotes: Array<Note>;
  startedNotes: Array<Note>;
  completedNotes: Array<Note>;

  errMessage: string;
  public note: Note;
  notes: Array<Note>;

  constructor(public authService: AuthenticationService, public noteService: NotesService) {
    this.note = new Note();
    this.notes = [];
    this.notStartedNotes = [];
    this.startedNotes = [];
    this.completedNotes = [];
  }

  ngOnInit() {
    this.noteService.getNotes().subscribe(
      data => {
        this.notes = data;
        this.notStartedNotes = [];
        this.startedNotes = [];
        this.completedNotes = [];
        for (const note of this.notes) {
          if (note.state === 'not-started') {
            this.notStartedNotes.push(note);
          } else if (note.state === 'started') {
            this.startedNotes.push(note);
          } else if (note.state === 'completed') {
            this.completedNotes.push(note);
          }
        }
      },
      err => this.errMessage = err.message
    );
  }
}
