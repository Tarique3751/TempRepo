import { Component, OnInit, ViewChild } from '@angular/core';
import { Note } from '../note';
import { FormGroup, FormGroupDirective, FormBuilder, Validators, FormControl } from '@angular/forms';
import { AuthenticationService } from '../services/authentication.service';
import { NotesService } from '../services/notes.service';

@Component({
  selector: 'app-note-taker',
  templateUrl: './note-taker.component.html',
  styleUrls: ['./note-taker.component.css']
})

export class NoteTakerComponent implements OnInit {
  errMessage: string;
  public note: Note;
  public notes: Note[];

  constructor(public authService: AuthenticationService, public noteService: NotesService) {
    this.note = new Note();
    this.notes = [];
  }

  ngOnInit() {

  }

  addNote() {
    const noteObj: Note = new Note();
    noteObj.title = this.note.title;
    noteObj.text = this.note.text;
    noteObj.state = 'not-started';

    if (this.note.text !== '' && this.note.text !== '') {
      this.errMessage = '';

      this.notes.push(noteObj);
      this.noteService.addNote(noteObj).subscribe(
        data => {
        },
        err => this.errMessage = err.message
      );

      this.note.title = '';
      this.note.text = '';
    } else {
      this.errMessage = 'Title and Text both are required fields';
    }
  }
}
