import { Component, OnInit } from '@angular/core';
import { RouterService } from '../services/router.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  isNoteView = true;

  constructor(public routerService: RouterService, private router: Router) {
  }

  ngOnInit(): void {
  }

  openListView() {
    this.isNoteView = false;
    this.routerService.routeToListView();
  }

  openNoteView() {
    this.isNoteView = true;
    this.routerService.routeToNoteView();
  }
}
