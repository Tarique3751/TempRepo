import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, FormGroupDirective, FormBuilder, Validators } from '@angular/forms';
import { LoginUser } from '../loginUser';
import { AuthenticationService } from '../services/authentication.service';
import { RouterService } from '../services/router.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username = new FormControl();
  password = new FormControl();

  public loginUser: LoginUser;
  public loginForm: FormGroup;
  public submitMessage: string;
  private bearerToken: string;
  public isAuthenticated: boolean;

  @ViewChild(FormGroupDirective)
  formGroupDirective: FormGroupDirective;

  constructor(public routerService: RouterService, public authService: AuthenticationService, public formBuilder: FormBuilder) {
    this.loginUser = new LoginUser();

    this.loginForm = formBuilder.group({
      username: ['', Validators.compose([Validators.required])],
      password: ['', Validators.compose([Validators.required])]
    });
  }

  ngOnInit() {
    this.bearerToken = this.authService.getBearerToken();
    this.authService.isUserAuthenticated(this.bearerToken).then(
      (res) => {
        this.isAuthenticated = res;
        if (this.isAuthenticated) {
          this.routerService.routeToDashboard();
        } else {
          this.routerService.routeToLogin();
        }
      }
    ).catch(function (err) {
      if (err.status === 403) {
        this.submitMessage = 'Unauthorized';
      } else {
        this.submitMessage = err.message;
      }
    });
  }

  loginSubmit(loginForm?: FormGroup) {
    if (loginForm !== undefined) {
      if (!loginForm.invalid) {
        this.loginUser = loginForm.value;

        this.authService.authenticateUser(this.loginUser).subscribe(
          res => {
            this.authService.setBearerToken(res['token']);
            this.routerService.routeToDashboard();
          },
          err => {
            if (err.status === 403) {
              this.submitMessage = 'Unauthorized';
            } else {
              this.submitMessage = err.message;
            }
          }
        );
        this.loginForm.reset();
        this.formGroupDirective.resetForm();
      }
    } else {
      if (this.username.valid && this.password.valid) {
        this.loginUser.username = this.username.value;
        this.loginUser.password = this.password.value;
        this.authService.authenticateUser(this.loginUser).subscribe(
          res => {
            this.authService.setBearerToken(res['token']);
            this.routerService.routeToDashboard();
          },
          err => {
            if (err.status === 403) {
              this.submitMessage = 'Unauthorized';
            } else {
              this.submitMessage = err.message;
            }
          }
        );
        this.formGroupDirective.resetForm();
      }
    }
  }
}
