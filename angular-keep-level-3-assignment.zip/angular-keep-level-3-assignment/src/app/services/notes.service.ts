import { Injectable } from '@angular/core';
import { Note } from '../note';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { AuthenticationService } from './authentication.service';
import { tap } from 'rxjs/operators';

@Injectable()
export class NotesService {

  notes: Array<Note>;
  notesSubject: BehaviorSubject<Array<Note>>;
  private token: string;

  constructor(private httpClient: HttpClient, public authService: AuthenticationService) {
    this.token = this.authService.getBearerToken();
    this.notesSubject = new BehaviorSubject([]);
    this.fetchNotesFromServer();
  }

  fetchNotesFromServer() {
    this.token = this.authService.getBearerToken();

    return this.httpClient.get<Note[]>('http://localhost:3000/api/v1/notes', {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.token}`)
    }).subscribe(notes => {
      this.notes = notes;
      this.notesSubject.next(this.notes);
    },
    err => {
      return err.message;
    }
    );
  }

  getNotes(): BehaviorSubject<Array<Note>> {
    return this.notesSubject;
  }

  addNote(note: Note): Observable<Note> {
    this.token = this.authService.getBearerToken();
    return this.httpClient.post<Note>('http://localhost:3000/api/v1/notes', note, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.token}`)
    }).pipe(
      tap(addedNote => {
        this.notes.push(addedNote);
        this.notesSubject.next(this.notes);
      })
    );
  }

  editNote(note: Note): Observable<Note> {
    this.token = this.authService.getBearerToken();
    return this.httpClient.put<Note>(`http://localhost:3000/api/v1/notes/${note.id}`, note, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.token}`)
    }).pipe(
      tap(editNote => {
        const noteObj = this.notes.find(noteObject => noteObject.id === editNote.id);
        Object.assign(noteObj, editNote);
        this.notesSubject.next(this.notes);
      })
    );
  }

  getNoteById(noteId): Note {
    const foundNote = this.notes.find(note => note.id == noteId);
    return foundNote;
  }
}
