import { Component, OnInit, Inject } from '@angular/core';
import { Note } from '../note';
import { NotesService } from '../services/notes.service';

@Component({
  selector: 'app-list-view',
  templateUrl: './list-view.component.html',
  styleUrls: ['./list-view.component.css']
})
export class ListViewComponent implements OnInit {

  notStartedNotes: Array<Note> = [];
  startedNotes: Array<Note> = [];
  completedNotes: Array<Note> = [];
  notes: Array<Note> = [];
  errMessage: String = '';
  constructor(@Inject(NotesService) private notesSer: NotesService) { }

  ngOnInit() {
    this.notesSer.getNotes().subscribe(
      data => {
        this.notes = data;
        this.notStartedNotes = this.notes.filter(note => note.state === 'not-started');
        this.startedNotes = this.notes.filter(note => note.state === 'started');
        this.completedNotes = this.notes.filter(note => note.state === 'completed');
      },
      err => {
        this.errMessage = err.message;
      }
    );

  }

}
