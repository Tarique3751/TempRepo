import { Component, Inject } from '@angular/core';
import { FormControl, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AuthenticationService } from '../services/authentication.service';
import { RouterService } from '../services/router.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username = new FormControl('', Validators.required);
  password = new FormControl('', [Validators.minLength(4), Validators.required]);
  submitMessage = '';

  constructor(@Inject(AuthenticationService) private authSer: AuthenticationService,
    @Inject(RouterService) private route: RouterService) { }
  loginForm = new FormGroup(
    {
      'username': this.username,
      'password': this.password
    }
  );

  loginSubmit() {
    this.authSer.authenticateUser(this.loginForm.value).subscribe(
      data => {
        this.authSer.setBearerToken(data['token']);
        this.route.routeToDashboard();
      }
      , err => {
        this.submitMessage = err.status === 404 ? err.message : err.error.message;
      }
    );
  }

  get userName() {
    return this.loginForm.get('username');
  }

  get pass() {
    return this.loginForm.get('password');
  }

  getUserNameErrorMessage() {
    return this.userName.hasError('required') ? 'userName cannot be left blank' : '';
  }

  getPasswordErrorMessage() {
    return this.pass.hasError('required') ? 'Password cannot be left blank' : '';
  }
  getPasswordLengthErrorMessage() {
    return this.password.hasError('minLength') ? 'Password must contain atleast 4 characters' : '';
  }
}
