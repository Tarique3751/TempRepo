import { Injectable, Inject } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Note } from '../note';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from './authentication.service';

import { BehaviorSubject } from 'rxjs';

@Injectable()
export class NotesService {

  notes: Array<Note>;
  noteSubject: BehaviorSubject<Array<Note>>;

  constructor(@Inject(HttpClient) private httpClient: HttpClient,
    @Inject(AuthenticationService) private authSer: AuthenticationService) {
    this.notes = [];
    this.noteSubject = new BehaviorSubject(this.notes);
    this.fetchNotesFromServer();
  }

  fetchNotesFromServer() {
    return this.httpClient.get<Array<Note>>('http://localhost:3000/api/v1/notes', {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authSer.getBearerToken()}`)
    }).subscribe(notes => {
      this.notes = notes;
      this.noteSubject.next(this.notes);
    }
    , err => {
      return err.message;
    });
  }

  getNotes(): Observable<Array<Note>> {
    return this.noteSubject;
  }

  addNote(note: Note): Observable<Note> {
    return this.httpClient.post<Note>('http://localhost:3000/api/v1/notes', note, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authSer.getBearerToken()}`)
    }).do(newNote => {
      this.notes.push(newNote);
      this.noteSubject.next(this.notes);
    });
  }

  getNoteById(noteId) {
    const noteById = this.notes.find(note => note.id === noteId);
    return Object.assign({}, noteById);
  }

  editNote(noteEdited): Observable<Note> {
    console.log(`editNote : ${noteEdited.id} token : Bearer ${this.authSer.getBearerToken()}`);
    return this.httpClient.put<Note>(`http://localhost:3000/api/v1/notes/${noteEdited.id}`, noteEdited, {
      headers: new HttpHeaders().set('Authorization', `Bearer ${this.authSer.getBearerToken()}`)
    }).do(editNote => {
      const noteExist = this.notes.find(note => note.id === editNote.id);
      Object.assign(noteExist, editNote);
      this.noteSubject.next(this.notes);
    });
  }
}
