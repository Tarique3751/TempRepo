import { Injectable, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';

@Injectable()
export class RouterService {

  constructor(@Inject(Router) private routes: Router, private location: Location) { }

  routeToDashboard() {
    this.routes.navigate(['dashboard']);
  }
  routeToLogin() {
    this.routes.navigate(['login']);
  }
  routeToEditNoteView(noteId) {
    this.routes.navigate([
      'dashboard', {
        outlets: {
          noteEditOutlet: ['note', noteId, 'edit']
        }
      }
    ]);
  }
  routeBack() {
    this.location.back();
  }
  routeToNoteView() {
    this.routes.navigate(['view/noteview']);
  }
  routeToListView() {
    this.routes.navigate(['view/listview']);
  }
}
