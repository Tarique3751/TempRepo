import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Rx';

@Injectable()
export class AuthenticationService {
  token = '';
  constructor(@Inject(HttpClient) private httpClient: HttpClient) { }

  authenticateUser(data) {
    return this.httpClient.post('http://localhost:3000/auth/v1/', data);
  }

  setBearerToken(token) {
    localStorage.setItem('token', token);
  }

  getBearerToken() {
    return localStorage.getItem('token');
  }

  isUserAuthenticated(token): Promise<boolean> {

    const obsr: Observable<any> = this.httpClient.post('http://localhost:3000/auth/v1/isAuthenticated', {}, {
      headers: new HttpHeaders()
        .set('Authorization', `Bearer ${token}`)
    });
    console.log(obsr);
    return obsr.map(response => {
      return response['isAuthenticated'];
    }).toPromise();
  }
}
