import { Component, Inject, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NotesService } from '../services/notes.service';
import { Note } from '../note';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  notes: Note[] = [];
  errMessage: string;

  constructor(@Inject(NotesService) private notesSer: NotesService) {
    this.notesSer.fetchNotesFromServer();
  }
  ngOnInit() {
  }

}
