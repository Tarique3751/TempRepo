import { Component, OnInit, Inject } from '@angular/core';
import { NotesService } from '../services/notes.service';
import { Note } from '../note';

@Component({
  selector: 'app-note-taker',
  templateUrl: './note-taker.component.html',
  styleUrls: ['./note-taker.component.css']
})
export class NoteTakerComponent implements OnInit {
  note: Note = new Note();
  notes: Note[] = [];
  errMessage: string;
  constructor(@Inject(NotesService) private notesSer: NotesService) { }

  ngOnInit() {
  }
  takeNotes(event) {
    this.note.text === ''
      ? (this.errMessage = 'Title and Text both are required fields')
      : (this.errMessage = '');
    this.note.title === ''
      ? (this.errMessage = 'Title and Text both are required fields')
      : (this.errMessage = '');
    this.notes.push(this.note);
    this.notesSer.addNote(this.note).subscribe(
      data => { },
      err => {
        this.errMessage = err.message;
        const noteIndex = this.notes.findIndex(
          note => note.title === this.note.title
        );
        this.notes.splice(noteIndex, 1);
      }
    );
  }
}
