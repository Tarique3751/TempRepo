import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { NotesService } from '../services/notes.service';
import { Note } from '../note';
@Component({
  selector: 'app-edit-note-view',
  templateUrl: './edit-note-view.component.html',
  styleUrls: ['./edit-note-view.component.css']
})
export class EditNoteViewComponent implements OnInit {
  errMessage = '';
  note: Note = new Note();
  constructor(private dialogref: MatDialogRef<EditNoteViewComponent>, private noteser: NotesService
    , @Inject(MAT_DIALOG_DATA) private data: any) { }

  ngOnInit() {
    this.note = this.noteser.getNoteById(this.data.noteId);
  }

  editNote() {
    this.noteser.editNote(this.note).subscribe(editNote => {
      this.dialogref.close();
    }
    , err => {
      this.errMessage = err.message;
    }
    );
  }
}
