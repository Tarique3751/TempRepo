export class Note {
    id: number;
    text: string;
    state: string;
    title: string;
   // constructor(public title: string, public text: string, public state: string = 'not-started' ) { }
   constructor() {
       this.text = '';
       this.title = '';
       this.state = 'not-started';
   }
}
