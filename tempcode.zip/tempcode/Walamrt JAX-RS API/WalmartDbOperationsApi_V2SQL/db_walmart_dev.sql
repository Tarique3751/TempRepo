-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2016 at 04:22 AM
-- Server version: 5.7.9
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_walmart_dev`
--

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `get_walmart_details_data`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_walmart_details_data` ()  BEGIN

--   Author      : Jeffin Jude
--   Create date : 19-may-16
--   Description : Fetch data from walmart_order_details
  
    SELECT * FROM walmart_order_details wod
	INNER JOIN walmart_order_header woh ON woh.WalmartOrderHdId = wod.WalmartOrderHdId
	WHERE woh.ImportStatus = 44 AND woh.AutomaticImportStatus = 1;
END$$

DROP PROCEDURE IF EXISTS `get_walmart_header_data`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_walmart_header_data` ()  BEGIN

--   Author      : Jeffin Jude
--   Create date : 19-may-16
--   Description : Fetch data from walmart_order_header
  
    SELECT * FROM walmart_order_header WHERE ImportStatus = 44 AND AutomaticImportStatus = 1;
END$$

DROP PROCEDURE IF EXISTS `usp_order_data_normalization_for_walmart`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_order_data_normalization_for_walmart` ()  BEGIN

--   Author      : Shijo K Prakash
--   Create date : 10-may-16 12:01:44
--   Description : normalizing order data for walmart
  
    CREATE TEMPORARY TABLE IF NOT EXISTS tempOrder( 
          WalmartRowNumber VARCHAR(100)			            
          ) engine=memory;
    
	 TRUNCATE TABLE tempOrder;
	 UPDATE walmart_temp w SET w.RowNumber = UUID();     
          
  	 SET @num := 0, @group_id := '';
	 INSERT INTO tempOrder(WalmartRowNumber)
    SELECT RowNumber FROM (
    SELECT w.RowNumber, @num := if(@group_id = concat(w.OrderNumber,w.SKU), @num + 1, 1) as row_number,
      @group_id := concat(w.OrderNumber,w.SKU) as dummy 
		FROM walmart_temp w
      order by w.OrderNumber,w.SKU
    ) AS T
    WHERE T.row_number < 2; 
	     	   
    DELETE wl FROM  walmart_temp wl 
	 WHERE wl.RowNumber NOT IN (SELECT WalmartRowNumber FROM tempOrder);
	 
	 SELECT * FROM tempOrder;         

  	INSERT INTO walmart_order_header(PoNumber,OrderNumber,ShipBy,CustomerName,CustomerShippingInfo,ImportStatus,
	        AutomaticImportStatus,AutomaticImportErrorDetails,CreatedDate,UpdatedDate,CreatedBy,UpdatedBy)  
     SELECT wl.PoNumber,wl.OrderNumber,wl.ShipBy,wl.CustomerName,wl.CustomerShippingInfo,0,
           1,'',UTC_TIMESTAMP(),UTC_TIMESTAMP(),'',''
           FROM walmart_temp wl
			  ON DUPLICATE KEY UPDATE 
			     PoNumber       			=    wl.PoNumber,
	           OrderNumber          	=    wl.OrderNumber,
	           ShipBy           		=    wl.ShipBy,
	           CustomerName       	=    wl.CustomerName,
	           CustomerShippingInfo	=    wl.CustomerShippingInfo,
	           AutomaticImportStatus	=    1,
	           UpdatedDate          	=    UTC_TIMESTAMP();
			  
				  
	 DELETE od FROM  walmart_order_details od INNER JOIN walmart_temp wl ON od.OrderNumber = wl.OrderNumber;         
	                    
	 INSERT INTO walmart_order_details(WalmartOrderHdId,OrderNumber,LineNumber,UPC,Status,ItemDescription,RequestedCarrierMethod,
	        RequestedShippingMethod,Qty,SKU,UpdateStatus,UpdateQty,ActualCarrierMethodUsed,UpdateShippingMethod,
	        TrackingNumber,TrackingUrl,CreatedDate,UpdatedDate,CreatedBy,UpdatedBy)  
    SELECT oh.WalmartOrderHdId,wl.OrderNumber,wl.LineNumber,wl.UPC,wl.Status,wl.ItemDescription,
           wl.RequestedCarrierMethod,wl.RequestedShippingMethod,wl.Qty,wl.SKU,wl.UpdateStatus,wl.UpdateQty,wl.ActualCarrierMethodUsed,wl.UpdateShippingMethod,
           wl.TrackingNumber,wl.TrackingUrl,UTC_TIMESTAMP(),UTC_TIMESTAMP(),'',''
           FROM walmart_temp wl INNER JOIN walmart_order_header oh ON wl.OrderNumber = oh.OrderNumber;
   
	  DELETE FROM walmart_temp; 	
	  DROP TEMPORARY TABLE IF EXISTS tempOrder;
END$$

DROP PROCEDURE IF EXISTS `usp_order_data_normalization_for_walmart_test`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_order_data_normalization_for_walmart_test` ()  BEGIN
INSERT into walmart_order_header(PoNumber)values("test");

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `walmart_order_details`
--

DROP TABLE IF EXISTS `walmart_order_details`;
CREATE TABLE IF NOT EXISTS `walmart_order_details` (
  `WalmartOrderDtId` int(11) NOT NULL AUTO_INCREMENT,
  `WalmartOrderHdId` int(11) DEFAULT NULL,
  `OrderNumber` varchar(50) DEFAULT NULL,
  `LineNumber` int(11) DEFAULT NULL,
  `UPC` varchar(50) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  `ItemDescription` varchar(250) DEFAULT NULL,
  `RequestedCarrierMethod` varchar(250) DEFAULT NULL,
  `RequestedShippingMethod` varchar(250) DEFAULT NULL,
  `Qty` int(11) DEFAULT NULL,
  `SKU` varchar(50) DEFAULT NULL,
  `UpdateStatus` varchar(50) DEFAULT NULL,
  `UpdateQty` varchar(50) DEFAULT NULL,
  `ActualCarrierMethodUsed` varchar(50) DEFAULT NULL,
  `UpdateShippingMethod` varchar(50) DEFAULT NULL,
  `TrackingNumber` varchar(50) DEFAULT NULL,
  `TrackingUrl` varchar(50) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `UpdatedDate` datetime DEFAULT NULL,
  `CreatedBy` datetime DEFAULT NULL,
  `UpdatedBy` datetime DEFAULT NULL,
  PRIMARY KEY (`WalmartOrderDtId`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `walmart_order_details`
--

INSERT INTO `walmart_order_details` (`WalmartOrderDtId`, `WalmartOrderHdId`, `OrderNumber`, `LineNumber`, `UPC`, `Status`, `ItemDescription`, `RequestedCarrierMethod`, `RequestedShippingMethod`, `Qty`, `SKU`, `UpdateStatus`, `UpdateQty`, `ActualCarrierMethodUsed`, `UpdateShippingMethod`, `TrackingNumber`, `TrackingUrl`, `CreatedDate`, `UpdatedDate`, `CreatedBy`, `UpdatedBy`) VALUES
(54, 27, 'string', 0, 'string', 'string', 'string', 'string', 'string', 0, 'string', 'string', 'string', 'string', 'string', 'string', 'string', '2016-05-20 11:51:14', '2016-05-20 11:51:14', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(55, 28, 'string', 0, 'string', 'string', 'string', 'string', 'string', 0, 'string', 'string', 'string', 'string', 'string', 'string', 'string', '2016-05-20 11:51:14', '2016-05-20 11:51:14', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(56, 29, 'string', 0, 'string', 'string', 'string', 'string', 'string', 0, 'string', 'string', 'string', 'string', 'string', 'string', 'string', '2016-05-20 11:51:14', '2016-05-20 11:51:14', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `walmart_order_header`
--

DROP TABLE IF EXISTS `walmart_order_header`;
CREATE TABLE IF NOT EXISTS `walmart_order_header` (
  `WalmartOrderHdId` int(11) NOT NULL AUTO_INCREMENT,
  `PoNumber` varchar(50) DEFAULT NULL,
  `OrderNumber` varchar(50) DEFAULT NULL,
  `ShipBy` varchar(50) DEFAULT NULL,
  `CustomerName` varchar(50) DEFAULT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `CustomerShippingInfo` varchar(50) DEFAULT NULL,
  `ImportStatus` int(11) DEFAULT NULL,
  `AutomaticImportStatus` int(11) DEFAULT NULL,
  `AutomaticImportErrorDetails` varchar(50) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `UpdatedDate` datetime DEFAULT NULL,
  `CreatedBy` varchar(50) DEFAULT NULL,
  `UpdatedBy` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`WalmartOrderHdId`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `walmart_order_header`
--

INSERT INTO `walmart_order_header` (`WalmartOrderHdId`, `PoNumber`, `OrderNumber`, `ShipBy`, `CustomerName`, `FirstName`, `LastName`, `CustomerShippingInfo`, `ImportStatus`, `AutomaticImportStatus`, `AutomaticImportErrorDetails`, `CreatedDate`, `UpdatedDate`, `CreatedBy`, `UpdatedBy`) VALUES
(27, 'string', 'string', 'string', 'string', NULL, NULL, 'string', 0, 1, '', '2016-05-20 11:51:13', '2016-05-20 11:51:13', '', ''),
(28, 'string', 'string', 'string', 'string', NULL, NULL, 'string', 0, 1, '', '2016-05-20 11:51:14', '2016-05-20 11:51:14', '', ''),
(29, 'string', 'string', 'string', 'string', NULL, NULL, 'string', 0, 1, '', '2016-05-20 11:51:14', '2016-05-20 11:51:14', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `walmart_temp`
--

DROP TABLE IF EXISTS `walmart_temp`;
CREATE TABLE IF NOT EXISTS `walmart_temp` (
  `PoNumber` varchar(255) DEFAULT NULL,
  `OrderNumber` varchar(255) DEFAULT NULL,
  `ShipBy` varchar(255) DEFAULT NULL,
  `CustomerName` varchar(255) DEFAULT NULL,
  `CustomerShippingInfo` varchar(255) DEFAULT NULL,
  `LineNumber` varchar(255) DEFAULT NULL,
  `UPC` varchar(255) DEFAULT NULL,
  `Status` varchar(255) DEFAULT NULL,
  `ItemDescription` varchar(255) DEFAULT NULL,
  `RequestedCarrierMethod` varchar(255) DEFAULT NULL,
  `RequestedShippingMethod` varchar(255) DEFAULT NULL,
  `Qty` varchar(255) DEFAULT NULL,
  `SKU` varchar(255) DEFAULT NULL,
  `UpdateStatus` varchar(255) DEFAULT NULL,
  `UpdateQty` varchar(255) DEFAULT NULL,
  `ActualCarrierMethodUsed` varchar(255) DEFAULT NULL,
  `UpdateShippingMethod` varchar(255) DEFAULT NULL,
  `TrackingNumber` varchar(255) DEFAULT NULL,
  `TrackingUrl` varchar(255) DEFAULT NULL,
  `RowNumber` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
