=========================================
  	Walmart Db Operations API V1
=========================================

-----------------------------------------
	Setup Instructions
-----------------------------------------
1) Import the project into eclipse workspace (File->Import->Existing Projects Into Workspace.).
2) Ensure that apache tomacat working directory is set to the projects workspace
	2.1)Eclipse -> Run -> Run Configurations -> Tomacat Server -> Arguments -> Working Directory
3) Configure the mysql database settings in hibernate.cfg.xml (src/main/java).
4) Set the AppDir variable in AppConfigurations.java(src/main/java/org/cto/walmart/dbops/AppConfigurations.java). Configure the app configs in AppConfig.properties file (src/main/resources/AppConfig.properties).
5) Configure base_url variable in index.html (src/main/webapp/index.html).
6) Ensure that all dependencies in pom.xml are resolved.
7) Right click -> Run As -> Run On Server (Use Apache Tomcat).

-----------------------------------------
	Functionalities
-----------------------------------------
1)Api to performs Db operations on walmart table using Hibernate.

-----------------------------------------
	Changelog
-----------------------------------------
#V1
- Performs insertion of POST json data into walmart_temp table.
- Performs order data normalization for walmart by calling sp 'usp_order_data_normalization_for_walmart'.
- Added basic authentication for api

#V2
- Integrating Swagger UI.
- Added log file generation
- Added junit test cases

-----------------------------------------
	Dependency Jar files required
-----------------------------------------
.m2\repository\org\glassfish\jersey\containers\jersey-container-servlet-core\2.22.2\jersey-container-servlet-core-2.22.2.jar
.m2\repository\org\glassfish\hk2\external\javax.inject\2.4.0-b34\javax.inject-2.4.0-b34.jar
.m2\repository\org\glassfish\jersey\core\jersey-common\2.22.2\jersey-common-2.22.2.jar
.m2\repository\javax\annotation\javax.annotation-api\1.2\javax.annotation-api-1.2.jar
.m2\repository\org\glassfish\jersey\bundles\repackaged\jersey-guava\2.22.2\jersey-guava-2.22.2.jar
.m2\repository\org\glassfish\hk2\hk2-api\2.4.0-b34\hk2-api-2.4.0-b34.jar
.m2\repository\org\glassfish\hk2\hk2-utils\2.4.0-b34\hk2-utils-2.4.0-b34.jar
.m2\repository\org\glassfish\hk2\external\aopalliance-repackaged\2.4.0-b34\aopalliance-repackaged-2.4.0-b34.jar
.m2\repository\org\glassfish\hk2\hk2-locator\2.4.0-b34\hk2-locator-2.4.0-b34.jar
.m2\repository\org\glassfish\hk2\osgi-resource-locator\1.0.1\osgi-resource-locator-1.0.1.jar
.m2\repository\org\glassfish\jersey\core\jersey-server\2.22.2\jersey-server-2.22.2.jar
.m2\repository\org\glassfish\jersey\core\jersey-client\2.22.2\jersey-client-2.22.2.jar
.m2\repository\org\glassfish\jersey\media\jersey-media-jaxb\2.22.2\jersey-media-jaxb-2.22.2.jar
.m2\repository\javax\validation\validation-api\1.1.0.Final\validation-api-1.1.0.Final.jar
.m2\repository\javax\ws\rs\javax.ws.rs-api\2.0.1\javax.ws.rs-api-2.0.1.jar
.m2\repository\org\glassfish\jersey\media\jersey-media-moxy\2.22.2\jersey-media-moxy-2.22.2.jar
.m2\repository\org\glassfish\jersey\ext\jersey-entity-filtering\2.22.2\jersey-entity-filtering-2.22.2.jar
.m2\repository\org\eclipse\persistence\org.eclipse.persistence.moxy\2.6.0\org.eclipse.persistence.moxy-2.6.0.jar
.m2\repository\org\eclipse\persistence\org.eclipse.persistence.core\2.6.0\org.eclipse.persistence.core-2.6.0.jar
.m2\repository\org\eclipse\persistence\org.eclipse.persistence.asm\2.6.0\org.eclipse.persistence.asm-2.6.0.jar
.m2\repository\org\glassfish\javax.json\1.0.4\javax.json-1.0.4.jar
.m2\repository\javax\servlet\servlet-api\2.5\servlet-api-2.5.jar
.m2\repository\org\hibernate\hibernate-java8\5.1.0.Final\hibernate-java8-5.1.0.Final.jar
.m2\repository\org\jboss\logging\jboss-logging\3.3.0.Final\jboss-logging-3.3.0.Final.jar
.m2\repository\org\hibernate\hibernate-core\5.1.0.Final\hibernate-core-5.1.0.Final.jar
.m2\repository\antlr\antlr\2.7.7\antlr-2.7.7.jar
.m2\repository\org\jboss\jandex\2.0.0.Final\jandex-2.0.0.Final.jar
.m2\repository\com\fasterxml\classmate\1.3.0\classmate-1.3.0.jar
.m2\repository\org\hibernate\hibernate-entitymanager\5.1.0.Final\hibernate-entitymanager-5.1.0.Final.jar
.m2\repository\dom4j\dom4j\1.6.1\dom4j-1.6.1.jar
.m2\repository\xml-apis\xml-apis\1.0.b2\xml-apis-1.0.b2.jar
.m2\repository\org\hibernate\common\hibernate-commons-annotations\5.0.1.Final\hibernate-commons-annotations-5.0.1.Final.jar
.m2\repository\org\hibernate\javax\persistence\hibernate-jpa-2.1-api\1.0.0.Final\hibernate-jpa-2.1-api-1.0.0.Final.jar
.m2\repository\org\javassist\javassist\3.20.0-GA\javassist-3.20.0-GA.jar
.m2\repository\org\apache\geronimo\specs\geronimo-jta_1.1_spec\1.1.1\geronimo-jta_1.1_spec-1.1.1.jar
.m2\repository\org\hibernate\hibernate-jpamodelgen\5.1.0.Final\hibernate-jpamodelgen-5.1.0.Final.jar
.m2\repository\commons-lang\commons-lang\2.6\commons-lang-2.6.jar
.m2\repository\com\fasterxml\jackson\core\jackson-annotations\2.7.4\jackson-annotations-2.7.4.jar
.m2\repository\org\json\json\20090211\json-20090211.jar
.m2\repository\io\swagger\swagger-jersey2-jaxrs\1.5.0\swagger-jersey2-jaxrs-1.5.0.jar
.m2\repository\io\swagger\swagger-jaxrs\1.5.0\swagger-jaxrs-1.5.0.jar
.m2\repository\com\fasterxml\jackson\dataformat\jackson-dataformat-yaml\2.4.2\jackson-dataformat-yaml-2.4.2.jar
.m2\repository\com\fasterxml\jackson\core\jackson-core\2.4.2\jackson-core-2.4.2.jar
.m2\repository\com\fasterxml\jackson\dataformat\jackson-dataformat-xml\2.4.2\jackson-dataformat-xml-2.4.2.jar
.m2\repository\com\fasterxml\jackson\core\jackson-databind\2.4.2\jackson-databind-2.4.2.jar
.m2\repository\com\fasterxml\jackson\module\jackson-module-jaxb-annotations\2.4.2\jackson-module-jaxb-annotations-2.4.2.jar
.m2\repository\org\codehaus\woodstox\stax2-api\3.1.4\stax2-api-3.1.4.jar
.m2\repository\io\swagger\swagger-core\1.5.0\swagger-core-1.5.0.jar
.m2\repository\org\apache\commons\commons-lang3\3.2.1\commons-lang3-3.2.1.jar
.m2\repository\org\slf4j\slf4j-api\1.6.3\slf4j-api-1.6.3.jar
.m2\repository\com\fasterxml\jackson\datatype\jackson-datatype-joda\2.4.2\jackson-datatype-joda-2.4.2.jar
.m2\repository\joda-time\joda-time\2.2\joda-time-2.2.jar
.m2\repository\io\swagger\swagger-models\1.5.0\swagger-models-1.5.0.jar
.m2\repository\io\swagger\swagger-annotations\1.5.0\swagger-annotations-1.5.0.jar
.m2\repository\org\reflections\reflections\0.9.9\reflections-0.9.9.jar
.m2\repository\com\google\guava\guava\15.0\guava-15.0.jar
.m2\repository\com\google\code\findbugs\annotations\2.0.1\annotations-2.0.1.jar
.m2\repository\com\fasterxml\jackson\jaxrs\jackson-jaxrs-json-provider\2.4.2\jackson-jaxrs-json-provider-2.4.2.jar
.m2\repository\com\fasterxml\jackson\jaxrs\jackson-jaxrs-base\2.4.2\jackson-jaxrs-base-2.4.2.jar
.m2\repository\org\glassfish\jersey\media\jersey-media-multipart\2.22.2\jersey-media-multipart-2.22.2.jar
.m2\repository\org\jvnet\mimepull\mimepull\1.9.6\mimepull-1.9.6.jar
.m2\repository\junit\junit\4.11\junit-4.11.jar
.m2\repository\org\hamcrest\hamcrest-core\1.3\hamcrest-core-1.3.jar