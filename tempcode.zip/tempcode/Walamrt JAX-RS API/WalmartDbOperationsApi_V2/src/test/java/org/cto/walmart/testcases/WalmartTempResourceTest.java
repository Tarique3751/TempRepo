package org.cto.walmart.testcases;

import static org.junit.Assert.*;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Response;
import org.cto.walmart.dbops.AppConfigurations;
import org.junit.BeforeClass;
import org.junit.Test;

public class WalmartTempResourceTest {
	
	public static String ApiBasePath;
	
	@BeforeClass
    public static void oneTimeSetUp() {
        // one-time initialization code
		
		//'System.getProperty("user.dir")' returns the root of project directory when running junit. So 'AppDir' variable must not be appended, hence set it as null.
		AppConfigurations.AppDir = "";
		AppConfigurations.ReadConfiguration();
		ApiBasePath = AppConfigurations.ApiBasePath;
    }

	//Junit test to verify that api provides 200 response on providing valid credentials
	@Test
	public void ValidCredentialsAuthenticationTest() {
		String input = "{\r\n  \"orders\": [\r\n    {\r\n      \"id\": 0,\r\n      \"PO#\": \"string\",\r\n      \"Order#\": \"string\",\r\n      \"Ship By\": \"string\",\r\n      \"Customer Name\": \"string\",\r\n      \"Customer Shipping Info\": \"string\",\r\n      \"Line#\": \"string\",\r\n      \"UPC\": \"string\",\r\n      \"Status\": \"string\",\r\n      \"Item Description\": \"string\",\r\n      \"Requested Carrier Method\": \"string\",\r\n      \"Requested Shipping Method\": \"string\",\r\n      \"Qty\": \"string\",\r\n      \"SKU\": \"string\",\r\n      \"Update Status\": \"string\",\r\n      \"Update Qty\": \"string\",\r\n      \"Actual Carrier Method Used\": \"string\",\r\n      \"Update Shipping Method\": \"string\",\r\n      \"Tracking Number\": \"string\",\r\n      \"Tracking Url\": \"string\"\r\n    }\r\n  ]\r\n}";
		
		//Define valid basic authentication credential values
        String username = "user";
        String password = "password_test";
        String usernameAndPassword = username + ":" + password;
        String authorizationHeaderName = "Authorization";
        String authorizationHeaderValue = "Basic " + java.util.Base64.getEncoder().encodeToString( usernameAndPassword.getBytes() );

        // Perform a post request
        String restResource = ApiBasePath;
        Client client = ClientBuilder.newClient();
        Response res = client.target( restResource )
            .path( "WalmartTempResource" ) // API Module Path
            .request( "text/plain" ) // Expected response mime type
            .header( authorizationHeaderName, authorizationHeaderValue ) // The basic authentication header goes here
            .post( Entity.text(input) ); // Perform a post with the form values
        assertTrue( res.getStatus() == 200 );
	}
	
	//Junit test to verify that api provides 401 response on providing invalid credentials
	@Test
	public void InValidCredentialsAuthenticationTest() {
		String input = "{\r\n  \"orders\": [\r\n    {\r\n      \"id\": 0,\r\n      \"PO#\": \"string\",\r\n      \"Order#\": \"string\",\r\n      \"Ship By\": \"string\",\r\n      \"Customer Name\": \"string\",\r\n      \"Customer Shipping Info\": \"string\",\r\n      \"Line#\": \"string\",\r\n      \"UPC\": \"string\",\r\n      \"Status\": \"string\",\r\n      \"Item Description\": \"string\",\r\n      \"Requested Carrier Method\": \"string\",\r\n      \"Requested Shipping Method\": \"string\",\r\n      \"Qty\": \"string\",\r\n      \"SKU\": \"string\",\r\n      \"Update Status\": \"string\",\r\n      \"Update Qty\": \"string\",\r\n      \"Actual Carrier Method Used\": \"string\",\r\n      \"Update Shipping Method\": \"string\",\r\n      \"Tracking Number\": \"string\",\r\n      \"Tracking Url\": \"string\"\r\n    }\r\n  ]\r\n}";
		
		//Define invalid basic authentication credential values
        String username = "user";
        String password = "invalid_password";
        String usernameAndPassword = username + ":" + password;
        String authorizationHeaderName = "Authorization";
        String authorizationHeaderValue = "Basic " + java.util.Base64.getEncoder().encodeToString( usernameAndPassword.getBytes() );

        // Perform a post request
        String restResource = ApiBasePath;
        Client client = ClientBuilder.newClient();
        Response res = client.target( restResource )
            .path( "WalmartTempResource" ) // API Module Path
            .request( "text/plain" ) // Expected response mime type
            .header( authorizationHeaderName, authorizationHeaderValue ) // The basic authentication header goes here
            .post( Entity.text(input) ); // Perform a post with the form values
        assertTrue( res.getStatus() == 401 );
	}
	
	//Junit test to verify that api provides 200 response on providing valid json input
	@Test
	public void ValidJsonInputTest() {
		//Valid Json input
		String input = "{\r\n  \"orders\": [\r\n    {\r\n      \"id\": 0,\r\n      \"PO#\": \"string\",\r\n      \"Order#\": \"string\",\r\n      \"Ship By\": \"string\",\r\n      \"Customer Name\": \"string\",\r\n      \"Customer Shipping Info\": \"string\",\r\n      \"Line#\": \"string\",\r\n      \"UPC\": \"string\",\r\n      \"Status\": \"string\",\r\n      \"Item Description\": \"string\",\r\n      \"Requested Carrier Method\": \"string\",\r\n      \"Requested Shipping Method\": \"string\",\r\n      \"Qty\": \"string\",\r\n      \"SKU\": \"string\",\r\n      \"Update Status\": \"string\",\r\n      \"Update Qty\": \"string\",\r\n      \"Actual Carrier Method Used\": \"string\",\r\n      \"Update Shipping Method\": \"string\",\r\n      \"Tracking Number\": \"string\",\r\n      \"Tracking Url\": \"string\"\r\n    }\r\n  ]\r\n}";
		
		//Define valid basic authentication credential values
        String username = "user";
        String password = "password_test";
        String usernameAndPassword = username + ":" + password;
        String authorizationHeaderName = "Authorization";
        String authorizationHeaderValue = "Basic " + java.util.Base64.getEncoder().encodeToString( usernameAndPassword.getBytes() );

        // Perform a post request
        String restResource = ApiBasePath;
        Client client = ClientBuilder.newClient();
        Response res = client.target( restResource )
            .path( "WalmartTempResource" ) // API Module Path
            .request( "text/plain" ) // Expected response mime type
            .header( authorizationHeaderName, authorizationHeaderValue ) // The basic authentication header goes here
            .post( Entity.text(input) ); // Perform a post with the form values
        assertTrue( res.getStatus() == 200 );
	}
	
	//Junit test to verify that api provides 400 response on providing invalid json input
	@Test
	public void InValidJsonInputTest() {
		//Invalid json input
		String input = "invalid json input";
		
		//Define valid basic authentication credential values
        String username = "user";
        String password = "password_test";
        String usernameAndPassword = username + ":" + password;
        String authorizationHeaderName = "Authorization";
        String authorizationHeaderValue = "Basic " + java.util.Base64.getEncoder().encodeToString( usernameAndPassword.getBytes() );

        // Perform a post request
        String restResource = ApiBasePath;
        Client client = ClientBuilder.newClient();
        Response res = client.target( restResource )
            .path( "WalmartTempResource" ) // API Module Path
            .request( "text/plain" ) // Expected response mime type
            .header( authorizationHeaderName, authorizationHeaderValue ) // The basic authentication header goes here
            .post( Entity.text(input) ); // Perform a post with the form values
        assertTrue( res.getStatus() == 400 );
	}
	
	//Junit test to verify that api parses and insert into database on providing valid json input
	@Test
	public void DbInsertionTest() {
		//Valid json input
		String input = "{\r\n  \"orders\": [\r\n    {\r\n      \"id\": 0,\r\n      \"PO#\": \"string\",\r\n      \"Order#\": \"string\",\r\n      \"Ship By\": \"string\",\r\n      \"Customer Name\": \"string\",\r\n      \"Customer Shipping Info\": \"string\",\r\n      \"Line#\": \"string\",\r\n      \"UPC\": \"string\",\r\n      \"Status\": \"string\",\r\n      \"Item Description\": \"string\",\r\n      \"Requested Carrier Method\": \"string\",\r\n      \"Requested Shipping Method\": \"string\",\r\n      \"Qty\": \"string\",\r\n      \"SKU\": \"string\",\r\n      \"Update Status\": \"string\",\r\n      \"Update Qty\": \"string\",\r\n      \"Actual Carrier Method Used\": \"string\",\r\n      \"Update Shipping Method\": \"string\",\r\n      \"Tracking Number\": \"string\",\r\n      \"Tracking Url\": \"string\"\r\n    }\r\n  ]\r\n}";
		
		//Define valid basic authentication credential values
		String username = "user";
		String password = "password_test";
		String usernameAndPassword = username + ":" + password;
		String authorizationHeaderName = "Authorization";
		String authorizationHeaderValue = "Basic " + java.util.Base64.getEncoder().encodeToString( usernameAndPassword.getBytes() );
		
		// Perform a post request
		String restResource = ApiBasePath;
		Client client = ClientBuilder.newClient();
		Response res = client.target( restResource )
		    .path( "WalmartTempResource" ) // API Module Path
		    .request( "text/plain" ) // Expected response mime type
		    .header( authorizationHeaderName, authorizationHeaderValue ) // The basic authentication header goes here
		    .post( Entity.text(input) ); // Perform a post with the form values
	   String ResponseString = res.readEntity(String.class);
	   ResponseString = ResponseString.replaceFirst("Inserted walmart_temp Record Id(s) : ", ""); //Extract the inserted records primary column values from the response string
	   String[] InsertedRecords = ResponseString.split(",");
	   assertEquals(1,InsertedRecords.length); //Check whether 1 record has been inserted in Db
	}
}
