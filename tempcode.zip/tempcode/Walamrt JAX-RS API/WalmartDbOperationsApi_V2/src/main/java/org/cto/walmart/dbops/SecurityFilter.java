/*
 * This is the JAX-RS filter to implement authentication for api.
 */
package org.cto.walmart.dbops;

import java.io.IOException;
import java.util.List;
import java.util.StringTokenizer;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;
import org.glassfish.jersey.internal.util.Base64;

@Provider
public class SecurityFilter implements ContainerRequestFilter{
	private static final String AUTHORIZATION_HEADER_KEY = "Authorization"; 
	private static final String AUTHORIZATION_HEADER_PREFIX = "Basic ";
	private static final String SECURED_URL_PREFIX = "WalmartTempResource";
	
	@Override
	public void filter(ContainerRequestContext requestContext) throws IOException {
		//Read the app config values.
		AppConfigurations.ReadConfiguration();
		
		if (requestContext.getUriInfo().getPath().contains(SECURED_URL_PREFIX)) //Secure all the api requests that access 'WalmartTempResource' 
		{
			List<String> authHeader = requestContext.getHeaders().get(AUTHORIZATION_HEADER_KEY);
			if (authHeader != null && authHeader.size() > 0) 
			{
				String authToken = authHeader.get(0);
				authToken = authToken.replaceFirst(AUTHORIZATION_HEADER_PREFIX, "");
				if(!authToken.equals("") && !authToken.equals("Basic"))
				{
					String decodedString = Base64.decodeAsString(authToken);
					if(!decodedString.equals(":"))
					{
						try
						{
							StringTokenizer tokenizer = new StringTokenizer(decodedString, ":");
							String username = tokenizer.nextToken();
							String password = tokenizer.nextToken();
							if (AppConfigurations.UserName.equals(username) && AppConfigurations.Password.equals(password)) //If username and password is correct the allow access to api resource
							{
								return;
							}
						}
						catch(Exception e)
						{
							//Invalid AUTHORIZATION HEADER
						}
					}
				}
			}
			//If username and password is not correct abort with 401:UNAUTHORIZED
			Response unauthorizedStatus = Response
								            .status(Response.Status.UNAUTHORIZED)
								            .entity("Unauthorized Access. Please provide correct api credentials.")
								            .build();
					
			requestContext.abortWith(unauthorizedStatus);
		}
		
	}
}
