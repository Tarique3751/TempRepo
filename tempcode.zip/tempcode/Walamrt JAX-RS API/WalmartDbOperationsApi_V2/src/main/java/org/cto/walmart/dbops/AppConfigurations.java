package org.cto.walmart.dbops;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class AppConfigurations {
	public static Properties prop = new Properties();
	/*Set this variable so that config properties file can be fetched correctly. 
	'System.getProperty("user.dir")' returns the root of tomcat directory. So 'AppDir' variable must be appended to point to the project directory.
	*/
	public static String AppDir = "/WalmartDbOperationsApi_V2";
	public static String AppName;
	public static String UserName;
	public static String Password;
	public static String ApiBasePath;
	
	public static void ReadConfiguration()
	{
		//Reading configurations details from config file.
		try
		{
			prop.load(new FileInputStream(System.getProperty("user.dir") + AppDir + "/src/main/resources/AppConfig.properties"));
		}
		catch(IOException e)
		{
			System.out.println("Exception :" + e);
		}
		//Setting the app config variables
		AppName = prop.getProperty("AppName");
		UserName = prop.getProperty("UserName");
		Password = prop.getProperty("Password");
		ApiBasePath = prop.getProperty("ApiBasePath");
	}
}
