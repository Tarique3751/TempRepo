package org.cto.walmart.dto;

import java.util.ArrayList;
import javax.persistence.Embedded;

public class Orders {
	@Embedded
	private ArrayList<WalmartTemp> orders;

	public ArrayList<WalmartTemp> getOrders() {
		return orders;
	}

	public void setOrders(ArrayList<WalmartTemp> orders) {
		this.orders = orders;
	}
}
