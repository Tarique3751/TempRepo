/*
 * Data Transfer Object for the table 'walmart_temp' 
 * 
 */
package org.cto.walmart.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@NamedNativeQueries({
	@NamedNativeQuery(
	name = "CallUspOrderDataNormalizationForWalmart",
	query = "CALL usp_order_data_normalization_for_walmart_test",//Test SP.Need to change this to normalisation SP. 
	resultClass = WalmartTemp.class
	)
})
@Entity
@XmlRootElement(name="orders")
@Table(name = "walmart_temp")
@ApiModel(value = "WalmartTemp")
@Embeddable
public class WalmartTemp {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column(name = "PoNumber")
	@XmlElement(name = "PO#")
	@ApiModelProperty(name = "PO#", required = true)
	private String poNumber;
	@Column(name = "OrderNumber")
	@XmlElement(name = "Order#")
	@ApiModelProperty(name = "Order#", required = true)
	private String orderNumber;
	@Column(name = "ShipBy")
	@XmlElement(name = "Ship By")
	@ApiModelProperty(name = "Ship By", required = true)
	private String shipBy;
	@Column(name = "CustomerName")
	@XmlElement(name = "Customer Name")
	@ApiModelProperty(name = "Customer Name", required = true)
	private String customerName;
	@Column(name = "CustomerShippingInfo")
	@XmlElement(name = "Customer Shipping Info")
	@ApiModelProperty(name = "Customer Shipping Info", required = true)
	private String customerShippingInfo;
	@Column(name = "LineNumber")
	@XmlElement(name = "Line#")
	@ApiModelProperty(name = "Line#", required = true)
	private String lineNumber;
	@Column(name = "UPC")
	@XmlElement(name = "UPC")
	@ApiModelProperty(name = "UPC", required = true)
	private String uPC;
	@Column(name = "Status")
	@XmlElement(name = "Status")
	@ApiModelProperty(name = "Status", required = true)
	private String status;
	@Column(name = "ItemDescription")
	@XmlElement(name = "Item Description")
	@ApiModelProperty(name = "Item Description", required = true)
	private String itemDescription;
	@Column(name = "RequestedCarrierMethod")
	@XmlElement(name = "Requested Carrier Method")
	@ApiModelProperty(name = "Requested Carrier Method", required = true)
	private String requestedCarrierMethod;
	@Column(name = "RequestedShippingMethod")
	@XmlElement(name = "Requested Shipping Method")
	@ApiModelProperty(name = "Requested Shipping Method", required = true)
	private String requestedShippingMethod;
	@Column(name = "Qty")
	@XmlElement(name = "Qty")
	@ApiModelProperty(name = "Qty", required = true)
	private String qty;
	@Column(name = "SKU")
	@XmlElement(name = "SKU")
	@ApiModelProperty(name = "SKU", required = true)
	private String sKU;
	@Column(name = "UpdateStatus")
	@XmlElement(name = "Update Status")
	@ApiModelProperty(name = "Update Status", required = true)
	private String updateStatus;
	@Column(name = "UpdateQty")
	@XmlElement(name = "Update Qty")
	@ApiModelProperty(name = "Update Qty", required = true)
	private String updateQty;
	@Column(name = "ActualCarrierMethodUsed")
	@XmlElement(name = "Actual Carrier Method Used")
	@ApiModelProperty(name = "Actual Carrier Method Used", required = true)
	private String actualCarrierMethodUsed;
	@Column(name = "UpdateShippingMethod")
	@XmlElement(name = "Update Shipping Method")
	@ApiModelProperty(name = "Update Shipping Method", required = true)
	private String updateShippingMethod;
	@Column(name = "TrackingNumber")
	@XmlElement(name = "Tracking Number")
	@ApiModelProperty(name = "Tracking Number", required = true)
	private String trackingNumber;
	@Column(name = "TrackingUrl")
	@XmlElement(name = "Tracking Url")
	@ApiModelProperty(name = "Tracking Url", required = true)
	private String trackingUrl;
	
	//Constructors
	public WalmartTemp()
	{
		
	}
	public WalmartTemp(String poNumber, String orderNumber, String shipBy, String customerName, String customerShippingInfo, String lineNumber, String uPC, String status, String itemDescription, String requestedCarrierMethod, String requestedShippingMethod, String qty, String sKU, String updateStatus, String updateQty, String actualCarrierMethodUsed, String updateShippingMethod, String trackingNumber, String trackingUrl) {
    	this.poNumber = poNumber;
    	this.orderNumber = orderNumber;
    	this.shipBy = shipBy;
    	this.customerName = customerName;
    	this.customerShippingInfo = customerShippingInfo;
    	this.lineNumber = lineNumber;
    	this.uPC = uPC;
    	this.status = status;
    	this.itemDescription = itemDescription;
    	this.requestedCarrierMethod = requestedCarrierMethod;
    	this.requestedShippingMethod = requestedShippingMethod;
    	this.qty = qty;
    	this.sKU = sKU;
    	this.updateStatus = updateStatus;
    	this.updateQty = updateQty;
    	this.actualCarrierMethodUsed = actualCarrierMethodUsed;
    	this.updateShippingMethod = updateShippingMethod;
    	this.trackingNumber = trackingNumber;
    	this.trackingUrl = trackingUrl;
    }
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getShipBy() {
		return shipBy;
	}
	public void setShipBy(String shipBy) {
		this.shipBy = shipBy;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerShippingInfo() {
		return customerShippingInfo;
	}
	public void setCustomerShippingInfo(String customerShippingInfo) {
		this.customerShippingInfo = customerShippingInfo;
	}
	public String getLineNumber() {
		return lineNumber;
	}
	public void setLineNumber(String lineNumber) {
		this.lineNumber = lineNumber;
	}
	public String getuPC() {
		return uPC;
	}
	public void setuPC(String uPC) {
		this.uPC = uPC;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	public String getRequestedCarrierMethod() {
		return requestedCarrierMethod;
	}
	public void setRequestedCarrierMethod(String requestedCarrierMethod) {
		this.requestedCarrierMethod = requestedCarrierMethod;
	}
	public String getRequestedShippingMethod() {
		return requestedShippingMethod;
	}
	public void setRequestedShippingMethod(String requestedShippingMethod) {
		this.requestedShippingMethod = requestedShippingMethod;
	}
	public String getQty() {
		return qty;
	}
	public void setQty(String qty) {
		this.qty = qty;
	}
	public String getsKU() {
		return sKU;
	}
	public void setsKU(String sKU) {
		this.sKU = sKU;
	}
	public String getUpdateStatus() {
		return updateStatus;
	}
	public void setUpdateStatus(String updateStatus) {
		this.updateStatus = updateStatus;
	}
	public String getUpdateQty() {
		return updateQty;
	}
	public void setUpdateQty(String updateQty) {
		this.updateQty = updateQty;
	}
	public String getActualCarrierMethodUsed() {
		return actualCarrierMethodUsed;
	}
	public void setActualCarrierMethodUsed(String actualCarrierMethodUsed) {
		this.actualCarrierMethodUsed = actualCarrierMethodUsed;
	}
	public String getUpdateShippingMethod() {
		return updateShippingMethod;
	}
	public void setUpdateShippingMethod(String updateShippingMethod) {
		this.updateShippingMethod = updateShippingMethod;
	}
	public String getTrackingNumber() {
		return trackingNumber;
	}
	public void setTrackingNumber(String trackingNumber) {
		this.trackingNumber = trackingNumber;
	}
	public String getTrackingUrl() {
		return trackingUrl;
	}
	public void setTrackingUrl(String trackingUrl) {
		this.trackingUrl = trackingUrl;
	}
}
