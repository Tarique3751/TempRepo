/*
 * This class performs CRUD operations on walmart_temp table
 */
package org.cto.walmart.services;

import org.hibernate.Query;
import org.hibernate.Session;
import org.cto.walmart.dbops.HibernateManager;
import org.cto.walmart.dto.WalmartTemp;

public class WalmartTempServices {
	
	public static String PONum;
	public static String OrderNum;
	public static String ShipBy;
	public static String CustomerName;
	public static String CustomerShippingInfo;
	public static String LineNum;
	public static String UPC;
	public static String Status;
	public static String ItemDescription;
	public static String RequestedCarrierMethod;
	public static String RequestedShippingMethod;
	public static String Qty;
	public static String SKU;
	public static String UpdateStatus;
	public static String UpdateQty;
	public static String ActualCarrierMethodUsed;
	public static String UpdateShippingMethod;
	public static String TrackingNumber;
	public static String TrackingUrl;
	
	public int InsertWalmartDetailsToDb(WalmartTemp WalmartTempObj) // Perform insert operations in walmart_temp table
	{
		WalmartTemp WalmartTempInsert = new WalmartTemp();
		WalmartTempInsert.setPoNumber(WalmartTempObj.getPoNumber());
		WalmartTempInsert.setOrderNumber(WalmartTempObj.getOrderNumber());
		WalmartTempInsert.setShipBy(WalmartTempObj.getShipBy());
		WalmartTempInsert.setCustomerName(WalmartTempObj.getCustomerName());
		WalmartTempInsert.setCustomerShippingInfo(WalmartTempObj.getCustomerShippingInfo());
		WalmartTempInsert.setLineNumber(WalmartTempObj.getLineNumber());
		WalmartTempInsert.setuPC(WalmartTempObj.getuPC());
		WalmartTempInsert.setStatus(WalmartTempObj.getStatus());
		WalmartTempInsert.setItemDescription(WalmartTempObj.getItemDescription());
		WalmartTempInsert.setRequestedCarrierMethod(WalmartTempObj.getRequestedCarrierMethod());
		WalmartTempInsert.setRequestedShippingMethod(WalmartTempObj.getRequestedShippingMethod());
		WalmartTempInsert.setQty(WalmartTempObj.getQty());
		WalmartTempInsert.setsKU(WalmartTempObj.getsKU());
		WalmartTempInsert.setUpdateStatus(WalmartTempObj.getUpdateStatus());
		WalmartTempInsert.setUpdateQty(WalmartTempObj.getUpdateQty());
		WalmartTempInsert.setActualCarrierMethodUsed(WalmartTempObj.getActualCarrierMethodUsed());
		WalmartTempInsert.setUpdateShippingMethod(WalmartTempObj.getUpdateShippingMethod());
		WalmartTempInsert.setTrackingNumber(WalmartTempObj.getTrackingNumber());
		WalmartTempInsert.setTrackingUrl(WalmartTempObj.getTrackingUrl());
		
		int WalmartId = 0;
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();		
		session.save(WalmartTempInsert);
		session.flush();
		WalmartId = WalmartTempInsert.getId();
		try
		{
			session.getTransaction().commit();
		}
		catch(Exception e)
		{
			session.getTransaction().rollback();
		}
		session.close();
		return WalmartId;
	}
	
	public void NormalizeWalmartOrderData()
	{
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		Query NormalizeWalmartOrderDataQry = session.getNamedQuery("CallUspOrderDataNormalizationForWalmart");
		NormalizeWalmartOrderDataQry.executeUpdate();
		session.close();
	}
	
}
