package org.cto.walmart.dbops;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class HibernateManager // Hibernate utility class
{  
	private static final SessionFactory sessionFactory;
	  
	static 
	{//create sessionFactory object only once    
		try
		{          
			sessionFactory = new Configuration().configure().buildSessionFactory();
		} 
		catch (Throwable ex) 
		{
			System.out.println("JDBC Connection error. Please ensure that Mysql is running and restart the application.");
		    throw new ExceptionInInitializerError(ex);
		}
	}
	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}
} 