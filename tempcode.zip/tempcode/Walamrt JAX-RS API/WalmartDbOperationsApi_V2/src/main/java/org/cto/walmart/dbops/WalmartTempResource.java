/*
 * This class handles the GET,POST,PUT and Delete requests for walmart_temp table
 */
package org.cto.walmart.dbops;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ApiResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.cto.walmart.dto.Orders;
import org.cto.walmart.dto.WalmartTemp;
import org.cto.walmart.services.WalmartTempServices;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Path("WalmartTempResource")
@Api(value = "WalmartTempResource")
public class WalmartTempResource {
	Logger logger = Logger.getLogger("AppLogs");  
    FileHandler fh;
    public static String NewLineChar = System.getProperty("line.separator");
	WalmartTempServices WalmartTempServicesObj = new WalmartTempServices();
	/*
	 * This method handles the POST method of API
	 * Sample API Call : http://192.168.1.151:8080/WalmartDbOperationsApi_V2/WebApi/WalmartTempResource
	 * Headers
	 * --------
	 * Content-Type : text/plain
	 * 
	 * Body
	 * ----
	 * {
			"orders" : [
				{
				"PO#":"XXXXXXXXXX",
				"Order#":"XXXXXXXXX",
				"Ship By":"2016-05-05T03:49:14.887Z",
				"Customer Name":"ABC",
				"Customer Shipping Info":"ABCD",
				"Line#":"1",
				"UPC":"YYYYYYYYYYY",
				"Status":"ORDERED",
				"Item Description":"XXXXXXXXXXXXXXXXXXXXXXX",
				"Requested Carrier Method":"2 - (Value) UPS Ground - DSV",
				"Requested Shipping Method":"STANDARD",
				"Qty":"1",
				"SKU":"ABCD",
				"Update Status":"",
				"Update Qty":"",
				"Actual Carrier Method Used":"",
				"Update Shipping Method":"",
				"Tracking Number":"",
				"Tracking Url":""
				},
				{
				"PO#":"XXXXXXXXXX2",
				"Order#":"XXXXXXXXX",
				"Ship By":"2016-05-05T03:49:14.887Z",
				"Customer Name":"ABC",
				"Customer Shipping Info":"ABCD",
				"Line#":"1",
				"UPC":"YYYYYYYYYYY",
				"Status":"ORDERED",
				"Item Description":"XXXXXXXXXXXXXXXXXXXXXXX",
				"Requested Carrier Method":"2 - (Value) UPS Ground - DSV",
				"Requested Shipping Method":"STANDARD",
				"Qty":"1",
				"SKU":"ABCD",
				"Update Status":"",
				"Update Qty":"",
				"Actual Carrier Method Used":"",
				"Update Shipping Method":"",
				"Tracking Number":"",
				"Tracking Url":""
				}
			]
		}
	 * 
	 */
	@POST
    @Consumes(MediaType.TEXT_PLAIN)
    @Produces(MediaType.TEXT_PLAIN)
	@ApiOperation(value = "Insert walmart details",
			notes = "Provide the api input as json string in valid format. The data in the json string is parsed and inserted into walmart_temp table. After insertion into walmart_temp table normalization is done.",
			response = Orders.class
			)
	@ApiResponses(value = {
	        @ApiResponse(code = HttpURLConnection.HTTP_OK, message = "Success. Returns the IDs of inserted records",response = Orders.class),
	        @ApiResponse(code = HttpURLConnection.HTTP_UNAUTHORIZED, message = "Unauthorized Access"),
	        @ApiResponse(code = HttpURLConnection.HTTP_BAD_REQUEST, message = "Invalid Json"),
	        @ApiResponse(code = HttpURLConnection.HTTP_NOT_FOUND, message = "Not found"),
	        @ApiResponse(code = HttpURLConnection.HTTP_INTERNAL_ERROR, message = "Internal server problems")
	})
    public Response insertWalmartTemp(@ApiParam(value = "Json string that needs to be parsed", required = true) String walmart_temp) throws JSONException {
		//Creating log file
		try
		{
	        // This block configure the logger with handler and formatter  
	        fh = new FileHandler(System.getProperty("user.dir") + "/" + AppConfigurations.AppName + "/src/main/resources/AppLogs/AppLogs.txt",true);
	        logger.addHandler(fh);
	        SimpleFormatter formatter = new SimpleFormatter();  
	        fh.setFormatter(formatter);
	    } 
		catch (SecurityException e)
		{  
	        e.printStackTrace();  
	    } 
		catch (IOException e)
		{  
	        e.printStackTrace();  
	    }
				
		String InsertedIds = "Inserted walmart_temp Record Id(s) : ";
		String json_data = "";
		try
    	{
			JSONObject json_obj = new JSONObject(walmart_temp);
	    	JSONArray array = json_obj.getJSONArray("orders");
	    	int i,Id;
	    	for(i = 0 ; i < array.length() ; i++){
	    		json_data = array.getJSONObject(i).getString("PO#") + "," + array.getJSONObject(i).getString("Order#")+ "," +array.getJSONObject(i).getString("Ship By")+ "," +array.getJSONObject(i).getString("Customer Name")+ "," +array.getJSONObject(i).getString("Customer Shipping Info")+ "," +array.getJSONObject(i).getString("Line#")+ "," +array.getJSONObject(i).getString("UPC")+ "," +array.getJSONObject(i).getString("Status")+ "," +array.getJSONObject(i).getString("Item Description")+ "," +array.getJSONObject(i).getString("Requested Carrier Method")+ "," +array.getJSONObject(i).getString("Requested Shipping Method")+ "," +array.getJSONObject(i).getString("Qty")+ "," +array.getJSONObject(i).getString("SKU")+ "," +array.getJSONObject(i).getString("Update Status")+ "," +array.getJSONObject(i).getString("Update Qty")+ "," +array.getJSONObject(i).getString("Actual Carrier Method Used")+ "," +array.getJSONObject(i).getString("Update Shipping Method")+ "," +array.getJSONObject(i).getString("Tracking Number")+ "," +array.getJSONObject(i).getString("Tracking Url");
	    	}
	    	if(json_data.length() > 0)
	    	{
		    	for(i = 0 ; i < array.length() ; i++){
		    		WalmartTemp walmart_temp_obj = new WalmartTemp(array.getJSONObject(i).getString("PO#"),array.getJSONObject(i).getString("Order#"),array.getJSONObject(i).getString("Ship By"),array.getJSONObject(i).getString("Customer Name"),array.getJSONObject(i).getString("Customer Shipping Info"),array.getJSONObject(i).getString("Line#"),array.getJSONObject(i).getString("UPC"),array.getJSONObject(i).getString("Status"),array.getJSONObject(i).getString("Item Description"),array.getJSONObject(i).getString("Requested Carrier Method"),array.getJSONObject(i).getString("Requested Shipping Method"),array.getJSONObject(i).getString("Qty"),array.getJSONObject(i).getString("SKU"),array.getJSONObject(i).getString("Update Status"),array.getJSONObject(i).getString("Update Qty"),array.getJSONObject(i).getString("Actual Carrier Method Used"),array.getJSONObject(i).getString("Update Shipping Method"),array.getJSONObject(i).getString("Tracking Number"),array.getJSONObject(i).getString("Tracking Url"));
		    		Id = WalmartTempServicesObj.InsertWalmartDetailsToDb(walmart_temp_obj);
		    		if(i == 0)
		    		{
		    			InsertedIds = InsertedIds + Id;
		    		}
		    		else
		    		{
		    			InsertedIds = InsertedIds + "," + Id;
		    		}
		    	}
	    	}
	    	//Call the 'usp_order_data_normalization_for_walmart' SP
	    	WalmartTempServicesObj.NormalizeWalmartOrderData();
	    	Response ValidJson = Response
    	            .status(200)
    	            .entity(InsertedIds)
    	            .build();
	    	logger.info(NewLineChar + "***********************************************************************************"
	    			+ NewLineChar + "Input Json : " + NewLineChar + walmart_temp + NewLineChar +"Response : " + NewLineChar + InsertedIds + NewLineChar
	    			+"***********************************************************************************");
	    	fh.close();
    		return ValidJson;
    	}
    	catch (JSONException ex) 
    	{
    		logger.info(NewLineChar + "***********************************************************************************"
    				+ NewLineChar + "Input Json : " + NewLineChar + walmart_temp + NewLineChar + "Response : " + NewLineChar + "Invalid Json." + NewLineChar +
    				"***********************************************************************************");
    		fh.close();
    		Response InvalidJson = Response
    	            .status(400)
    	            .entity("Invalid Json.")
    	            .build();
    		return InvalidJson;
    	}
    }
}
