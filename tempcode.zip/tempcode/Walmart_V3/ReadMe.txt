=========================================
  	Walmart Data Processing V3
=========================================

-----------------------------------------
	System Requirements
-----------------------------------------
1) Java JRE 8 or higher

-----------------------------------------
	Setup Instructions
-----------------------------------------
1) Import the project into eclipse workspace (File->Import->Existing Projects Into Workspace.).
2) Configure the app configs in AppConfig.properties file (src/main/resources).
	2.1)InputFolderPath : The directory in which the json file is stored.
	Eg - D:/jbdevstudio_workspace/walmart_data_exchange/input
	2.2)ThreadSleepTime : Java thread sleep time in milliseconds
	Eg - 3600000
	2.3)ErrorDirPollingTime : Error Directory Polling Interval in milliseconds
	Eg - 120000
	2.4) ApiBaseUrl : Api base path url
	Eg - http://192.168.1.151:8080/WalmartDbOperationsApi_V2/WebApi/
	2.5) ApiResource : Path of the api resource to be accessed relative to ApiBaseUrl
	Eg - WalmartTempResource
	2.6)ApiUsername : Api username
	2.7) ApiPassword : Api password
3) Configure the following log4j log file creation settings in log4j.properties file (src/main/resources).
	3.1)log4j.appender.rollingFile.File : Specify the path where the log file should be created.
	Eg - D:/jbdevstudio_workspace/Walmart_V2/src/main/resources/AppLogs/ProcessedFileLogs.log
	3.2)log4j.appender.rollingFile.MaxFileSize : Specify the maximum file size of log file. When log file size exceeds this limit a new log file is created and old log files are moved to a backup log file.
	Eg - 10KB
	3.3)log4j.appender.rollingFile.MaxBackupIndex : Specify the number of log file backups that should be kept.
	Eg - 10
4) Ensure that all dependencies in pom.xml are resolved.
5) Run the project as java application and select main type as 'MainApp - org.cto.walmart'.

-----------------------------------------
	Functionalities
-----------------------------------------
1) Parses the json text file in input directory and calls the walmart api.

-----------------------------------------
	Changelog
-----------------------------------------
#V1
- Parsing the json data from text file in input directory.
- Call walmart api and send the json data as POST request .
- Logging the api response.
- Move file to error directory in case of failure response codes(500,404,401).
- Check the ErrorDirectory at specified intervals and process the files that couldn't be processed.

#V2
- Changed the log file creation from java.util.logger to Log4j, so that the log files could be split into backup log files when its size excceds a limit.

#V3
- Changed the AppConfig file location to WalmartConfig folder in the root of application so that it could be loaded from the application's jar file.
- Removed Apache camel thread sleep time configuration.
- Changes to keep apache camel route running until the application is stopped or JVM terminates.
- Added Camel route test case using CamelTestSupport library.
-----------------------------------------
	Dependency Jar files required
-----------------------------------------
.m2\repository\junit\junit\4.11\junit-4.11.jar
.m2\repository\org\hamcrest\hamcrest-core\1.3\hamcrest-core-1.3.jar
.m2\repository\org\apache\camel\camel-blueprint\2.17.1\camel-blueprint-2.17.1.jar
.m2\repository\org\apache\camel\camel-core-xml\2.17.1\camel-core-xml-2.17.1.jar
.m2\repository\org\apache\camel\camel-core-osgi\2.17.1\camel-core-osgi-2.17.1.jar
.m2\repository\com\sun\xml\bind\jaxb-core\2.2.11\jaxb-core-2.2.11.jar
.m2\repository\com\sun\xml\bind\jaxb-impl\2.2.11\jaxb-impl-2.2.11.jar
.m2\repository\log4j\log4j\1.2.17\log4j-1.2.17.jar
.m2\repository\org\apache\camel\camel-test-blueprint\2.17.1\camel-test-blueprint-2.17.1.jar
.m2\repository\org\apache\camel\camel-core\2.17.1\camel-core-2.17.1-tests.jar
.m2\repository\org\apache\aries\proxy\org.apache.aries.proxy.api\1.0.1\org.apache.aries.proxy.api-1.0.1.jar
.m2\repository\org\apache\aries\proxy\org.apache.aries.proxy.impl\1.0.4\org.apache.aries.proxy.impl-1.0.4.jar
.m2\repository\org\apache\aries\blueprint\org.apache.aries.blueprint.api\1.0.1\org.apache.aries.blueprint.api-1.0.1.jar
.m2\repository\org\apache\aries\blueprint\org.apache.aries.blueprint.core\1.4.4\org.apache.aries.blueprint.core-1.4.4.jar
.m2\repository\org\apache\aries\quiesce\org.apache.aries.quiesce.api\1.0.0\org.apache.aries.quiesce.api-1.0.0.jar
.m2\repository\org\apache\aries\blueprint\org.apache.aries.blueprint.cm\1.0.6\org.apache.aries.blueprint.cm-1.0.6.jar
.m2\repository\org\apache\aries\org.apache.aries.util\1.1.1\org.apache.aries.util-1.1.1.jar
.m2\repository\org\apache\felix\org.apache.felix.connect\0.1.0\org.apache.felix.connect-0.1.0.jar
.m2\repository\org\ops4j\pax\swissbox\pax-swissbox-tinybundles\1.3.2\pax-swissbox-tinybundles-1.3.2.jar
.m2\repository\org\ops4j\base\ops4j-base-lang\1.2.2\ops4j-base-lang-1.2.2.jar
.m2\repository\org\ops4j\base\ops4j-base-io\1.2.2\ops4j-base-io-1.2.2.jar
.m2\repository\org\ops4j\base\ops4j-base-monitors\1.2.2\ops4j-base-monitors-1.2.2.jar
.m2\repository\org\ops4j\base\ops4j-base-store\1.2.2\ops4j-base-store-1.2.2.jar
.m2\repository\org\ops4j\pax\swissbox\pax-swissbox-bnd\1.3.2\pax-swissbox-bnd-1.3.2.jar
.m2\repository\biz\aQute\bndlib\0.0.357\bndlib-0.0.357.jar
.m2\repository\commons-logging\commons-logging\1.2\commons-logging-1.2.jar
.m2\repository\org\apache\felix\org.apache.felix.configadmin\1.8.8\org.apache.felix.configadmin-1.8.8.jar
.m2\repository\org\apache\felix\org.apache.felix.fileinstall\3.5.2\org.apache.felix.fileinstall-3.5.2.jar
.m2\repository\org\apache\camel\camel-core\2.17.1\camel-core-2.17.1.jar
.m2\repository\org\slf4j\slf4j-api\1.7.13\slf4j-api-1.7.13.jar
.m2\repository\mysql\mysql-connector-java\5.1.26\mysql-connector-java-5.1.26.jar
.m2\repository\org\slf4j\slf4j-log4j12\1.7.21\slf4j-log4j12-1.7.21.jar
.m2\repository\org\apache\camel\camel-test\2.15.1\camel-test-2.15.1.jar
.m2\repository\org\apache\camel\camel-testng\2.15.1\camel-testng-2.15.1.jar
.m2\repository\org\apache\camel\camel-spring\2.15.1\camel-spring-2.15.1.jar
.m2\repository\org\springframework\spring-context\4.1.5.RELEASE\spring-context-4.1.5.RELEASE.jar
.m2\repository\org\springframework\spring-aop\4.1.5.RELEASE\spring-aop-4.1.5.RELEASE.jar
.m2\repository\aopalliance\aopalliance\1.0\aopalliance-1.0.jar
.m2\repository\org\springframework\spring-tx\4.1.5.RELEASE\spring-tx-4.1.5.RELEASE.jar
.m2\repository\org\apache\camel\camel-test-spring\2.15.1\camel-test-spring-2.15.1.jar
.m2\repository\org\springframework\spring-test\4.1.5.RELEASE\spring-test-4.1.5.RELEASE.jar
.m2\repository\org\springframework\spring-beans\4.1.5.RELEASE\spring-beans-4.1.5.RELEASE.jar
.m2\repository\org\springframework\spring-expression\4.1.5.RELEASE\spring-expression-4.1.5.RELEASE.jar
.m2\repository\org\springframework\spring-core\4.1.5.RELEASE\spring-core-4.1.5.RELEASE.jar
.m2\repository\org\testng\testng\6.8.8\testng-6.8.8.jar
.m2\repository\org\beanshell\bsh\2.0b4\bsh-2.0b4.jar
.m2\repository\com\beust\jcommander\1.27\jcommander-1.27.jar
.m2\repository\org\apache\camel\camel-http\2.17.1\camel-http-2.17.1.jar
.m2\repository\org\apache\camel\camel-http-common\2.17.1\camel-http-common-2.17.1.jar
.m2\repository\javax\servlet\javax.servlet-api\3.1.0\javax.servlet-api-3.1.0.jar
.m2\repository\commons-httpclient\commons-httpclient\3.1\commons-httpclient-3.1.jar
.m2\repository\commons-codec\commons-codec\1.10\commons-codec-1.10.jar
.m2\repository\javax\ws\rs\javax.ws.rs-api\2.0\javax.ws.rs-api-2.0.jar
.m2\repository\org\glassfish\jersey\core\jersey-client\2.22.2\jersey-client-2.22.2.jar
.m2\repository\org\glassfish\jersey\core\jersey-common\2.22.2\jersey-common-2.22.2.jar
.m2\repository\javax\annotation\javax.annotation-api\1.2\javax.annotation-api-1.2.jar
.m2\repository\org\glassfish\jersey\bundles\repackaged\jersey-guava\2.22.2\jersey-guava-2.22.2.jar
.m2\repository\org\glassfish\hk2\osgi-resource-locator\1.0.1\osgi-resource-locator-1.0.1.jar
.m2\repository\org\glassfish\hk2\hk2-api\2.4.0-b34\hk2-api-2.4.0-b34.jar
.m2\repository\org\glassfish\hk2\hk2-utils\2.4.0-b34\hk2-utils-2.4.0-b34.jar
.m2\repository\org\glassfish\hk2\external\aopalliance-repackaged\2.4.0-b34\aopalliance-repackaged-2.4.0-b34.jar
.m2\repository\org\glassfish\hk2\external\javax.inject\2.4.0-b34\javax.inject-2.4.0-b34.jar
.m2\repository\org\glassfish\hk2\hk2-locator\2.4.0-b34\hk2-locator-2.4.0-b34.jar
.m2\repository\org\javassist\javassist\3.18.1-GA\javassist-3.18.1-GA.jar