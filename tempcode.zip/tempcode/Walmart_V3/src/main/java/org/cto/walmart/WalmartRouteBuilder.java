package org.cto.walmart;

public class WalmartRouteBuilder extends org.apache.camel.builder.RouteBuilder{
	
	@Override
	public void configure() throws Exception
	{
		try
		{
			/*from("file:/" + MainApp.InputFolderPath + "?move=./processedfiles&include=.*.txt").
			setHeader(Exchange.HTTP_METHOD,simple("POST")).
			setHeader(Exchange.CONTENT_TYPE,simple("text/plain")).
			setHeader(AuthorizationHeaderName,simple(AuthorizationHeaderValue)).
			doTry().
				to(MainApp.ApiUrl).
			doCatch(ConnectException.class).
				log("Unable to access the API.").
			end();*/
			
			//Camel Route 1 : Pick up file from input directory and forward the json data to api
			from("file:/" + MainApp.InputFolderPath + "?readLock=changed&move=./ProcessedFiles&include=.*.txt").
			process(new ApiProcessor()).
			choice().
			//If the header contains error response codes then file is placed in ErrorDirectory
			when(header("ResponseCode").isEqualTo(500)). //When error occurs at api server 
				to("file:/" + MainApp.InputFolderPath + "/ErrorDirectory").
			when(header("ResponseCode").isEqualTo(401)). //When api authentication fails
				to("file:/" + MainApp.InputFolderPath + "/ErrorDirectory").
			when(header("ResponseCode").isEqualTo(404)). //When api url is incorrect
				to("file:/" + MainApp.InputFolderPath + "/ErrorDirectory").
			when(header("ResponseCode").isEqualTo(0)). //When api url is not available
				to("file:/" + MainApp.InputFolderPath + "/ErrorDirectory").
			otherwise().
				to("mock:result");
			
			//Camel Route 2 : Check the ErrorDirectory at regular intervals. If files are present put them in to input directory so that they could be processed again.
			//Checks the ErrorDirectory frequently based on Polling interval time specified in config file
			from("file:/" + MainApp.InputFolderPath + "/ErrorDirectory?move=./ProcessedErrorDirectoryFiles&readLock=changed&delay=" + MainApp.ErrorDirPollingTime + "&include=.*.txt").
			doTry().
				to("file:/" + MainApp.InputFolderPath).
			doCatch(Exception.class).
				to("mock:result");
		}
		catch(Exception e)
		{
			System.out.println("Something went wrong.Please ensure that app configurations are configured correctly in AppConfig.properties file.\n");
			System.out.println("Exception : " + e);
		}
	}
}