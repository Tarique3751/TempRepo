package org.cto.walmart;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.camel.CamelContext;
import org.apache.camel.impl.DefaultCamelContext;

public class MainApp {
	public static Properties prop = new Properties();
	public static String InputFolderPath;
	public static String ErrorDirPollingTime;
	public static String ApiBaseUrl;
	public static String ApiResource;
	public static String ApiUsername;
	public static String ApiPassword;
	
	public static void main(String[] args){
		
		//Read the app configs
		MainApp.ReadAppConfigurations();
		
		//Initializing and staring the Camel Route
		WalmartRouteBuilder RouteBuilder = new WalmartRouteBuilder();
		CamelContext ctx = new DefaultCamelContext();
		try
		{
			ctx.addRoutes(RouteBuilder);
			ctx.start();
			Thread.currentThread().join(); //Keep the apache camel thread running until the application stops or JVM terminates.
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static void ReadAppConfigurations()
	{
		try
		{
			prop.load(new FileInputStream("./WalmartConfig/AppConfig.properties"));
		}
		catch(IOException e)
		{
			System.out.println("Exception :" + e);
		}
		//Setting the app config variables
		InputFolderPath = prop.getProperty("InputFolderPath"); //Input directory path
		ErrorDirPollingTime = prop.getProperty("ErrorDirPollingTime"); //Polling interval to check the error directory for any un proccessed files
		ApiBaseUrl = prop.getProperty("ApiBaseUrl"); //Api Base url path
		ApiResource = prop.getProperty("ApiResource"); //Relative path of api resource to be accessed
		ApiUsername = prop.getProperty("ApiUsername"); //Api username
		ApiPassword = prop.getProperty("ApiPassword"); //Api password
	}
}
