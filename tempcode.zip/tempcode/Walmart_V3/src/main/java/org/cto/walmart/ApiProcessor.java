package org.cto.walmart;

import java.nio.file.Path;
import java.nio.file.Paths;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Response;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

public class ApiProcessor implements Processor {
	public static String FilePath;
	public static String FileName;
	public static String FileContent;
	public static int ApiResponse;
	public static String NewLineChar = System.getProperty("line.separator"); //To get the newline character of corresponding platform
	public String ProcessingStatus;
	public String ProcessingInfo;
	
	static Logger log = Logger.getLogger(ApiProcessor.class.getName());
	
	@Override
	public void process(Exchange exchange) throws Exception {
		FilePath = exchange.getIn().getBody().toString();
		FilePath = FilePath.substring(FilePath.indexOf("[") + 1, FilePath.indexOf("]"));
		Path p = Paths.get(FilePath);
		FileName = p.getFileName().toString();
		FileContent = exchange.getIn().getBody(String.class);
		
		//API Call
		//Define valid basic authentication credential values
        String username = MainApp.ApiUsername;
        String password = MainApp.ApiPassword;
        String UsernameAndPassword = username + ":" + password;
        String AuthorizationHeaderName = "Authorization";
        String AuthorizationHeaderValue = "Basic " + java.util.Base64.getEncoder().encodeToString( UsernameAndPassword.getBytes() );
		
		try
		{
	        // Perform a post request
	        String restResource = MainApp.ApiBaseUrl;
	        Client client = ClientBuilder.newClient();
	        Response res = client.target( restResource )
	            .path(MainApp.ApiResource) // API Module Path
	            .request( "text/plain" ) // Expected response mime type
	            .header( AuthorizationHeaderName, AuthorizationHeaderValue ) // The basic authentication header goes here
	            .post( Entity.text(FileContent) ); // Perform a post with the form values
	        System.out.println("Api url : " + MainApp.ApiBaseUrl + MainApp.ApiResource);
	        ApiResponse = res.getStatus();
	        System.out.println("Response Code : " + ApiResponse);
	        
	        if(ApiResponse == 400)
			{
	        	ProcessingStatus = "Successfully Processed.";
	        	ProcessingInfo = "Invalid Json.";
	        	System.out.println("Invalid Json.");
			}
			else if(ApiResponse == 401)
			{
				ProcessingStatus = "Processing Failed. File has been moved to ErrorDirectory.";
				ProcessingInfo = "Unauthorized Access. Please specify correct Api credentials.";
				System.out.println("Unauthorized Access. Please specify correct Api credentials.");
			}
			else if(ApiResponse == 404)
			{
				ProcessingStatus = "Processing Failed. File has been moved to ErrorDirectory.";
				ProcessingInfo = "Api resource not found.";
				System.out.println("Api resource not found.");
			}
			else if(ApiResponse == 500)
			{
				ProcessingStatus = "Processing Failed. File has been moved to ErrorDirectory.";
				ProcessingInfo = "Api server problems.";
				System.out.println("Api server problems.");
			}
			else if(ApiResponse == 200)
			{
				ProcessingStatus = "Successfully Processed.";
				ProcessingInfo = "Data successfully saved.";
				System.out.println("Data successfully saved.");
			}
		}
		catch(Exception e)
		{
			ApiResponse = 0;
			ProcessingStatus = "Processing Failed. File has been moved to ErrorDirectory.";
			ProcessingInfo = "Api not accessible.";
			System.out.println("Api not accessible.");
		}
		
		//Logging the details using apache log4j
		log.info(NewLineChar + "***********************************************************************************" + NewLineChar
				+ "Processed file - " + FileName + NewLineChar
				+ "Processed file content - " + NewLineChar + FileContent + NewLineChar
				+ "Api Response Code - " + ApiResponse + NewLineChar
				+ "Processing Status - " + ProcessingStatus + NewLineChar
				+ "Processing Info - " + ProcessingInfo + NewLineChar
				+ "***********************************************************************************");
		
		Message newMessage = exchange.getIn(); 
		newMessage.setHeader("ResponseCode",ApiResponse);
	}
}