package org.cto.walmart.testcases;

import java.io.File;
import java.util.Date;

import org.apache.camel.Exchange;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.cto.walmart.MainApp;
import org.cto.walmart.WalmartRouteBuilder;
import org.junit.Before;
import org.junit.Test;

public class WalmartTest extends CamelTestSupport {
	
	@Before
	public void setup() throws Exception {
		// one-time initialization code
		MainApp.ReadAppConfigurations();
		context.addRoutes(new WalmartRouteBuilder());
	}
	
	@Test
	public void TestWalmartRoute() throws Exception {
		String BodyOfMessage = "{\r\n  \"orders\": [\r\n    {\r\n      \"id\": 0,\r\n      \"PO#\": \"string\",\r\n      \"Order#\": \"string\",\r\n      \"Ship By\": \"string\",\r\n      \"Customer Name\": \"string\",\r\n      \"Customer Shipping Info\": \"string\",\r\n      \"Line#\": \"string\",\r\n      \"UPC\": \"string\",\r\n      \"Status\": \"string\",\r\n      \"Item Description\": \"string\",\r\n      \"Requested Carrier Method\": \"string\",\r\n      \"Requested Shipping Method\": \"string\",\r\n      \"Qty\": \"string\",\r\n      \"SKU\": \"string\",\r\n      \"Update Status\": \"string\",\r\n      \"Update Qty\": \"string\",\r\n      \"Actual Carrier Method Used\": \"string\",\r\n      \"Update Shipping Method\": \"string\",\r\n      \"Tracking Number\": \"string\",\r\n      \"Tracking Url\": \"string\"\r\n    }\r\n  ]\r\n}";
		String timestamp = new java.text.SimpleDateFormat("yyyyMMdd_hmmss").format(new Date());
		
		// Initialize the mock and set expected results
		MockEndpoint mock = context.getEndpoint("mock:result", MockEndpoint.class);
		mock.expectedMessageCount(1);
		mock.setResultWaitTime(1000);
		mock.expectedHeaderReceived("ResponseCode", 200);
	
		// ProducerTemplate sends a message (i.e. a File) to the inbox directory
		template.sendBodyAndHeader("file:/" + MainApp.InputFolderPath + "?readLock=changed&move=./ProcessedFiles&include=.*.txt", BodyOfMessage, Exchange.FILE_NAME, "WalmartOrders_" + timestamp + ".txt");
		Thread.sleep(5000);
	
		// Was the file moved to the processed directory?
		File target = new File(MainApp.InputFolderPath + "/ProcessedFiles/" + "WalmartOrders_" + timestamp + ".txt");
		assertTrue("File not moved!", target.exists());
	
		mock.assertIsSatisfied();
	}
}
