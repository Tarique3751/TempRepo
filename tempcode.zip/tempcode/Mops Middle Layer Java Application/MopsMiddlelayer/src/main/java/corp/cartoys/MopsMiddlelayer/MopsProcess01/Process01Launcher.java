package corp.cartoys.MopsMiddlelayer.MopsProcess01;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import corp.cartoys.MopsMiddlelayer.AppConfigValidator;

/**
 *MopsProcess01 - Process the incoming monsoon order files, split them into mnsn_order_header and mnsn_order_details tables and generate the Gers xml.
 * @author jjude
 */
public class Process01Launcher {
	public static Properties prop = new Properties();
	public static String inputFolderPath;
	public static String outputFolderPath;
	public static String dBPollingTime;
	public static String dataSplitDelimiter;
	public static String acceptedFileListRegExp;
	public static String AMAZON_MARKET_NAME;
	public static String EBAY_MARKET_NAME;
	public static String STATUS_ID_FOR_XML_GENERATION;
	public static String STATUS_ID_FOR_XML_GENERATED_RECORDS;
	
	public static String PHONENUMBER_LENGTH;
	public static String PHN_NUM_WITH_CODE_LENGTH;
	public static String ERR_MSG_FOR_PHONENUM;
	public static String ERR_MSG_FOR_CITY;
	public static String ERR_MSG_FOR_STATE;
	
	public static String MAX_TOTAL_AMOUNT_NEED_ATTENTION;
	public static String WRN_MSG_FOR_TOTAL_AMT;
	public static String AMAZON_FBA_EMAIL_VAL;
	public static String AMAZON_FBA_FNAME_VAL;
	public static String AMAZON_FBA_LNAME_VAL;
	public static String AMAZON_FBA_ADDR1_VAL;
	public static String AMAZON_FBA_ADDR2_VAL;
	public static String EBAY_FBA_ADDR2_VAL;
	public static String AMAZON_FBA_LOCATION_CODE_VAL;
	public static String EBAY_FBA_LOCATION_CODE_VAL;
	public static String CONFIDENTIAL_CITY_VAL;
	public static String CONFIDENTIAL_STATE_VAL;
	public static String CONFIDENTIAL_POSTAL_CODE;
	public static String MAX_ADDR_LEN_NEED_ATTENTION;
	public static String WRN_MSG_FOR_ADDR_LEN;
	public static String WRN_MSG_FOR_LNAME_EMPTY;
	public static String WRN_MSG_FOR_MULTIPLE_SKU;
	
	public static String FIN_CUST_CD_FOR_AMAZON;
	public static String FIN_CUST_CD_FOR_EBAY;
	public static String EBAY_FBA_EMAIL_VAL;
	public static String EBAY_FBA_FNAME_VAL;
	public static String EBAY_FBA_LNAME_VAL;
	public static String EBAY_FBA_ADDR1_VAL;
	public static String FBA_ORDER_SRT_CD;
	public static String CTO_ORDER_SRT_CD;
	public static String FBA_PU_DEL;
	public static String CTO_PU_DEL;
	
	public static String ORIGIN_CD;
	public static String CAUSE_CD;
	public static String EMP_CD_OP;
	public static String EMP_CD_KEYER;
	public static String TAX_CD;
	public static String ORDER_TP_CD;
	public static String SO_STORE_CD;
	public static String PU_DEL_STORE_CD;
	public static String SO_EMP_SLSP_CD1;
	public static String SHIP_TO_TITLE;
	public static String SHIP_TO_EXT;
	public static String SHIP_TO_CORP;
	public static String PCT_OF_SALE1;
	public static String DEL_CHG;
	public static String SETUP_CHG;
	public static String ORIG_DEL_DOC_NUM;
	public static String ALT_CUST_CD;
	public static String SRT_CD;
	public static String TITLE;
	public static String INIT;
	public static String BUS_PHONE;
	public static String EXT;
	public static String CORP_NAME;
	public static String CUST_TP_CD;
	public static String SER_NUM;
	public static String SO_LN_CMNT;
	public static String ACTIVATION_DT;
	public static String ACTIVATION_PHONE;
	public static String SHIP_GROUP;
	static String configFilePath = "./MopsProcess01Config/AppConfig.properties";
	
	//This variable ensures that ExtractNormalizedData and XmlGenerator beans are used by only one camel route at a time.
	public static int lockBizRulesAndXmlGen  = 0;

	/**
	 * Read the AppConfig properties file and fetch the application configurations.
	 * @param Nothing.
	 * @return Nothing.
	 */
	public static void readAppConfigurations()
	{		
		try
		{
			prop.load(new FileInputStream(configFilePath));
		}
		catch(IOException e)
		{
			System.out.println("Exception :" + e);
		}
		//Setting the app config variables
		inputFolderPath                     = prop.getProperty("InputFolderPath"); //Input directory path
		outputFolderPath                    = prop.getProperty("OutputFolderPath"); //Output directory path
		dBPollingTime                       = prop.getProperty("DBPollingTime");//Database polling interval
		dataSplitDelimiter                  = prop.getProperty("DataSplitDelimiter");//Delimiter to split out the values from file
		acceptedFileListRegExp              = prop.getProperty("AcceptedFileListRegExp"); //List of file types that should be parsed
		AMAZON_MARKET_NAME                  = prop.getProperty("AMAZON_MARKET_NAME");// Market Name for Amazon 
		EBAY_MARKET_NAME                    = prop.getProperty("EBAY_MARKET_NAME");// Market Name for Ebay 
		STATUS_ID_FOR_XML_GENERATION        = prop.getProperty("STATUS_ID_FOR_XML_GENERATION"); //Status id to indicate the DB records for which the XML should be generated
		STATUS_ID_FOR_XML_GENERATED_RECORDS = prop.getProperty("STATUS_ID_FOR_XML_GENERATED_RECORDS"); //Status id to indicate the DB records for which XML was successfully generated.
		
		//Data Validation Configuration
		PHONENUMBER_LENGTH                  = prop.getProperty("PHONENUMBER_LENGTH");//Permitted Length for Buyer Phone Numbers.
		PHN_NUM_WITH_CODE_LENGTH            = prop.getProperty("PHN_NUM_WITH_CODE_LENGTH");//Permitted Length for Buyer Phone Numbers with code.
		ERR_MSG_FOR_PHONENUM                = prop.getProperty("ERR_MSG_FOR_PHONENUM");//Error message for invalid phone numbers.
		ERR_MSG_FOR_CITY                    = prop.getProperty("ERR_MSG_FOR_CITY");//Error message for invalid city.
		ERR_MSG_FOR_STATE                   = prop.getProperty("ERR_MSG_FOR_STATE");//Error message for state.
		
		//Business Rules Configurations For Database Records
		MAX_TOTAL_AMOUNT_NEED_ATTENTION     = prop.getProperty("MAX_TOTAL_AMOUNT_NEED_ATTENTION");
		WRN_MSG_FOR_TOTAL_AMT               = prop.getProperty("WRN_MSG_FOR_TOTAL_AMT");
		AMAZON_FBA_EMAIL_VAL                = prop.getProperty("AMAZON_FBA_EMAIL_VAL");
		AMAZON_FBA_FNAME_VAL                = prop.getProperty("AMAZON_FBA_FNAME_VAL");
		AMAZON_FBA_LNAME_VAL                = prop.getProperty("AMAZON_FBA_LNAME_VAL");
		AMAZON_FBA_ADDR1_VAL                = prop.getProperty("AMAZON_FBA_ADDR1_VAL");
		AMAZON_FBA_ADDR2_VAL                = prop.getProperty("AMAZON_FBA_ADDR2_VAL");
		EBAY_FBA_ADDR2_VAL                  = prop.getProperty("EBAY_FBA_ADDR2_VAL");
		AMAZON_FBA_LOCATION_CODE_VAL        = prop.getProperty("AMAZON_FBA_LOCATION_CODE_VAL");
		EBAY_FBA_LOCATION_CODE_VAL          = prop.getProperty("EBAY_FBA_LOCATION_CODE_VAL");
		CONFIDENTIAL_CITY_VAL               = prop.getProperty("CONFIDENTIAL_CITY_VAL");
		CONFIDENTIAL_STATE_VAL              = prop.getProperty("CONFIDENTIAL_STATE_VAL");
		CONFIDENTIAL_POSTAL_CODE            = prop.getProperty("CONFIDENTIAL_POSTAL_CODE");
		MAX_ADDR_LEN_NEED_ATTENTION         = prop.getProperty("MAX_ADDR_LEN_NEED_ATTENTION");
		WRN_MSG_FOR_ADDR_LEN                = prop.getProperty("WRN_MSG_FOR_ADDR_LEN");
		WRN_MSG_FOR_LNAME_EMPTY             = prop.getProperty("WRN_MSG_FOR_LNAME_EMPTY");
		WRN_MSG_FOR_MULTIPLE_SKU            = prop.getProperty("WRN_MSG_FOR_MULTIPLE_SKU");
		EBAY_FBA_EMAIL_VAL                  = prop.getProperty("EBAY_FBA_EMAIL_VAL");
		EBAY_FBA_FNAME_VAL                  = prop.getProperty("EBAY_FBA_FNAME_VAL");
		EBAY_FBA_LNAME_VAL                  = prop.getProperty("EBAY_FBA_LNAME_VAL");
		EBAY_FBA_ADDR1_VAL                  = prop.getProperty("EBAY_FBA_ADDR1_VAL");
		
		//Business Rules Configurations For XML Records
		FIN_CUST_CD_FOR_AMAZON              = prop.getProperty("FIN_CUST_CD_FOR_AMAZON");
		FIN_CUST_CD_FOR_EBAY                = prop.getProperty("FIN_CUST_CD_FOR_EBAY");
		FBA_ORDER_SRT_CD                    = prop.getProperty("FBA_ORDER_SRT_CD");
		CTO_ORDER_SRT_CD                    = prop.getProperty("CTO_ORDER_SRT_CD");
		FBA_PU_DEL                          = prop.getProperty("FBA_PU_DEL");
		CTO_PU_DEL                          = prop.getProperty("CTO_PU_DEL");
		ORIGIN_CD                           = prop.getProperty("ORIGIN_CD");
		CAUSE_CD                            = prop.getProperty("CAUSE_CD");
		EMP_CD_OP                           = prop.getProperty("EMP_CD_OP");
		EMP_CD_KEYER                        = prop.getProperty("EMP_CD_KEYER");
		TAX_CD                              = prop.getProperty("TAX_CD");
		ORDER_TP_CD                         = prop.getProperty("ORDER_TP_CD");
		SO_STORE_CD                         = prop.getProperty("SO_STORE_CD");
		PU_DEL_STORE_CD                     = prop.getProperty("PU_DEL_STORE_CD");
		SO_EMP_SLSP_CD1                     = prop.getProperty("SO_EMP_SLSP_CD1");
		SHIP_TO_TITLE                       = prop.getProperty("SHIP_TO_TITLE");
		SHIP_TO_EXT                         = prop.getProperty("SHIP_TO_EXT");
		SHIP_TO_CORP                        = prop.getProperty("SHIP_TO_CORP");
		PCT_OF_SALE1                        = prop.getProperty("PCT_OF_SALE1");
		DEL_CHG                             = prop.getProperty("DEL_CHG");
		SETUP_CHG                           = prop.getProperty("SETUP_CHG");
		ORIG_DEL_DOC_NUM                    = prop.getProperty("ORIG_DEL_DOC_NUM");
		ALT_CUST_CD                         = prop.getProperty("ALT_CUST_CD");
		SRT_CD                              = prop.getProperty("SRT_CD");
		TITLE                               = prop.getProperty("TITLE");
		INIT                                = prop.getProperty("INIT");
		BUS_PHONE                           = prop.getProperty("BUS_PHONE");
		EXT                                 = prop.getProperty("EXT");
		CORP_NAME                           = prop.getProperty("CORP_NAME");
		CUST_TP_CD                          = prop.getProperty("CUST_TP_CD");
		SER_NUM                             = prop.getProperty("SER_NUM");
		SO_LN_CMNT                          = prop.getProperty("SO_LN_CMNT");
		ACTIVATION_DT                       = prop.getProperty("ACTIVATION_DT");
		ACTIVATION_PHONE                    = prop.getProperty("ACTIVATION_PHONE");
		SHIP_GROUP                          = prop.getProperty("SHIP_GROUP");
		
		//Validate the configurations
		AppConfigValidator.checkFolderExists(inputFolderPath,configFilePath);
		AppConfigValidator.checkFolderExists(outputFolderPath,configFilePath);
		AppConfigValidator.isNumeric("DBPollingTime",dBPollingTime,configFilePath);
		AppConfigValidator.isNumeric("STATUS_ID_FOR_XML_GENERATION",STATUS_ID_FOR_XML_GENERATION,configFilePath);
		AppConfigValidator.isNumeric("STATUS_ID_FOR_XML_GENERATED_RECORDS",STATUS_ID_FOR_XML_GENERATED_RECORDS,configFilePath);
		AppConfigValidator.isNumeric("PHONENUMBER_LENGTH",PHONENUMBER_LENGTH,configFilePath);
		AppConfigValidator.isNumeric("PHN_NUM_WITH_CODE_LENGTH",PHN_NUM_WITH_CODE_LENGTH,configFilePath);
		AppConfigValidator.isNumeric("MAX_TOTAL_AMOUNT_NEED_ATTENTION",MAX_TOTAL_AMOUNT_NEED_ATTENTION,configFilePath);
		AppConfigValidator.isNumeric("MAX_ADDR_LEN_NEED_ATTENTION",MAX_ADDR_LEN_NEED_ATTENTION,configFilePath);
	}
}
