package corp.cartoys.MopsMiddlelayer.MopsProcess03.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

/**
 * The Data transfer object for mnsn_order_tracking table.
 * @author jjude
 */
@Entity
@Table(name = "mnsn_order_tracking")
@NamedNativeQueries({
	@NamedNativeQuery(
	name        = "MonsoonOrderTracking.UpdateMopsSP",
	query       = "CALL mnsn_order_tracking_update_mops_sp",
	resultClass = MonsoonOrderTracking.class
	)
})
public class MonsoonOrderTracking {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int TrackingId;
	private String GersInvoice;
	private int OrderNumber;
	private String TrackingNumber;
	private String sku;
	private int qty;
	private String CreatedBy;
	private String CreatedOn;
	private String UpdatedBy;
	private String UpdatedOn;
	private String CreatedFrom;
	private int active;
	private int FileId;
	private int UpdateMops;
	private int UpdateMnsn;
	private String ManualTrackingNumber;
	public int getTrackingId() {
		return TrackingId;
	}
	public void setTrackingId(int trackingId) {
		TrackingId = trackingId;
	}
	public String getGersInvoice() {
		return GersInvoice;
	}
	public void setGersInvoice(String gersInvoice) {
		GersInvoice = gersInvoice;
	}
	public int getOrderNumber() {
		return OrderNumber;
	}
	public void setOrderNumber(int orderNumber) {
		OrderNumber = orderNumber;
	}
	public String getTrackingNumber() {
		return TrackingNumber;
	}
	public void setTrackingNumber(String trackingNumber) {
		TrackingNumber = trackingNumber;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public String getCreatedBy() {
		return CreatedBy;
	}
	public void setCreatedBy(String createdBy) {
		CreatedBy = createdBy;
	}
	public String getCreatedOn() {
		return CreatedOn;
	}
	public void setCreatedOn(String createdOn) {
		CreatedOn = createdOn;
	}
	public String getUpdatedBy() {
		return UpdatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		UpdatedBy = updatedBy;
	}
	public String getUpdatedOn() {
		return UpdatedOn;
	}
	public void setUpdatedOn(String updatedOn) {
		UpdatedOn = updatedOn;
	}
	public String getCreatedFrom() {
		return CreatedFrom;
	}
	public void setCreatedFrom(String createdFrom) {
		CreatedFrom = createdFrom;
	}
	public int getActive() {
		return active;
	}
	public void setActive(int active) {
		this.active = active;
	}
	public int getFileId() {
		return FileId;
	}
	public void setFileId(int fileId) {
		FileId = fileId;
	}
	public int getUpdateMops() {
		return UpdateMops;
	}
	public void setUpdateMops(int updateMops) {
		UpdateMops = updateMops;
	}
	public int getUpdateMnsn() {
		return UpdateMnsn;
	}
	public void setUpdateMnsn(int updateMnsn) {
		UpdateMnsn = updateMnsn;
	}
	public String getManualTrackingNumber() {
		return ManualTrackingNumber;
	}
	public void setManualTrackingNumber(String manualTrackingNumber) {
		ManualTrackingNumber = manualTrackingNumber;
	}
}
