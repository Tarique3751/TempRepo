package corp.cartoys.MopsMiddlelayer.MopsProcess06.dto;

/**
 * The model object to parse the monsoon inventory json response.
 * @author jjude
 */
public class MnsnInventory {
	
	private String id;
	private String sku;
	private Double quantity;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public Double getQuantity() {
		return quantity;
	}
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
}
