package corp.cartoys.MopsMiddlelayer.MopsProcess01.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;

/**
 * The Data transfer object for gers_xml_cust table.
 * @author jjude
 */
@Entity
@Table(name = "gers_xml_cust")
@NamedQueries({
	@NamedQuery(
	name  = "GersXmlCust.GetRecordsForXml",
	query = "FROM GersXmlCust gxc WHERE gxc.CustCd = :CustCd"
	)
})
public class GersXmlCust {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int CustId;
	private int GersXmlId;
	private int CustCd;
	private String SrtCd;
	private String Title;
	private String Fname;
	private String Init;
	private String Lname;
	private String Addr1;
	private String Addr2;
	private String City;
	private String StCd;
	private String ZipCd;
	private String HomePhone;
	private String BusPhone;
	private String Ext;
	private String CorpName;
	private String CustTpCd;
	private String AltCustCd;
	private String EmailAddr;
	private String EmailAddrShipTo;
	public int getCustId() {
		return CustId;
	}
	public void setCustId(int custId) {
		CustId = custId;
	}
	public int getGersXmlId() {
		return GersXmlId;
	}
	public void setGersXmlId(int gersXmlId) {
		GersXmlId = gersXmlId;
	}
	public int getCustCd() {
		return CustCd;
	}
	public void setCustCd(int custCd) {
		CustCd = custCd;
	}
	public String getSrtCd() {
		return SrtCd;
	}
	public void setSrtCd(String srtCd) {
		SrtCd = srtCd;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public String getFname() {
		return Fname;
	}
	public void setFname(String fname) {
		Fname = fname;
	}
	public String getInit() {
		return Init;
	}
	public void setInit(String init) {
		Init = init;
	}
	public String getLname() {
		return Lname;
	}
	public void setLname(String lname) {
		Lname = lname;
	}
	public String getAddr1() {
		return Addr1;
	}
	public void setAddr1(String addr1) {
		Addr1 = addr1;
	}
	public String getAddr2() {
		return Addr2;
	}
	public void setAddr2(String addr2) {
		Addr2 = addr2;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getStCd() {
		return StCd;
	}
	public void setStCd(String stCd) {
		StCd = stCd;
	}
	public String getZipCd() {
		return ZipCd;
	}
	public void setZipCd(String zipCd) {
		ZipCd = zipCd;
	}
	public String getHomePhone() {
		return HomePhone;
	}
	public void setHomePhone(String homePhone) {
		HomePhone = homePhone;
	}
	public String getBusPhone() {
		return BusPhone;
	}
	public void setBusPhone(String busPhone) {
		BusPhone = busPhone;
	}
	public String getExt() {
		return Ext;
	}
	public void setExt(String ext) {
		Ext = ext;
	}
	public String getCorpName() {
		return CorpName;
	}
	public void setCorpName(String corpName) {
		CorpName = corpName;
	}
	public String getCustTpCd() {
		return CustTpCd;
	}
	public void setCustTpCd(String custTpCd) {
		CustTpCd = custTpCd;
	}
	public String getAltCustCd() {
		return AltCustCd;
	}
	public void setAltCustCd(String altCustCd) {
		AltCustCd = altCustCd;
	}
	public String getEmailAddr() {
		return EmailAddr;
	}
	public void setEmailAddr(String emailAddr) {
		EmailAddr = emailAddr;
	}
	public String getEmailAddrShipTo() {
		return EmailAddrShipTo;
	}
	public void setEmailAddrShipTo(String emailAddrShipTo) {
		EmailAddrShipTo = emailAddrShipTo;
	}
}
