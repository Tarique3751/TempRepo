package corp.cartoys.MopsMiddlelayer;

import java.io.File;


/**
 *Performs validation of the values in AppConfig file
 * @author jjude
 */
public class AppConfigValidator {
	
	/**
	 * Checks whether the directory exits.
	 * @param Path - String.
	 * @param configFilePath - String.
	 * @return Nothing.
	 */
	public static void checkFolderExists(String path, String configFilePath)
	{
		File dirPath = new File(path);
		if (!dirPath.exists())
		{
			System.err.println("Failed to launch the application.The folder \"" + path + "\" does not exist. Please check the application configurations in \"" + configFilePath + "\". Use only forward slash in path names.");
			//Quit the application
			System.exit(0);
		}
	}
	
	/**
	 * Checks whether the field is a valid digit.
	 * @param field - String.
	 * @param value - String.
	 * @param configFilePath - String.
	 * @return Nothing.
	 */
	public static void isNumeric(String field, String value, String configFilePath)
	{
		if (!(value.matches("[0-9]+")))
		{
			System.err.println("Failed to launch the application.The configuration field \"" + field + "\" should contain only digits. Please check the application configurations in \"" + configFilePath + "\".");
			//Quit the application
			System.exit(0);
		}
	}
}
