package corp.cartoys.MopsMiddlelayer.MopsProcess03;

import java.util.Date;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import corp.cartoys.MopsMiddlelayer.HibernateManager;
import corp.cartoys.MopsMiddlelayer.MopsProcess03.dto.MonsoonFileHeader;
import corp.cartoys.MopsMiddlelayer.MopsProcess03.dto.MonsoonOrderTracking;

/**
 * Parses the contents of the tracking files and inserts them to database.
 * @author jjude
 */
public class InsertCsvToDatabase {
	
	String timeStamp = new java.text.SimpleDateFormat("yyyy-MM-dd h:mm:ss").format(new Date());
	
	/**
	 * Function that parses the data of tracking file and inserts the tracking file details into database.
	 * @param body - String argument that accepts each row inside a tracking file.
	 * @return Nothing.
	 */
	public void processTrackingFile(String body) throws Exception{
		String[] fileContentArr = body.split(Process03Launcher.dataSplitDelimiter);
		int fileId;
		
		//Insertion into mnsn_file_header table
		MonsoonFileHeader mnsnFileHeader = new MonsoonFileHeader();
		mnsnFileHeader.setFileName(MopsFileProcessor.fileName);
		mnsnFileHeader.setCreatedOn(timeStamp);
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		
		MonsoonFileHeader mnsnFileHeaderFetchData = new MonsoonFileHeader();
		mnsnFileHeaderFetchData = null;
		Criteria criteria = session.createCriteria(MonsoonFileHeader.class);
		criteria.add(Restrictions.eq("FileName", MopsFileProcessor.fileName));
		mnsnFileHeaderFetchData = (MonsoonFileHeader) criteria.uniqueResult();
		//Insert into mnsn_file_header only if that file details are not already present.
		if(mnsnFileHeaderFetchData == null)
		{
			session.save(mnsnFileHeader);
			session.flush();
			fileId = mnsnFileHeader.getFileId();
			try
			{
				session.getTransaction().commit();
			}
			catch(Exception e)
			{
				session.getTransaction().rollback();
			}
		}
		else
		{
			fileId = mnsnFileHeaderFetchData.getFileId();
		}
		session.close();
		
		//Insertion into MonsoonOrderTracking
		MonsoonOrderTracking mnsnOrderTracking = new MonsoonOrderTracking();
		mnsnOrderTracking.setGersInvoice(fileContentArr[0].trim());
		mnsnOrderTracking.setOrderNumber(Integer.parseInt(fileContentArr[1].trim()));
		mnsnOrderTracking.setTrackingNumber(fileContentArr[2].trim());
		mnsnOrderTracking.setSku(fileContentArr[3].trim());
		mnsnOrderTracking.setQty(Integer.parseInt(fileContentArr[4].trim()));
		mnsnOrderTracking.setCreatedOn(timeStamp);
		mnsnOrderTracking.setFileId(fileId);
		mnsnOrderTracking.setUpdateMops(0);
		mnsnOrderTracking.setUpdateMnsn(0);
		
		session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();		
		session.save(mnsnOrderTracking);
		session.flush();
		try
		{
			session.getTransaction().commit();
		}
		catch(Exception e)
		{
			session.getTransaction().rollback();
		}
		session.close();
		
		//Update the ImportStatus and UpdateMops fields after the tracking details are inserted.
		CallUpdateMopsSp();
	}
	
	/**
	 * Function that sets ImportStatus as 2 and UpdateMops as 1 for the MonsoonOrderIds for which the tracking details are inserted into db.
	 * @param Nothing.
	 * @return Nothing.
	 */
	public void CallUpdateMopsSp()
	{
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		Query updateMopsSpQry = session.getNamedQuery("MonsoonOrderTracking.UpdateMopsSP");
		updateMopsSpQry.executeUpdate();
		session.close();
	}
}
