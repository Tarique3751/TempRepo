package corp.cartoys.MopsMiddlelayer.MopsProcess01.XmlModels;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SOLNSType", propOrder = { "SoLn" })
public class SOLNSType {
	@XmlElement(name = "SO_LN")
	protected List<SOLNType> SoLn;

	public List<SOLNType> getSoLn() {
		if (SoLn == null) {
			SoLn = new ArrayList<SOLNType>();
		}
		return this.SoLn;
	}

	public void setSoLn(ArrayList<SOLNType> soLn) {
		SoLn = soLn;
	}

	
}
