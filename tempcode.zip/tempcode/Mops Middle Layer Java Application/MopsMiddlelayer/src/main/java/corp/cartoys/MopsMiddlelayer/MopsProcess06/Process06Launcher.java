package corp.cartoys.MopsMiddlelayer.MopsProcess06;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import corp.cartoys.MopsMiddlelayer.AppConfigValidator;

/**
 * MopsProcess06 - Calls webservice, to fetch data from monsoon and insert into mysql table.
 * @author jjude
 */
public class Process06Launcher {
	public static Properties prop = new Properties();
	public static String webServicePollingTime;
	public static String webServiceUrl;
	static String configFilePath = "./MopsProcess06Config/AppConfig.properties";
	/**
	 * Read the AppConfig properties file and fetch the application configurations.
	 * @param Nothing.
	 * @return Nothing.
	 */
	public static void readAppConfigurations()
	{
		try
		{
			prop.load(new FileInputStream(configFilePath));
		}
		catch(IOException e)
		{
			System.out.println("Exception :" + e);
		}
		//Setting the app config variables
		webServicePollingTime = prop.getProperty("WebServicePollingTime");//Webservice polling interval
		webServiceUrl         = prop.getProperty("WebServiceUrl"); // Webservice url
		
		//Validate the configurations
		AppConfigValidator.isNumeric("WebServicePollingTime",webServicePollingTime,configFilePath);
	}
}
