package corp.cartoys.MopsMiddlelayer.MopsProcess02.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

/**
 * The Data transfer object for gers_weblink_status table.
 * @author jjude
 */
@Entity
@Table(name = "gers_weblink_status")
@NamedNativeQueries({
	@NamedNativeQuery(
	name        = "GersWeblinkStatus.UpdateMopsSP",
	query       = "CALL weblink_status_insert_update_mops_sp",
	resultClass = GersWeblinkStatus.class
	),
	@NamedNativeQuery(
	name        = "GersWeblinkStatus.UpdateMopsFbaSP",
	query       = "CALL weblink_status_insert_update_mops_fba_sp",
	resultClass = GersWeblinkStatus.class
	)
})
public class GersWeblinkStatus {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int weblink_id;
	private int order_number;
	private String gers_invoice;
	private String sku;
	private int qty;
	private String ord_srt_cd;
	private String del_doc_ln;
	private String cust_cd;
	private String error_cd;
	private String error_msg;
	private String err_table;
	private String stat;
	private String file_name;
	private int weblink_process_status;
	private String creation_time;
	private String update_time;
	private int file_id;
	private int UpdateMops;
	
	public int getWeblink_id() {
		return weblink_id;
	}
	public void setWeblink_id(int weblink_id) {
		this.weblink_id = weblink_id;
	}
	public int getOrder_number() {
		return order_number;
	}
	public void setOrder_number(int order_number) {
		this.order_number = order_number;
	}
	public String getGers_invoice() {
		return gers_invoice;
	}
	public void setGers_invoice(String gers_invoice) {
		this.gers_invoice = gers_invoice;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public String getOrd_srt_cd() {
		return ord_srt_cd;
	}
	public void setOrd_srt_cd(String ord_srt_cd) {
		this.ord_srt_cd = ord_srt_cd;
	}
	public String getDel_doc_ln() {
		return del_doc_ln;
	}
	public void setDel_doc_ln(String del_doc_ln) {
		this.del_doc_ln = del_doc_ln;
	}
	public String getCust_cd() {
		return cust_cd;
	}
	public void setCust_cd(String cust_cd) {
		this.cust_cd = cust_cd;
	}
	public String getError_cd() {
		return error_cd;
	}
	public void setError_cd(String error_cd) {
		this.error_cd = error_cd;
	}
	public String getError_msg() {
		return error_msg;
	}
	public void setError_msg(String error_msg) {
		this.error_msg = error_msg;
	}
	public String getErr_table() {
		return err_table;
	}
	public void setErr_table(String err_table) {
		this.err_table = err_table;
	}
	public String getStat() {
		return stat;
	}
	public void setStat(String stat) {
		this.stat = stat;
	}
	public String getFile_name() {
		return file_name;
	}
	public void setFile_name(String file_name) {
		this.file_name = file_name;
	}
	public int getWeblink_process_status() {
		return weblink_process_status;
	}
	public void setWeblink_process_status(int weblink_process_status) {
		this.weblink_process_status = weblink_process_status;
	}
	public String getCreation_time() {
		return creation_time;
	}
	public void setCreation_time(String creation_time) {
		this.creation_time = creation_time;
	}
	public String getUpdate_time() {
		return update_time;
	}
	public void setUpdate_time(String update_time) {
		this.update_time = update_time;
	}
	public int getFile_id() {
		return file_id;
	}
	public void setFile_id(int file_id) {
		this.file_id = file_id;
	}
	public int getUpdateMops() {
		return UpdateMops;
	}
	public void setUpdateMops(int updateMops) {
		UpdateMops = updateMops;
	}
}
