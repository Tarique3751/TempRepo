package corp.cartoys.MopsMiddlelayer.MopsProcess01.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

/**
 * The Data transfer object for mnsn_order_for_weblink table.
 * @author jjude
 */
@Entity
@Table(name = "mnsn_order_for_weblink")
@NamedNativeQueries({
	@NamedNativeQuery(
	name        = "MnsnOrderForWeblink.OrderDataNormalizationSP",
	query       = "CALL order_data_normalization_test", // CHANGE THIS TO CORRECT NORMALIZATION SP
	resultClass = MnsnOrderForWeblink.class
	)
})
public class MnsnOrderForWeblink {
	@Id
	private int MonsoonOrderId;
	private String OrderStatus;
	private String MarketName;
	private String MarketOrderId;
	private String ShipMethod;
	private String OrderDate;
	private String ShipDate;
	private String OrderNote;
	private String TrackingNumber;
	private String CarrierCode;
	private String BuyerEmail;
	private String BuyerName;
	private String ShipToName;
	private String Address1;
	private String Address2;
	private String City;
	private String State;
	private String PostalCode;
	private String Country;
	private String BuyerPhoneNumber;
	private String SKU;
	private String ASIN;
	private String UPC;
	private String Conditions;
	private String SkuOnMarket;
	private String LocatorCode;
	private int OrderedQuantity;
	private int ShippedQuantity;
	private String Price;
	private String ShippingFee;
	private String MarketPrice;
	private String MarketShippingFee;
	private String RefundAmount;
	private String MarketRefundAmount;
	private String Tax;
	private String ShippingTax;
	private String MarketOrderItemId;
	private String FulfillmentType;
	private String ManufacturerPartNum;
	private String ShippingSurcharge;
	private String PromotionalShippingDiscount;
	private String RowNumber;
	
	public int getMonsoonOrderId() {
		return MonsoonOrderId;
	}
	public void setMonsoonOrderId(int monsoonOrderId) {
		MonsoonOrderId = monsoonOrderId;
	}
	public String getOrderStatus() {
		return OrderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		OrderStatus = orderStatus;
	}
	public String getMarketName() {
		return MarketName;
	}
	public void setMarketName(String marketName) {
		MarketName = marketName;
	}
	public String getMarketOrderId() {
		return MarketOrderId;
	}
	public void setMarketOrderId(String marketOrderId) {
		MarketOrderId = marketOrderId;
	}
	public String getShipMethod() {
		return ShipMethod;
	}
	public void setShipMethod(String shipMethod) {
		ShipMethod = shipMethod;
	}
	public String getOrderDate() {
		return OrderDate;
	}
	public void setOrderDate(String orderDate) {
		OrderDate = orderDate;
	}
	public String getShipDate() {
		return ShipDate;
	}
	public void setShipDate(String shipDate) {
		ShipDate = shipDate;
	}
	public String getOrderNote() {
		return OrderNote;
	}
	public void setOrderNote(String orderNote) {
		OrderNote = orderNote;
	}
	public String getTrackingNumber() {
		return TrackingNumber;
	}
	public void setTrackingNumber(String trackingNumber) {
		TrackingNumber = trackingNumber;
	}
	public String getCarrierCode() {
		return CarrierCode;
	}
	public void setCarrierCode(String carrierCode) {
		CarrierCode = carrierCode;
	}
	public String getBuyerEmail() {
		return BuyerEmail;
	}
	public void setBuyerEmail(String buyerEmail) {
		BuyerEmail = buyerEmail;
	}
	public String getBuyerName() {
		return BuyerName;
	}
	public void setBuyerName(String buyerName) {
		BuyerName = buyerName;
	}
	public String getShipToName() {
		return ShipToName;
	}
	public void setShipToName(String shipToName) {
		ShipToName = shipToName;
	}
	public String getAddress1() {
		return Address1;
	}
	public void setAddress1(String address1) {
		Address1 = address1;
	}
	public String getAddress2() {
		return Address2;
	}
	public void setAddress2(String address2) {
		Address2 = address2;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getPostalCode() {
		return PostalCode;
	}
	public void setPostalCode(String postalCode) {
		PostalCode = postalCode;
	}
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
	public String getBuyerPhoneNumber() {
		return BuyerPhoneNumber;
	}
	public void setBuyerPhoneNumber(String buyerPhoneNumber) {
		BuyerPhoneNumber = buyerPhoneNumber;
	}
	public String getSKU() {
		return SKU;
	}
	public void setSKU(String sKU) {
		SKU = sKU;
	}
	public String getASIN() {
		return ASIN;
	}
	public void setASIN(String aSIN) {
		ASIN = aSIN;
	}
	public String getUPC() {
		return UPC;
	}
	public void setUPC(String uPC) {
		UPC = uPC;
	}
	public String getConditions() {
		return Conditions;
	}
	public void setConditions(String conditions) {
		Conditions = conditions;
	}
	public String getSkuOnMarket() {
		return SkuOnMarket;
	}
	public void setSkuOnMarket(String skuOnMarket) {
		SkuOnMarket = skuOnMarket;
	}
	public String getLocatorCode() {
		return LocatorCode;
	}
	public void setLocatorCode(String locatorCode) {
		LocatorCode = locatorCode;
	}
	public int getOrderedQuantity() {
		return OrderedQuantity;
	}
	public void setOrderedQuantity(int orderedQuantity) {
		OrderedQuantity = orderedQuantity;
	}
	public int getShippedQuantity() {
		return ShippedQuantity;
	}
	public void setShippedQuantity(int shippedQuantity) {
		ShippedQuantity = shippedQuantity;
	}
	public String getPrice() {
		return Price;
	}
	public void setPrice(String price) {
		Price = price;
	}
	public String getShippingFee() {
		return ShippingFee;
	}
	public void setShippingFee(String shippingFee) {
		ShippingFee = shippingFee;
	}
	public String getMarketPrice() {
		return MarketPrice;
	}
	public void setMarketPrice(String marketPrice) {
		MarketPrice = marketPrice;
	}
	public String getMarketShippingFee() {
		return MarketShippingFee;
	}
	public void setMarketShippingFee(String marketShippingFee) {
		MarketShippingFee = marketShippingFee;
	}
	public String getRefundAmount() {
		return RefundAmount;
	}
	public void setRefundAmount(String refundAmount) {
		RefundAmount = refundAmount;
	}
	public String getMarketRefundAmount() {
		return MarketRefundAmount;
	}
	public void setMarketRefundAmount(String marketRefundAmount) {
		MarketRefundAmount = marketRefundAmount;
	}
	public String getTax() {
		return Tax;
	}
	public void setTax(String tax) {
		Tax = tax;
	}
	public String getShippingTax() {
		return ShippingTax;
	}
	public void setShippingTax(String shippingTax) {
		ShippingTax = shippingTax;
	}
	public String getMarketOrderItemId() {
		return MarketOrderItemId;
	}
	public void setMarketOrderItemId(String marketOrderItemId) {
		MarketOrderItemId = marketOrderItemId;
	}
	public String getFulfillmentType() {
		return FulfillmentType;
	}
	public void setFulfillmentType(String fulfillmentType) {
		FulfillmentType = fulfillmentType;
	}
	public String getManufacturerPartNum() {
		return ManufacturerPartNum;
	}
	public void setManufacturerPartNum(String manufacturerPartNum) {
		ManufacturerPartNum = manufacturerPartNum;
	}
	public String getShippingSurcharge() {
		return ShippingSurcharge;
	}
	public void setShippingSurcharge(String shippingSurcharge) {
		ShippingSurcharge = shippingSurcharge;
	}
	public String getPromotionalShippingDiscount() {
		return PromotionalShippingDiscount;
	}
	public void setPromotionalShippingDiscount(String promotionalShippingDiscount) {
		PromotionalShippingDiscount = promotionalShippingDiscount;
	}
	public String getRowNumber() {
		return RowNumber;
	}
	public void setRowNumber(String rowNumber) {
		RowNumber = rowNumber;
	}
}
