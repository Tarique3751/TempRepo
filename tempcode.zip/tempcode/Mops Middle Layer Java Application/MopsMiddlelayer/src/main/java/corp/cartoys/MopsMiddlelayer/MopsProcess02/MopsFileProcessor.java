package corp.cartoys.MopsMiddlelayer.MopsProcess02;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.hibernate.Query;
import org.hibernate.Session;

import corp.cartoys.MopsMiddlelayer.HibernateManager;
import corp.cartoys.MopsMiddlelayer.MopsProcess02.dto.GersWeblinkStatus;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * Log the files that were processed and check whether the processed files are valid gers pass/fail files.
 * @author jjude
 */
public class MopsFileProcessor implements Processor {
	
	String newLineChar = System.getProperty("line.separator"); //To get the newline character of corresponding platform
	public static String fileName;
	
	static Logger log = Logger.getLogger(MopsFileProcessor.class.getName());
	
	public void process(Exchange exchange) throws Exception {
		String fileType    = "";
		String fileStatus  = "";
		String filePath    = exchange.getIn().getBody().toString();
		filePath           = filePath.substring(filePath.indexOf("[") + 1, filePath.indexOf("]"));
		String fileContent = exchange.getIn().getBody(String.class);
		Path p             = Paths.get(filePath);
		fileName           = p.getFileName().toString();
		
		try
		{
			String[] fileContentArr  = fileContent.split("\n");
			String headerContents= fileContentArr[0].trim();
			if(fileName.toLowerCase().contains("pass"))
			{
				String validPassFileHeader = "order_number" + Process02Launcher.dataSplitDelimiter + "gers_invoice" + Process02Launcher.dataSplitDelimiter + "sku" + Process02Launcher.dataSplitDelimiter + "qty" + Process02Launcher.dataSplitDelimiter + "ord_srt_cd" + Process02Launcher.dataSplitDelimiter + "del_doc_ln" + Process02Launcher.dataSplitDelimiter + "cust_cd" + Process02Launcher.dataSplitDelimiter + "stat";
				fileType = "pass";
				if(!headerContents.equalsIgnoreCase(validPassFileHeader))
				{
					fileType = "invalid";
				}	
			}
			else if(fileName.toLowerCase().contains("fail"))
			{
				String validFailFileHeader = "order_number" + Process02Launcher.dataSplitDelimiter + "gers_invoice" + Process02Launcher.dataSplitDelimiter + "sku" + Process02Launcher.dataSplitDelimiter + "qty" + Process02Launcher.dataSplitDelimiter + "error_cd" + Process02Launcher.dataSplitDelimiter + "error_msg" + Process02Launcher.dataSplitDelimiter + "err_table" + Process02Launcher.dataSplitDelimiter + "stat";
				fileType = "fail";
				if(!headerContents.equalsIgnoreCase(validFailFileHeader))
				{
					fileType = "invalid";
				}
			}
			else
			{
				fileType = "invalid";
			}
		}
		catch(Exception e)
		{
			fileType = "invalid";
		}
				
		//Check if the pass or fail file was already processed.
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		Query query = session.getNamedQuery("Process02MonsoonFileHeader.CheckFileNameExists").setString("FileName", fileName);
		List<GersWeblinkStatus> resultsList = query.list();
		session.close();
		if(!resultsList.isEmpty())
		{
			fileType = "already_processed";
		}
		
		if(fileType.equalsIgnoreCase("pass"))
		{
			fileStatus = "Pass file was successfully processed.";
		}
		else if(fileType.equalsIgnoreCase("fail"))
		{
			fileStatus = "Fail file was successfully processed.";
		}
		else if(fileType.equalsIgnoreCase("already_processed"))
		{
			fileStatus = "File was already processed.";
		}
		else
		{
			fileStatus = "Invalid File. File has been moved to error directory.";
		}
		
		//Creating log
		String logMessage = newLineChar
				+ "Processed File - " + fileName + newLineChar
				+ "Processed File Path - " + filePath + newLineChar
				+ "Processed File Content - " + newLineChar + fileContent + newLineChar
				+ "Processed File Status - " + fileStatus + newLineChar
				+ newLineChar;
		log.info(logMessage);
				
		//Pass the file type in header of the message exchange
		Message newMessage = exchange.getIn(); 
		newMessage.setHeader("FileType",fileType);
	}

}
