package corp.cartoys.MopsMiddlelayer.MopsProcess01;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import corp.cartoys.MopsMiddlelayer.HibernateManager;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.dto.MnsnOrderDetails;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.dto.MnsnOrderForWeblink;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.dto.MnsnOrderHeader;

import org.apache.commons.collections.MultiMap;
import org.apache.commons.collections.map.MultiValueMap;

/**
 * Parses the data from the order file and inserts them into the temporary table mnsn_order_for_weblink.
 * @author jjude
 */
public class DbInsertion {
	
	// Header details fields
	public MnsnOrderHeader moh;
	
	//Order details fields
	public MnsnOrderDetails mod;
	
	public static MultiMap monsoonOrderSKUs = new MultiValueMap();
	
	public DbInsertion()
	{
		
	}
	
	/**
	 * Constructor that assignes the data from order file into member variables.
	 * @param body - String arguments that takes each row of the order file.
	 * @return Nothing.
	 */
	public DbInsertion(String body)
	{
		String[] filecontentArray = body.split(Process01Launcher.dataSplitDelimiter);
		//The hashmap that stores all the SKUs for a corresponding monsoon order
		monsoonOrderSKUs.put(filecontentArray[0].trim(), filecontentArray[20].trim());
		
		//Function to handle MonsoonOrderId that was already inserted into the database.
		//Commented this out since if order with previously inserted MonsoonOrderId comes business rules need not be re-applied.
		//updateExistingOrder(Integer.parseInt(filecontentArray[0]));
		
		this.moh = new MnsnOrderHeader();
		if((filecontentArray[0]).length() == 0 || (filecontentArray[0]).trim().equals(""))
		{
			filecontentArray[0] = "0";
		}
		this.moh.setMonsoonOrderId(Integer.parseInt(filecontentArray[0]));
		this.moh.setOrderStatus(filecontentArray[1].trim());
		this.moh.setMarketName(filecontentArray[2].trim());
		this.moh.setMarketOrderId(filecontentArray[3].trim());
		this.moh.setShipMethod(filecontentArray[4].trim());
		this.moh.setOrderDate(filecontentArray[5].trim());
		this.moh.setShipDate(filecontentArray[6].trim());
		this.moh.setOrderNote(filecontentArray[7].trim());
		this.moh.setTrackingNumber(filecontentArray[8].trim());
		this.moh.setCarrierCode(filecontentArray[9].trim());
		this.moh.setBuyerEmail(filecontentArray[10].trim());
		this.moh.setBuyerName(filecontentArray[11].trim());
		this.moh.setShipToName(filecontentArray[12].trim());
		this.moh.setAddress1(filecontentArray[13].trim());
		this.moh.setAddress2(filecontentArray[14].trim());
		this.moh.setCity(filecontentArray[15].trim());
		this.moh.setState(filecontentArray[16].trim());
		this.moh.setPostalCode(filecontentArray[17].trim());
		this.moh.setCountry(filecontentArray[18].trim());
		this.moh.setBuyerPhoneNumber(filecontentArray[19].trim());
		
		this.mod = new MnsnOrderDetails();
		this.mod.setSKU(filecontentArray[20].trim());
		this.mod.setASIN(filecontentArray[21].trim());
		this.mod.setUPC(filecontentArray[22].trim());
		this.mod.setConditions(filecontentArray[23].trim());
		this.mod.setSkuOnMarket(filecontentArray[24].trim());
		this.mod.setLocatorCode(filecontentArray[25].trim());
		if((filecontentArray[26]).length() == 0 || (filecontentArray[26]).trim().equals(""))
		{
			filecontentArray[26] = "0";
		}
		this.mod.setOrderedQuantity(Integer.parseInt(filecontentArray[26]));
		if((filecontentArray[27]).length() == 0 || (filecontentArray[27]).trim().equals(""))
		{
			filecontentArray[27] = "0";
		}
		this.mod.setShippedQuantity(Integer.parseInt(filecontentArray[27]));
		this.mod.setPrice(filecontentArray[28].trim());
		this.mod.setShippingFee(filecontentArray[29].trim());
		this.mod.setMarketPrice(filecontentArray[30].trim());
		this.mod.setMarketShippingFee(filecontentArray[31].trim());
		this.mod.setRefundAmount(filecontentArray[32].trim());
		this.mod.setMarketRefundAmount(filecontentArray[33].trim());
		this.mod.setTax(filecontentArray[34].trim());
		this.mod.setShippingTax(filecontentArray[35].trim());
		this.mod.setMarketOrderItemId(filecontentArray[36].trim());
		this.mod.setFulfillmentType(filecontentArray[37].trim());
		this.mod.setManufacturerPartNum(filecontentArray[38].trim());
		this.mod.setShippingSurcharge(filecontentArray[39].trim());
		if((filecontentArray[40]).length() == 0 || (filecontentArray[40]).trim().equals(""))
		{
			filecontentArray[40] = "0.00";
		}
		this.mod.setPromotionalShippingDiscount(Double.parseDouble(filecontentArray[40]));
	}
	
	/**
	 * Function that checks whether the MonsoonOrderId in the order file already exists in the database. If so update the ImportStatus as 0 and AutomaticImportStatus as 1, so that the business rules gets re-applied for the new order data. 
	 * @param monsoonOrderId - Int.
	 * @return Nothing.
	 */
	public void updateExistingOrder(int monsoonOrderId)
	{
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		
		MnsnOrderHeader mnsnOrderHeader = new MnsnOrderHeader();
		mnsnOrderHeader                 = null;
		
		Criteria criteria = session.createCriteria(MnsnOrderHeader.class);
		criteria.add(Restrictions.eq("MonsoonOrderId", monsoonOrderId));
		mnsnOrderHeader = (MnsnOrderHeader) criteria.uniqueResult();
		
		if(mnsnOrderHeader != null)
		{
			Query statusFlagsQry = session.getNamedQuery("MnsnOrderHeader.UpdateImportStatusAndAutomaticImportStatusQry").setLong("ImportStatus", 0).setLong("AutomaticImportStatus", 1).setLong("MonsoonOrderId", monsoonOrderId);
			statusFlagsQry.executeUpdate();
		}
		
		session.close();

	}
	
	/**
	 * Function that inserts the data from order file into the database.
	 * @param body - String arguments that takes each row of the order file.
	 * @return Nothing.
	 */
	public void insertData(String body) {
		
		DbInsertion DbInsertionObj = new DbInsertion(body);
		
		//Insert into table mnsn_order_for_weblink.
		MnsnOrderForWeblink MnsnOrderForWeblinkObj = new MnsnOrderForWeblink();
		MnsnOrderForWeblinkObj.setMonsoonOrderId(DbInsertionObj.moh.getMonsoonOrderId());
		MnsnOrderForWeblinkObj.setOrderStatus(DbInsertionObj.moh.getOrderStatus());
		MnsnOrderForWeblinkObj.setMarketName(DbInsertionObj.moh.getMarketName());
		MnsnOrderForWeblinkObj.setMarketOrderId(DbInsertionObj.moh.getMarketOrderId());
		MnsnOrderForWeblinkObj.setShipMethod(DbInsertionObj.moh.getShipMethod());
		MnsnOrderForWeblinkObj.setOrderDate(DbInsertionObj.moh.getOrderDate());
		MnsnOrderForWeblinkObj.setShipDate(DbInsertionObj.moh.getShipDate());
		MnsnOrderForWeblinkObj.setOrderNote(DbInsertionObj.moh.getOrderNote());
		MnsnOrderForWeblinkObj.setTrackingNumber(DbInsertionObj.moh.getTrackingNumber());
		MnsnOrderForWeblinkObj.setCarrierCode(DbInsertionObj.moh.getCarrierCode());
		MnsnOrderForWeblinkObj.setBuyerEmail(DbInsertionObj.moh.getBuyerEmail());
		MnsnOrderForWeblinkObj.setBuyerName(DbInsertionObj.moh.getBuyerName());
		MnsnOrderForWeblinkObj.setShipToName(DbInsertionObj.moh.getShipToName());
		MnsnOrderForWeblinkObj.setAddress1(DbInsertionObj.moh.getAddress1());
		MnsnOrderForWeblinkObj.setAddress2(DbInsertionObj.moh.getAddress2());
		MnsnOrderForWeblinkObj.setCity(DbInsertionObj.moh.getCity());
		MnsnOrderForWeblinkObj.setState(DbInsertionObj.moh.getState());
		MnsnOrderForWeblinkObj.setPostalCode(DbInsertionObj.moh.getPostalCode());
		MnsnOrderForWeblinkObj.setCountry(DbInsertionObj.moh.getCountry());
		MnsnOrderForWeblinkObj.setBuyerPhoneNumber(DbInsertionObj.moh.getBuyerPhoneNumber());
		
		MnsnOrderForWeblinkObj.setSKU(DbInsertionObj.mod.getSKU());
		MnsnOrderForWeblinkObj.setASIN(DbInsertionObj.mod.getASIN());
		MnsnOrderForWeblinkObj.setUPC(DbInsertionObj.mod.getUPC());
		MnsnOrderForWeblinkObj.setConditions(DbInsertionObj.mod.getConditions());
		MnsnOrderForWeblinkObj.setSkuOnMarket(DbInsertionObj.mod.getSkuOnMarket());
		MnsnOrderForWeblinkObj.setLocatorCode(DbInsertionObj.mod.getLocatorCode());
		MnsnOrderForWeblinkObj.setOrderedQuantity(DbInsertionObj.mod.getOrderedQuantity());
		MnsnOrderForWeblinkObj.setShippedQuantity(DbInsertionObj.mod.getShippedQuantity());
		MnsnOrderForWeblinkObj.setPrice(DbInsertionObj.mod.getPrice());
		MnsnOrderForWeblinkObj.setShippingFee(DbInsertionObj.mod.getShippingFee());
		MnsnOrderForWeblinkObj.setMarketPrice(DbInsertionObj.mod.getMarketPrice());
		MnsnOrderForWeblinkObj.setMarketShippingFee(DbInsertionObj.mod.getMarketShippingFee());
		MnsnOrderForWeblinkObj.setRefundAmount(DbInsertionObj.mod.getRefundAmount());
		MnsnOrderForWeblinkObj.setMarketRefundAmount(DbInsertionObj.mod.getMarketRefundAmount());
		MnsnOrderForWeblinkObj.setTax(DbInsertionObj.mod.getTax());
		MnsnOrderForWeblinkObj.setShippingTax(DbInsertionObj.mod.getShippingTax());
		MnsnOrderForWeblinkObj.setMarketOrderItemId(DbInsertionObj.mod.getMarketOrderItemId());
		MnsnOrderForWeblinkObj.setFulfillmentType(DbInsertionObj.mod.getFulfillmentType());
		MnsnOrderForWeblinkObj.setManufacturerPartNum(DbInsertionObj.mod.getManufacturerPartNum());
		MnsnOrderForWeblinkObj.setShippingSurcharge(DbInsertionObj.mod.getShippingSurcharge());
		MnsnOrderForWeblinkObj.setPromotionalShippingDiscount(DbInsertionObj.mod.getPromotionalShippingDiscount().toString());
		
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();		
		session.save(MnsnOrderForWeblinkObj);
		session.flush();
		try
		{
			session.getTransaction().commit();
		}
		catch(Exception e)
		{
			session.getTransaction().rollback();
		}
		session.close();
	}
	
	//Getters and setters for the member variables.
	public MnsnOrderHeader getMoh() {
		if (moh == null) {
			moh = new MnsnOrderHeader();
		}
		return this.moh;
	}

	public void setMoh(MnsnOrderHeader moh) {
		this.moh = moh;
	}

	public MnsnOrderDetails getMod() {
		if (mod == null) {
			mod = new MnsnOrderDetails();
		}
		return this.mod;
	}

	public void setMod(MnsnOrderDetails mod) {
		this.mod = mod;
	}
}