package corp.cartoys.MopsMiddlelayer.MopsProcess05.dto;

/**
 * The model object to parse the gers inventory json response.
 * @author jjude
 */
public class GersInventory {
	
	private String id;
	private String monsoonop;
	private String sku;
	private String quantity;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMonsoonop() {
		return monsoonop;
	}
	public void setMonsoonop(String monsoonop) {
		this.monsoonop = monsoonop;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
}
