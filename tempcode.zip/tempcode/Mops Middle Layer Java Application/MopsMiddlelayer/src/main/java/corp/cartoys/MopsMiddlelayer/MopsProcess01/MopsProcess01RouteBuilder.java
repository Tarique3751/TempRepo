package corp.cartoys.MopsMiddlelayer.MopsProcess01;

import org.apache.log4j.Logger;

/**
 * Camel route that reads the order files, splits the data into header and details and generates the gers xml.
 * @author jjude
 */
public class MopsProcess01RouteBuilder extends org.apache.camel.builder.RouteBuilder{
	String newLineChar = System.getProperty("line.separator"); //To get the newline character of corresponding platform
	static Logger log  = Logger.getLogger(MopsProcess01RouteBuilder.class.getName());
	
	final int CAMEL_AGGREGATOR_COMPLETIONTIMEOUT = 1500;
	final int CAMEL_AGGREGATOR_COMPLETIONSIZE    = 4000;
	
	public void configure() throws Exception
	{
		try
		{
			//Camel Route 1 : Pick up file and check whether its valid. If invalid file move it to error directory.
			from("file:"+Process01Launcher.inputFolderPath+"?readLock=changed&move=./processed&include="+Process01Launcher.acceptedFileListRegExp).
			process(new MopsLogProcessor()).
			choice().
				when(header("ValidOrderFile").isEqualTo(1)).
					to("direct:ValidOrderQueue").
				otherwise().
					to("file:" + Process01Launcher.inputFolderPath + "/invalid").
			end();
			
			//Camel Route 2 : Pick up order file and slice each tsv row using splitter.
			from("direct:ValidOrderQueue").
			split().tokenize("\n",1). //Use camel splitter to forward each tsv row sepeartely to direct:processLineForDB.
			choice().
				when(simple("${property.CamelSplitIndex} > 0")). //Avoid the tsv headers.
					to("direct:Process01QueueForDB").
			end();
			
			//Camel Route 3 : Insert the incoming tsv row into DB and generate XML.
			from("direct:Process01QueueForDB").
			doTry().
				bean(new DbInsertion(),"insertData"). //Insert data into temporary table mnsn_order_for_weblink.
			doCatch(Exception.class). //Exception may occur if the size of data read from file is greater than db column size for that corresponding field.
				process(new InvalidDataLogger()). //Handles SQL exception and ArrayOutOfBound exceptions for a row in the order file. Exception occured when a row was processed ,hence it was not inserted in to DB.
			doFinally().
				setHeader("insert_success", constant("insert_success")).
				aggregate(header("insert_success"), new StringBodyAggregator()). //Aggregate all tsv rows so that Normalization SP and GenerateXML function is called only after DB insertion is complete for all tsv rows.
				completionSize(CAMEL_AGGREGATOR_COMPLETIONTIMEOUT).
				completionTimeout(CAMEL_AGGREGATOR_COMPLETIONSIZE).
				bean(new OrderDataNormalization(),"normalizeOrderData"). //Split the data into header and details.
				bean(new ResourceLock(),"checkLock"). //Check lock on on ExtractNormalizedData and XmlGenerator beans.
				choice().
					when(body().contains(0)). // Proceed only if lock is not set.
						bean(new ResourceLock(),"setLock"). // Lock the beans  ExtractNormalizedData and XmlGenerator , so that Camel Route 4 can't use them.
						bean(new ExtractNormalizedData(),"fetchNormalizedRecords"). //Fetch all records for which business rules need to be applied.
						bean(new XmlGenerator(),"generateXml"). //Generate XML for records
						bean(new ResourceLock(),"releaseLock"). // Release the locks on ExtractNormalizedData and XmlGenerator beans.
				end().
			end();
			
			
			//Camel Route 4 : Polling the DB to check if xml should be generated for any record.
			from("timer://foo?period=" + Process01Launcher.dBPollingTime).//Checks the db frequently based on Polling interval time specified in config file.
			bean(new ResourceLock(),"checkLock").//Check lock on on ExtractNormalizedData and XmlGenerator beans.
			choice().
				when(body().contains(0)). // Proceed only if lock is not set.
					doTry().
						bean(new ResourceLock(),"setLock"). // Lock the beans  ExtractNormalizedData and XmlGenerator , so that Camel Route 3 can't use them.
						bean(new ExtractNormalizedData(),"fetchNormalizedRecords").
						bean(new XmlGenerator(),"generateXml").
						bean(new ResourceLock(),"releaseLock"). // Release the locks on ExtractNormalizedData and XmlGenerator beans.
					doCatch(Exception.class).
					end().
			end().
			to("mock:result");
		}
		catch(Exception e)
		{
			String logMessage = newLineChar
					+ "Something went wrong.Please ensure that the input and output folder paths are configured correctly in AppConfig.properties file." + newLineChar
					+ "Exception : " + e + newLineChar
					+ newLineChar;
			log.info(logMessage);
		} 
	}
}