package corp.cartoys.MopsMiddlelayer.MopsProcess01;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;

import corp.cartoys.MopsMiddlelayer.HibernateManager;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.XmlModels.CUSTType;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.XmlModels.ObjectFactory;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.XmlModels.SOLNSType;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.XmlModels.SOLNType;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.XmlModels.SOType;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.dto.GersXml;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.dto.GersXmlCust;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.dto.GersXmlSolns;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.dto.MnsnOrderHeader;

/**
 * Generates Gers XML file from records in database.
 * @author jjude
 */
public class XmlGenerator {
	
	public static int gersXmlId;
	public static int trnId;
	public static String originCd;
	public static String causeCd;
	public static String empCdOp;
	public static String empCdKeyer;
	public static String finCustCd;
	public static String shipToStCd;
	public static String shipToZoneCd;
	public static String taxCd;
	public static String ordTpCd;
	public static String ordSrtCd;
	public static String soStoreCd;
	public static String puDelStoreCd;
	public static String soEmpSlspCd1;
	public static String soWrDt;
	public static String shipToTitle;
	public static String shipToFname;
	public static String shipToLname;
	public static String shipToAddr1;
	public static String shipToAddr2;
	public static String shipToZipCd;
	public static String shipToHphone;
	public static String shipToBphone;
	public static String shipToExt;
	public static String shipToCity;
	public static String shipToCorp;
	public static String pctOfSale1;
	public static String puDel;
	public static String puDelDt;
	public static String delChg;
	public static String setupChg;
	public static String taxChg;
	public static String origDelDocNum;
	public static String origFiAmt;
	public static String approvalCd;
	public static String requestedFiAmount;
	public static String altDocNum;
	public static String altCustCd;
	
	public static int soLnsId;
	public static int monsoonOrderId;
	public static String itemCd;
	public static String storeCd;
	public static String locCd;
	public static String serNum;
	public static String unitPrc;
	public static int qty;
	public static String soLnCmnt;
	public static String activationDt;
	public static String activationPhone;
	public static String shipGroup;
	
	public static int custId;
	public static int custCd;
	public static String srtCd;
	public static String title;
	public static String fname;
	public static String init;
	public static String lname;
	public static String addr1;
	public static String addr2;
	public static String city;
	public static String stCd;
	public static String zipCd;
	public static String homePhone;
	public static String busPhone;
	public static String ext;
	public static String corpName;
	public static String custTpCd;
	public static String cust_AltCustCd;
	public static String emailAddr;
	public static String emailAddrShipTo;
	
	public int STATUS_ID_FOR_XML_GENERATION        = Integer.parseInt(Process01Launcher.STATUS_ID_FOR_XML_GENERATION);
	public int STATUS_ID_FOR_XML_GENERATED_RECORDS = Integer.parseInt(Process01Launcher.STATUS_ID_FOR_XML_GENERATED_RECORDS);
	
	String newLineChar = System.getProperty("line.separator"); //To get the newline character of corresponding platform
	static Logger log  = Logger.getLogger(XmlGenerator.class.getName());  
	String logMessage  = "";
	
	 /**
	 * Generates the Gers XML files from the gers schema. 
	 * @param Nothing.
	 * @return Nothing.
	 */
	public void generateXml() throws JAXBException{
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		
		Query query                       = session.getNamedQuery("MnsnOrderHeader.GetRecordsForXml").setLong("ImportStatus", STATUS_ID_FOR_XML_GENERATION).setString("AutomaticImportStatus", "1");
		List<MnsnOrderHeader> resultsList = query.list();
		
		String XML;
		String timeStamp = new java.text.SimpleDateFormat("yyyy-MM-dd h:mm:ss").format(new Date());
		
		if(!resultsList.isEmpty())//Generate XML for only those records with ImportStatus = 44 (Ready to sent to Gers) and AutomaticImportStatus = 1
		{
			for (MnsnOrderHeader res : resultsList) 
			{
				
				Session gersXmlSession = HibernateManager.getSessionFactory().openSession();
				gersXmlSession.beginTransaction();
				
				Query gersXmlQuery        = gersXmlSession.getNamedQuery("GersXml.GetRecordsForXml").setLong("TrnId", res.getMonsoonOrderId());
				List<GersXml> gersXmlList = gersXmlQuery.list();
				gersXmlId                 = gersXmlList.get(0).getGersXmlId();
				trnId                     = gersXmlList.get(0).getTrnId();
				originCd                  = gersXmlList.get(0).getOriginCd().toUpperCase();
				causeCd                   = gersXmlList.get(0).getCauseCd().toUpperCase();
				empCdOp                   = gersXmlList.get(0).getEmpCdOp().toUpperCase();
				empCdKeyer                = gersXmlList.get(0).getEmpCdKeyer().toUpperCase();
				finCustCd                 = gersXmlList.get(0).getFinCustCd().toUpperCase();
				shipToStCd                = gersXmlList.get(0).getShipToStCd().toUpperCase();
				shipToZoneCd              = gersXmlList.get(0).getShipToZoneCd().toUpperCase();
				taxCd                     = gersXmlList.get(0).getTaxCd().toUpperCase();
				ordTpCd                   = gersXmlList.get(0).getOrdTpCd().toUpperCase();
				ordSrtCd                  = gersXmlList.get(0).getOrdSrtCd().toUpperCase();
				soStoreCd                 = gersXmlList.get(0).getSoStoreCd().toUpperCase();
				puDelStoreCd              = gersXmlList.get(0).getPuDelStoreCd().toUpperCase();
				soEmpSlspCd1              = gersXmlList.get(0).getSoEmpSlspCd1().toUpperCase();
				soWrDt                    = gersXmlList.get(0).getSoWrDt().toUpperCase();
				shipToTitle               = gersXmlList.get(0).getShipToTitle().toUpperCase();
				shipToFname               = gersXmlList.get(0).getShipToFname().toUpperCase();
				shipToLname               = gersXmlList.get(0).getShipToLname().toUpperCase();
				shipToAddr1               = gersXmlList.get(0).getShipToAddr1().toUpperCase();
				shipToAddr2               = gersXmlList.get(0).getShipToAddr2().toUpperCase();
				shipToZipCd               = gersXmlList.get(0).getShipToZipCd().toUpperCase();
				shipToHphone              = gersXmlList.get(0).getShipToHphone().toUpperCase();
				shipToBphone              = gersXmlList.get(0).getShipToBphone().toUpperCase();
				shipToExt                 = gersXmlList.get(0).getShipToExt().toUpperCase();
				shipToCity                = gersXmlList.get(0).getShipToCity().toUpperCase();
				shipToCorp                = gersXmlList.get(0).getShipToCorp().toUpperCase();
				pctOfSale1                = gersXmlList.get(0).getPctOfSale1().toUpperCase();
				puDel                     = gersXmlList.get(0).getPuDel().toUpperCase();
				puDelDt                   = gersXmlList.get(0).getPuDelDt().toUpperCase();
				delChg                    = gersXmlList.get(0).getDelChg().toUpperCase();
				setupChg                  = gersXmlList.get(0).getSetupChg().toUpperCase();
				taxChg                    = gersXmlList.get(0).getTaxChg().toUpperCase();
				origDelDocNum             = gersXmlList.get(0).getOrigDelDocNum().toUpperCase();
				origFiAmt                 = gersXmlList.get(0).getOrigFiAmt().toUpperCase();
				approvalCd                = gersXmlList.get(0).getApprovalCd().toUpperCase();
				requestedFiAmount         = gersXmlList.get(0).getRequestedFiAmount().toUpperCase();
				altDocNum                 = gersXmlList.get(0).getAltDocNum().toUpperCase();
				altCustCd                 = gersXmlList.get(0).getAltCustCd().toUpperCase();
				gersXmlSession.close();
				
				//Preparing XML Content using JAX-B
				SOType soObj = new SOType();
	            soObj.setTranId(trnId);
	    		soObj.setOriginCd(originCd);
	    		soObj.setCauseCd(causeCd);
	    		soObj.setEmpCdOp(empCdOp);
	    		soObj.setEmpCdKeyer(empCdKeyer);
	    		soObj.setFinCustCd(finCustCd);
	    		soObj.setShipToStCd(shipToStCd);
	    		soObj.setShipToZoneCd(shipToZoneCd);
	    		soObj.setTaxCd(taxCd);
	    		soObj.setOrdTpCd(ordTpCd);
	    		soObj.setOrdSrtCd(ordSrtCd);
	    		soObj.setSoStoreCd(soStoreCd);
	    		soObj.setPuDelStoreCd(puDelStoreCd);
	    		soObj.setSoEmpSlspCd1(soEmpSlspCd1);
	    		soObj.setSoWrDt(soWrDt);
	    		soObj.setShipToTitle(shipToTitle);
	    		soObj.setShipToFname(shipToFname);
	    		soObj.setShipToLname(shipToLname);
	    		soObj.setShipToAddr1(shipToAddr1);
	    		soObj.setShipToAddr2(shipToAddr2);
	    		soObj.setShipToZipCd(shipToZipCd);
	    		soObj.setShipToHphone(shipToHphone);
	    		soObj.setShipToBphone(shipToBphone);
	    		soObj.setShipToExt(shipToExt);
	    		soObj.setShipToCity(shipToCity);
	    		soObj.setShipToCorp(shipToCorp);
	    		soObj.setPctOfSale1(pctOfSale1);
	    		soObj.setPuDel(puDel);
	    		soObj.setPuDelDt(puDelDt);
	    		soObj.setDelChg(delChg);
	    		soObj.setSetupChg(setupChg);
	    		soObj.setTaxChg(taxChg);
	    		soObj.setOrigDelDocNum(origDelDocNum);
	    		soObj.setOrigFiAmount(origFiAmt);
	    		soObj.setApprovalCd(approvalCd);
	    		soObj.setRequestedFiAmt(requestedFiAmount);
	    		soObj.setAltDocNum(altDocNum);
	    		soObj.setAltCustCd(altCustCd);
	    		soObj.setSoLns(new SOLNSType());
	    		soObj.getSoLns().getSoLn().add(new SOLNType());
	    		
	    		Session gersXmlSolnsSession = HibernateManager.getSessionFactory().openSession();
	    		gersXmlSolnsSession.beginTransaction();
	    		
				Query gersXmlSolnsQuery             = gersXmlSolnsSession.getNamedQuery("GersXmlSolns.GetRecordsForXml").setLong("MonsoonOrderId", res.getMonsoonOrderId());
				List<GersXmlSolns> gersXmlSolnsList = gersXmlSolnsQuery.list();
	    		int lineNumber                      = 0;
	    		int listLength                      = gersXmlSolnsList.size();
	    		for (GersXmlSolns gersXmlSoln : gersXmlSolnsList)
				{
	    			soLnsId         = gersXmlSoln.getSoLnsId();
	    			monsoonOrderId  = gersXmlSoln.getMonsoonOrderId();
	    			itemCd          = gersXmlSoln.getItemCd();
	    			storeCd         = gersXmlSoln.getStoreCd();
	    			locCd           = gersXmlSoln.getLocCd();
	    			serNum          = gersXmlSoln.getSerNum();
	    			unitPrc         = gersXmlSoln.getUnitPrc();
	    			qty             = gersXmlSoln.getQty();
	    			soLnCmnt        = gersXmlSoln.getSoLnCmnt();
	    			activationDt    = gersXmlSoln.getActivationDt();
	    			activationPhone = gersXmlSoln.getActivationPhone();
	    			shipGroup       = gersXmlSoln.getShipGroup();
					if(lineNumber < listLength)
					{
						soObj.getSoLns().getSoLn().get(lineNumber).setDelDocLnNum(lineNumber+1);
		    			soObj.getSoLns().getSoLn().get(lineNumber).setItmCd(itemCd);
		    			soObj.getSoLns().getSoLn().get(lineNumber).setStoreCd(storeCd);
		    			soObj.getSoLns().getSoLn().get(lineNumber).setLocCd(locCd);
		    			soObj.getSoLns().getSoLn().get(lineNumber).setSerNum(serNum);
		    			soObj.getSoLns().getSoLn().get(lineNumber).setUnitPrc(unitPrc);
		    			soObj.getSoLns().getSoLn().get(lineNumber).setQty(qty);
		    			soObj.getSoLns().getSoLn().get(lineNumber).setSolnCmnt(soLnCmnt);
		    			soObj.getSoLns().getSoLn().get(lineNumber).setActivationDt(activationDt);
		    			soObj.getSoLns().getSoLn().get(lineNumber).setActivationPhone(activationPhone);
		    			soObj.getSoLns().getSoLn().get(lineNumber).setShipGroup(shipGroup);
					}
	    			soObj.getSoLns().getSoLn().add(new SOLNType());
	    			lineNumber++;
	    		}
	    		if(lineNumber == listLength)
	    		{
		    		soObj.getSoLns().getSoLn().get(lineNumber).setDelDocLnNum(lineNumber + 1);
		    		soObj.getSoLns().getSoLn().get(lineNumber).setItmCd("FREIGHT");
		    		soObj.getSoLns().getSoLn().get(lineNumber).setStoreCd("");
		    		soObj.getSoLns().getSoLn().get(lineNumber).setLocCd("");
		    		soObj.getSoLns().getSoLn().get(lineNumber).setSerNum("");
		    		soObj.getSoLns().getSoLn().get(lineNumber).setUnitPrc("0.0");
		    		soObj.getSoLns().getSoLn().get(lineNumber).setQty(1);
		    		soObj.getSoLns().getSoLn().get(lineNumber).setSolnCmnt("");
		    		soObj.getSoLns().getSoLn().get(lineNumber).setActivationDt("1900-01-01 01:01:01");
		    		soObj.getSoLns().getSoLn().get(lineNumber).setActivationPhone("");
		    		soObj.getSoLns().getSoLn().get(lineNumber).setShipGroup("");
	    		}
	    		gersXmlSolnsSession.close();
	    		
	    		Session gersXmlCustSession = HibernateManager.getSessionFactory().openSession();
	    		gersXmlCustSession.beginTransaction();
	    		
				Query gersXmlCustQuery            = gersXmlCustSession.getNamedQuery("GersXmlCust.GetRecordsForXml").setLong("CustCd", res.getMonsoonOrderId());
				List<GersXmlCust> gersXmlCustList = gersXmlCustQuery.list();
				
				custId          = gersXmlCustList.get(0).getCustId();
				custCd          = gersXmlCustList.get(0).getCustCd();
				srtCd           = gersXmlCustList.get(0).getSrtCd();
				title           = gersXmlCustList.get(0).getTitle();
				fname           = gersXmlCustList.get(0).getFname();
				init            = gersXmlCustList.get(0).getInit();
				lname           = gersXmlCustList.get(0).getLname();
				addr1           = gersXmlCustList.get(0).getAddr1();
				addr2           = gersXmlCustList.get(0).getAddr2();
				city            = gersXmlCustList.get(0).getCity();
				stCd            = gersXmlCustList.get(0).getStCd();
				zipCd           = gersXmlCustList.get(0).getZipCd();
				homePhone       = gersXmlCustList.get(0).getHomePhone();
				busPhone        = gersXmlCustList.get(0).getBusPhone();
				ext             = gersXmlCustList.get(0).getExt();
				corpName        = gersXmlCustList.get(0).getCorpName();
				custTpCd        = gersXmlCustList.get(0).getCustTpCd();
				altCustCd       = gersXmlCustList.get(0).getAltCustCd();
				emailAddr       = gersXmlCustList.get(0).getEmailAddr();
				emailAddrShipTo = gersXmlCustList.get(0).getEmailAddrShipTo();
				
	    		soObj.setCust(new CUSTType());
	    		soObj.getCust().setCustCd(custCd);
	    		soObj.getCust().setSrtCd(srtCd);
	    		soObj.getCust().setTitle(title);
	    		soObj.getCust().setFname(fname);
	    		soObj.getCust().setInit(init);
	    		soObj.getCust().setLname(lname);
	    		soObj.getCust().setAddr1(addr1);
	    		soObj.getCust().setAddr2(addr2);
	    		soObj.getCust().setCity(city);
	    		soObj.getCust().setStcd(stCd);
	    		soObj.getCust().setZipcd(zipCd);
	    		soObj.getCust().setHomePhone(homePhone);
	    		soObj.getCust().setBusPhone(busPhone);
	    		soObj.getCust().setExt(ext);
	    		soObj.getCust().setCorpName(corpName);
	    		soObj.getCust().setCustTpCd(custTpCd);
	    		soObj.getCust().setAltCustCd(altCustCd);
	    		soObj.getCust().setEmailAddr(emailAddr);
	    		soObj.getCust().setEmailAddrShipTo(emailAddrShipTo);
	    		gersXmlCustSession.close();
	    		
	    		StringWriter sw            = new StringWriter();
	            JAXBContext jaxbContext    = JAXBContext.newInstance("corp.cartoys.MopsMiddlelayer.MopsProcess01.XmlModels");
	    		Marshaller marshaller      = jaxbContext.createMarshaller();
	    		JAXBElement<SOType> soType = (new ObjectFactory()).createSO(soObj);
	    		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
	    		marshaller.marshal(soType, sw);
	    		XML = sw.toString();
				timeStamp = new java.text.SimpleDateFormat("yyyyMMdd_hmmss").format(new Date());
				
				//Writing XML to file
				try 
				{
					File xmlFile          = new File( Process01Launcher.outputFolderPath + "/orders_" + res.getMonsoonOrderId() + "_" + timeStamp + ".xml");
					FileWriter fileWriter = new FileWriter(xmlFile);
			        fileWriter.write(XML);
			        fileWriter.close();
				} 
				catch (IOException e) 
				{
					e.printStackTrace();
				}
				
				//Updating the field ImportStatus as 45 for db records for which xml is generated.
				Query importStatusUpdateQry = session.getNamedQuery("MnsnOrderHeader.UpdateImportStatusQry").setLong("ImportStatus", STATUS_ID_FOR_XML_GENERATED_RECORDS).setLong("MonsoonOrderId", res.getMonsoonOrderId());
				importStatusUpdateQry.executeUpdate();

				//Creating log file
				logMessage = newLineChar
						+ "DB polling done at " + new java.text.SimpleDateFormat("yyyy-MM-dd h:mm:ss").format(new Date()) + newLineChar
						+ "XML successfully generated at path \'" + Process01Launcher.outputFolderPath + "/orders_" + res.getMonsoonOrderId() + "_" + timeStamp + ".xml" +"\'" + newLineChar;
				log.info(logMessage);
	        }
		}
		else	
		{
			//Creating log file
			logMessage = newLineChar
						+ "DB polling done at " + timeStamp + newLineChar
						+ "Nothing to generate!";
			log.info(logMessage);
		}
		session.close();
	}
}