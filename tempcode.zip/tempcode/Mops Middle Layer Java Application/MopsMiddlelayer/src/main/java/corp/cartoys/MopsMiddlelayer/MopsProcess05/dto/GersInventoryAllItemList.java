package corp.cartoys.MopsMiddlelayer.MopsProcess05.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;
/**
 * The data transfer object for gers_inv_all_item_list table.
 * @author jjude
 */
@Entity
@Table(name = "gers_inv_all_item_list")
@NamedNativeQueries({
	@NamedNativeQuery(
	name        = "GersInventoryAllItemList.GetInvDetails",
	query       = "SELECT gers_inv_id,gers_inv_mnsn_op,gers_inv_item_code,gers_inv_qty,created_date FROM gers_inv_all_item_list ORDER BY gers_inv_item_code ASC",
    resultClass = GersInventoryAllItemList.class
	)
})
public class GersInventoryAllItemList {
	@Id
	private int gers_inv_id;
	private String gers_inv_mnsn_op;
	private String gers_inv_item_code;
	private Double gers_inv_qty;
	private String created_date;
	
	public int getGers_inv_id() {
		return gers_inv_id;
	}
	public void setGers_inv_id(int gers_inv_id) {
		this.gers_inv_id = gers_inv_id;
	}
	public String getGers_inv_mnsn_op() {
		return gers_inv_mnsn_op;
	}
	public void setGers_inv_mnsn_op(String gers_inv_mnsn_op) {
		this.gers_inv_mnsn_op = gers_inv_mnsn_op;
	}
	public String getGers_inv_item_code() {
		return gers_inv_item_code;
	}
	public void setGers_inv_item_code(String gers_inv_item_code) {
		this.gers_inv_item_code = gers_inv_item_code;
	}
	public Double getGers_inv_qty() {
		return gers_inv_qty;
	}
	public void setGers_inv_qty(Double gers_inv_qty) {
		this.gers_inv_qty = gers_inv_qty;
	}
	public String getCreated_date() {
		return created_date;
	}
	public void setCreated_date(String created_date) {
		this.created_date = created_date;
	}
}
