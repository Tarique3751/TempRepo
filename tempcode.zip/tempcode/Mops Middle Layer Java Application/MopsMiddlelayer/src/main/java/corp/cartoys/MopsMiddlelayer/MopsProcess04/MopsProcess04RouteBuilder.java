package corp.cartoys.MopsMiddlelayer.MopsProcess04;

import org.apache.log4j.Logger;

/**
 * Camel route that checks the database and generate the order import files.
 * @author jjude
 */
public class MopsProcess04RouteBuilder extends org.apache.camel.builder.RouteBuilder{
	String newLineChar = System.getProperty("line.separator"); //To get the newline character of corresponding platform
	static Logger log  = Logger.getLogger(MopsProcess04RouteBuilder.class.getName());
	
	public void configure() throws Exception
	{
		try
		{
			//Camel Route 1 : Check the database based on time interval specified in config and generate the order import file 
			from("timer://foo?period=" + Process04Launcher.dBPollingTime).
			bean(new OrderImportFileGenerator(),"generateOrderImportFile").
			to("mock:result");
		}
		catch(Exception e)
		{
			String logMessage = newLineChar
					+ "Something went wrong.Please ensure that the input and output folder paths are configured correctly in AppConfig.properties file." + newLineChar
					+ "Exception : " + e + newLineChar
					+ newLineChar;
			log.info(logMessage);
		} 
	}
}