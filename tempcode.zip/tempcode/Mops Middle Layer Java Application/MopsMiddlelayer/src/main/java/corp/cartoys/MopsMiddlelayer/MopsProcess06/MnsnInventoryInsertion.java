package corp.cartoys.MopsMiddlelayer.MopsProcess06;

import java.util.Date;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;

import corp.cartoys.MopsMiddlelayer.HibernateManager;
import corp.cartoys.MopsMiddlelayer.MopsProcess06.dto.GersInventoryAllItemList;
import corp.cartoys.MopsMiddlelayer.MopsProcess06.dto.MnsnInventory;

/**
 * Calls the webservice and saves the response data to database.
 * @author jjude
 */
public class MnsnInventoryInsertion {
	String newLineChar = System.getProperty("line.separator"); //To get the newline character of corresponding platform
	static Logger log  = Logger.getLogger(MnsnInventoryInsertion.class.getName());
	String timeStamp   = new java.text.SimpleDateFormat("yyyy-MM-dd h:mm:ss").format(new Date());
	
	/**
	 * Calls the webservice and saves the response data to database.
	 * @param Nothing.
	 * @return Nothing.
	 */
	public void insertAllInventoryToMysql()
	{
		String logMessage = newLineChar + "Webservice called at " + timeStamp + newLineChar;
		
		try
		{
			Client client      = ClientBuilder.newClient();
			WebTarget target   = client.target(Process06Launcher.webServiceUrl);
			int responseStatus = target.request(MediaType.APPLICATION_JSON).get().getStatus();
			
			if(responseStatus == 200) // proceed only if response status is 200
			{
				MnsnInventory[] response = target.request(MediaType.APPLICATION_JSON).get(MnsnInventory[].class);
				
				Session session = HibernateManager.getSessionFactory().openSession();
				session.beginTransaction();
				// Truncate the table gers_inv_all_item_list before insertion.
				Query truncateMnsnInv = session.getNamedQuery("GersInventoryAllItemList.TruncateTable");
				truncateMnsnInv.executeUpdate();
				int invCount = 0;
				for (MnsnInventory res : response) 
				{
					Session invSession = HibernateManager.getSessionFactory().openSession();
					GersInventoryAllItemList gersInventoryAllItemList = new GersInventoryAllItemList();
					gersInventoryAllItemList.setGers_inv_mnsn_op("m");
					gersInventoryAllItemList.setGers_inv_item_code(res.getSku());
					gersInventoryAllItemList.setGers_inv_qty(res.getQuantity());
					gersInventoryAllItemList.setCreated_date(timeStamp);
					invSession.save(gersInventoryAllItemList);
					invSession.flush();
					try
					{
						invSession.getTransaction().commit();
					}
					catch(Exception e)
					{
						invSession.getTransaction().rollback();
					}
					invSession.close();
					invCount++;
				}
				logMessage = logMessage + "Successfully inserted "+ invCount + " inventory into gers_inv_all_item_list." + newLineChar;
			}
			else
			{
				logMessage = logMessage + "Error occured while fetching monsoon inventory. Webservice response status :" + responseStatus + newLineChar;
			}
		}
		catch(Exception e)
		{
			logMessage = logMessage + "Could not connect to webservice." + newLineChar;
		}
		log.info(logMessage);
	}
}
