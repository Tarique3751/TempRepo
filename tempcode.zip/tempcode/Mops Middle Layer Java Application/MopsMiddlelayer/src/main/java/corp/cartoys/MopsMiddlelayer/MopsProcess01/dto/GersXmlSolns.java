package corp.cartoys.MopsMiddlelayer.MopsProcess01.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;

/**
 * The Data transfer object for gers_xml_solns table.
 * @author jjude
 */
@Entity
@Table(name = "gers_xml_solns")
@NamedQueries({
	@NamedQuery(
	name  = "GersXmlSolns.GetRecordsForXml",
	query = "FROM GersXmlSolns gxs WHERE gxs.MonsoonOrderId = :MonsoonOrderId"
	),
	@NamedQuery(
	name  = "GersXmlSolns.GetRecords",
	query = "FROM GersXmlSolns gxs WHERE gxs.MonsoonOrderId = :MonsoonOrderId and gxs.ItemCd = :ItemCd"
	)
})
public class GersXmlSolns {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int SoLnsId;
	private int GersXmlId;
	private int MonsoonOrderId;
	private String ItemCd;
	private String StoreCd;
	private String LocCd;
	private String SerNum;
	private String UnitPrc;
	private int Qty;
	private String SoLnCmnt;
	private String ActivationDt;
	private String ActivationPhone;
	private String ShipGroup;
	public int getSoLnsId() {
		return SoLnsId;
	}
	public void setSoLnsId(int soLnsId) {
		SoLnsId = soLnsId;
	}
	public int getGersXmlId() {
		return GersXmlId;
	}
	public void setGersXmlId(int gersXmlId) {
		GersXmlId = gersXmlId;
	}
	
	public int getMonsoonOrderId() {
		return MonsoonOrderId;
	}
	public void setMonsoonOrderId(int monsoonOrderId) {
		MonsoonOrderId = monsoonOrderId;
	}
	public String getItemCd() {
		return ItemCd;
	}
	public void setItemCd(String itemCd) {
		ItemCd = itemCd;
	}
	public String getStoreCd() {
		return StoreCd;
	}
	public void setStoreCd(String storeCd) {
		StoreCd = storeCd;
	}
	public String getLocCd() {
		return LocCd;
	}
	public void setLocCd(String locCd) {
		LocCd = locCd;
	}
	public String getSerNum() {
		return SerNum;
	}
	public void setSerNum(String serNum) {
		SerNum = serNum;
	}
	public String getUnitPrc() {
		return UnitPrc;
	}
	public void setUnitPrc(String unitPrc) {
		UnitPrc = unitPrc;
	}
	public int getQty() {
		return Qty;
	}
	public void setQty(int qty) {
		Qty = qty;
	}
	public String getSoLnCmnt() {
		return SoLnCmnt;
	}
	public void setSoLnCmnt(String soLnCmnt) {
		SoLnCmnt = soLnCmnt;
	}
	public String getActivationDt() {
		return ActivationDt;
	}
	public void setActivationDt(String activationDt) {
		ActivationDt = activationDt;
	}
	public String getActivationPhone() {
		return ActivationPhone;
	}
	public void setActivationPhone(String activationPhone) {
		ActivationPhone = activationPhone;
	}
	public String getShipGroup() {
		return ShipGroup;
	}
	public void setShipGroup(String shipGroup) {
		ShipGroup = shipGroup;
	}
}
