package corp.cartoys.MopsMiddlelayer;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.camel.CamelContext;
import org.apache.camel.impl.DefaultCamelContext;

import corp.cartoys.MopsMiddlelayer.MopsProcess01.MopsProcess01RouteBuilder;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.Process01Launcher;
import corp.cartoys.MopsMiddlelayer.MopsProcess02.MopsProcess02RouteBuilder;
import corp.cartoys.MopsMiddlelayer.MopsProcess02.Process02Launcher;
import corp.cartoys.MopsMiddlelayer.MopsProcess03.MopsProcess03RouteBuilder;
import corp.cartoys.MopsMiddlelayer.MopsProcess03.Process03Launcher;
import corp.cartoys.MopsMiddlelayer.MopsProcess04.MopsProcess04RouteBuilder;
import corp.cartoys.MopsMiddlelayer.MopsProcess04.Process04Launcher;
import corp.cartoys.MopsMiddlelayer.MopsProcess05.MopsProcess05RouteBuilder;
import corp.cartoys.MopsMiddlelayer.MopsProcess05.Process05Launcher;
import corp.cartoys.MopsMiddlelayer.MopsProcess06.MopsProcess06RouteBuilder;
import corp.cartoys.MopsMiddlelayer.MopsProcess06.Process06Launcher;

/**
 * Load the Application Configurations, Creates instance of camel routes and keeps it running till the application is stopped.
 * @author jjude
 */
public class AppLauncher {
	
	static String configFilePath = "./GeneralConfig/AppConfig.properties";
	public static Properties prop = new Properties();
	public static String MAIL_SMTP_HOST;
	public static String MAIL_SMTP_PORT;
	public static String FROM_EMAIL;
	public static String FROM_EMAIL_PASSWORD;
	public static String TO_EMAIL;
	
	/**
	 * Main method of the Mops Middleware java application.
	 * @param args Unused.
	 * @return Nothing.
	 */
	public static void main(String[] args) throws Exception {
		
		//Load the email settings from the config
		try
		{
			prop.load(new FileInputStream(configFilePath));
		}
		catch(IOException e)
		{
			System.out.println("Exception :" + e);
		}
		MAIL_SMTP_HOST      = prop.getProperty("MAIL_SMTP_HOST");
		MAIL_SMTP_PORT      = prop.getProperty("MAIL_SMTP_PORT");
		FROM_EMAIL          = prop.getProperty("FROM_EMAIL");
		FROM_EMAIL_PASSWORD = prop.getProperty("FROM_EMAIL_PASSWORD");
		TO_EMAIL            = prop.getProperty("TO_EMAIL"); 
		
		// Process 01 - Process the incoming monsoon order files, split them into mnsn_order_header and mnsn_order_details tables and generate the Gers xml.
		Process01Launcher.readAppConfigurations();
		// Process 02 - Process the incoming pass or fail gers file.
		Process02Launcher.readAppConfigurations();
		// Process 03 - Process the incoming tracking file.
		Process03Launcher.readAppConfigurations();
		// Process 04 - Check the database for specific time intervals, fetches order import details and generates the order import files.
		Process04Launcher.readAppConfigurations();
		// Process 05 - Calls webservice to fetch data from oracle , insert into mysql database and to create tsv file for monsoon.
		Process05Launcher.readAppConfigurations();
		// Process 06 - Calls webservice, to fetch data from monsoon and insert into mysql table.
		Process06Launcher.readAppConfigurations();
		
		MopsProcess01RouteBuilder p01RouteBuilder = new MopsProcess01RouteBuilder();
		MopsProcess02RouteBuilder p02RouteBuilder = new MopsProcess02RouteBuilder();
		MopsProcess03RouteBuilder p03RouteBuilder = new MopsProcess03RouteBuilder();
		MopsProcess04RouteBuilder p04RouteBuilder = new MopsProcess04RouteBuilder();
		MopsProcess05RouteBuilder p05RouteBuilder = new MopsProcess05RouteBuilder();
		MopsProcess06RouteBuilder p06RouteBuilder = new MopsProcess06RouteBuilder();
		
		CamelContext ctx = new DefaultCamelContext();
		try
		{
			ctx.addRoutes(p01RouteBuilder);
			ctx.addRoutes(p02RouteBuilder);
			ctx.addRoutes(p03RouteBuilder);
			ctx.addRoutes(p04RouteBuilder);
			ctx.addRoutes(p05RouteBuilder);
			ctx.addRoutes(p06RouteBuilder);
			ctx.start(); // Start all the Camel routes.
			Thread.currentThread().join(); //Keep the apache camel thread running until the application stops or JVM terminates.
		}
		catch(Exception e)
		{
			e.printStackTrace();
			ctx.stop();
		}
	}

}
