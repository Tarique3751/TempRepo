package corp.cartoys.MopsMiddlelayer.MopsProcess01.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;
import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;

/**
 * The Data transfer object for mnsn_order_header table.
 * @author jjude
 */
@Entity
@Table(name = "mnsn_order_header")
@NamedQueries({
	@NamedQuery(
	name  = "MnsnOrderHeader.GetRecordsForXml",
	query = "FROM MnsnOrderHeader moh WHERE moh.ImportStatus = :ImportStatus AND AutomaticImportStatus = :AutomaticImportStatus"
	),
	@NamedQuery(
	name  = "MnsnOrderHeader.GetOrderHeaderDetails",
	query = "FROM MnsnOrderHeader moh WHERE moh.MonsoonOrderId = :MonsoonOrderId"
	)
})
@NamedNativeQueries({
	@NamedNativeQuery(
	name        = "MnsnOrderHeader.UpdateImportStatusQry",
	query       = "update mnsn_order_header as moh set moh.ImportStatus = :ImportStatus where moh.MonsoonOrderId = :MonsoonOrderId",
    resultClass = MnsnOrderHeader.class
	),
	@NamedNativeQuery(
	name        = "MnsnOrderHeader.UpdateImportStatusAndAutomaticImportStatusQry",
	query       = "update mnsn_order_header as moh set moh.ImportStatus = :ImportStatus, moh.AutomaticImportStatus = :AutomaticImportStatus where moh.MonsoonOrderId = :MonsoonOrderId",
    resultClass = MnsnOrderHeader.class
	),
	@NamedNativeQuery(
	name        = "MnsnOrderHeader.UpdateAutomaticImportErrorDetails",
	query       = "update mnsn_order_header moh set moh.AutomaticImportErrorDetails= CONCAT(IFNULL(moh.AutomaticImportErrorDetails,''), :AutomaticImportErrorDetails) WHERE moh.MonsoonOrderId = :MonsoonOrderId",
    resultClass = MnsnOrderHeader.class
	),
	@NamedNativeQuery(
	name        = "MnsnOrderHeader.SetAutomaticImportErrorDetails",
	query       = "update mnsn_order_header moh set moh.AutomaticImportErrorDetails= :AutomaticImportErrorDetails WHERE moh.MonsoonOrderId = :MonsoonOrderId",
    resultClass = MnsnOrderHeader.class
	),
	@NamedNativeQuery(
	name        = "MnsnOrderHeader.UpdateBuyerDetails",
	query       = "update mnsn_order_header as moh set moh.BuyerEmail = :BuyerEmail,moh.FirstName = :FirstName,moh.LastName = :LastName,moh.Address1 = :Address1 where moh.MonsoonOrderId = :MonsoonOrderId",
    resultClass = MnsnOrderHeader.class
	),
	@NamedNativeQuery(
	name        = "MnsnOrderHeader.UpdateCityDetails",
	query       = "update mnsn_order_header as moh set moh.City = :City where moh.MonsoonOrderId = :MonsoonOrderId",
    resultClass = MnsnOrderHeader.class
	),
	@NamedNativeQuery(
	name        = "MnsnOrderHeader.UpdateStateDetails",
	query       = "update mnsn_order_header as moh set moh.State = :State where moh.MonsoonOrderId = :MonsoonOrderId",
    resultClass = MnsnOrderHeader.class
	),
	@NamedNativeQuery(
	name        = "MnsnOrderHeader.UpdatePostalCode",
	query       = "update mnsn_order_header as moh set moh.PostalCode = :PostalCode where moh.MonsoonOrderId = :MonsoonOrderId",
    resultClass = MnsnOrderHeader.class
	),
	@NamedNativeQuery(
	name        = "MnsnOrderHeader.UpdateAddress",
	query       = "update mnsn_order_header as moh set moh.Address2 = :Address2, moh.LocationCode = :LocationCode where moh.MonsoonOrderId = :MonsoonOrderId",
    resultClass = MnsnOrderHeader.class
	),
	@NamedNativeQuery(
	name        = "MnsnOrderHeader.UpdateFnameLname",
	query       = "update mnsn_order_header as moh set moh.FirstName = :FirstName, moh.LastName = :LastName where moh.MonsoonOrderId = :MonsoonOrderId",
    resultClass = MnsnOrderHeader.class
	),
	@NamedNativeQuery(
	name        = "MnsnOrderHeader.UpdateBuyerPhone",
	query       = "update mnsn_order_header as moh set moh.BuyerPhoneNumber = :BuyerPhoneNumber where moh.MonsoonOrderId = :MonsoonOrderId",
    resultClass = MnsnOrderHeader.class
	)
})
public class MnsnOrderHeader {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int MonsoonOrderHdId;
	private int MonsoonOrderId;
	private String OrderStatus;
	private String MarketName;
	private String MarketOrderId;
	private String ShipMethod;
	private String OrderDate;
	private String ShipDate;
	private String OrderNote;
	private String TrackingNumber;
	private String CarrierCode;
	private String BuyerEmail;
	private String BuyerName;
	private String FirstName;
	private String LastName;
	private String ShipToName;
	private String Address1;
	private String Address2;
	private String City;
	private String State;
	private String PostalCode;
	private String Country;
	private String BuyerPhoneNumber;
	private int ImportStatus;
	private String CreatedDate;
	private String Returns;
	private int AutomaticImportStatus;
	private String LocationCode;
	private String AutomaticImportErrorDetails;
	private String Company;
	private int AlreadyExist;
	public int getMonsoonOrderHdId() {
		return MonsoonOrderHdId;
	}
	public void setMonsoonOrderHdId(int monsoonOrderHdId) {
		MonsoonOrderHdId = monsoonOrderHdId;
	}
	public int getMonsoonOrderId() {
		return MonsoonOrderId;
	}
	public void setMonsoonOrderId(int monsoonOrderId) {
		MonsoonOrderId = monsoonOrderId;
	}
	public String getOrderStatus() {
		return OrderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		OrderStatus = orderStatus;
	}
	public String getMarketName() {
		return MarketName;
	}
	public void setMarketName(String marketName) {
		MarketName = marketName;
	}
	public String getMarketOrderId() {
		return MarketOrderId;
	}
	public void setMarketOrderId(String marketOrderId) {
		MarketOrderId = marketOrderId;
	}
	public String getShipMethod() {
		return ShipMethod;
	}
	public void setShipMethod(String shipMethod) {
		ShipMethod = shipMethod;
	}
	public String getOrderDate() {
		return OrderDate;
	}
	public void setOrderDate(String orderDate) {
		OrderDate = orderDate;
	}
	public String getShipDate() {
		return ShipDate;
	}
	public void setShipDate(String shipDate) {
		ShipDate = shipDate;
	}
	public String getOrderNote() {
		return OrderNote;
	}
	public void setOrderNote(String orderNote) {
		OrderNote = orderNote;
	}
	public String getTrackingNumber() {
		return TrackingNumber;
	}
	public void setTrackingNumber(String trackingNumber) {
		TrackingNumber = trackingNumber;
	}
	public String getCarrierCode() {
		return CarrierCode;
	}
	public void setCarrierCode(String carrierCode) {
		CarrierCode = carrierCode;
	}
	public String getBuyerEmail() {
		return BuyerEmail;
	}
	public void setBuyerEmail(String buyerEmail) {
		BuyerEmail = buyerEmail;
	}
	public String getBuyerName() {
		return BuyerName;
	}
	public void setBuyerName(String buyerName) {
		BuyerName = buyerName;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getShipToName() {
		return ShipToName;
	}
	public void setShipToName(String shipToName) {
		ShipToName = shipToName;
	}
	public String getAddress1() {
		return Address1;
	}
	public void setAddress1(String address1) {
		Address1 = address1;
	}
	public String getAddress2() {
		return Address2;
	}
	public void setAddress2(String address2) {
		Address2 = address2;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getPostalCode() {
		return PostalCode;
	}
	public void setPostalCode(String postalCode) {
		PostalCode = postalCode;
	}
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
	public String getBuyerPhoneNumber() {
		return BuyerPhoneNumber;
	}
	public void setBuyerPhoneNumber(String buyerPhoneNumber) {
		BuyerPhoneNumber = buyerPhoneNumber;
	}
	public int getImportStatus() {
		return ImportStatus;
	}
	public void setImportStatus(int importStatus) {
		ImportStatus = importStatus;
	}
	public String getCreatedDate() {
		return CreatedDate;
	}
	public void setCreatedDate(String createdDate) {
		CreatedDate = createdDate;
	}
	public String getReturns() {
		return Returns;
	}
	public void setReturns(String returns) {
		Returns = returns;
	}
	public int getAutomaticImportStatus() {
		return AutomaticImportStatus;
	}
	public void setAutomaticImportStatus(int automaticImportStatus) {
		AutomaticImportStatus = automaticImportStatus;
	}
	public String getLocationCode() {
		return LocationCode;
	}
	public void setLocationCode(String locationCode) {
		LocationCode = locationCode;
	}
	public String getAutomaticImportErrorDetails() {
		return AutomaticImportErrorDetails;
	}
	public void setAutomaticImportErrorDetails(String automaticImportErrorDetails) {
		AutomaticImportErrorDetails = automaticImportErrorDetails;
	}
	public String getCompany() {
		return Company;
	}
	public void setCompany(String company) {
		Company = company;
	}
	public int getAlreadyExist() {
		return AlreadyExist;
	}
	public void setAlreadyExist(int alreadyExist) {
		AlreadyExist = alreadyExist;
	}
}
