package corp.cartoys.MopsMiddlelayer.MopsProcess05;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import corp.cartoys.MopsMiddlelayer.AppConfigValidator;

/**
 * MopsProcess05 - Calls webservice to fetch data from oracle , insert into mysql database and to create tsv file for monsoon.
 * @author jjude
 */
public class Process05Launcher {
	public static Properties prop = new Properties();
	public static String outputFolderPath;
	public static String dataSplitDelimiter;
	public static String webServicePollingTime;
	public static String fileName;
	public static String webServiceUrl;
	static String configFilePath = "./MopsProcess05Config/AppConfig.properties";
	
	/**
	 * Read the AppConfig properties file and fetch the application configurations.
	 * @param Nothing.
	 * @return Nothing.
	 */
	public static void readAppConfigurations()
	{
		try
		{
			prop.load(new FileInputStream(configFilePath));
		}
		catch(IOException e)
		{
			System.out.println("Exception :" + e);
		}
		//Setting the app config variables
		outputFolderPath      = prop.getProperty("OutputFolderPath"); //Output directory path
		dataSplitDelimiter    = prop.getProperty("DataSplitDelimiter");//Delimiter used in the generated file
		webServicePollingTime = prop.getProperty("WebServicePollingTime");//Webservice polling interval
		fileName              = prop.getProperty("FileName");//File name of generated file
		webServiceUrl         = prop.getProperty("WebServiceUrl"); // Webservice url
		
		//Validate the configurations
		AppConfigValidator.checkFolderExists(outputFolderPath,configFilePath);
		AppConfigValidator.isNumeric("WebServicePollingTime",webServicePollingTime,configFilePath);
	}
}
