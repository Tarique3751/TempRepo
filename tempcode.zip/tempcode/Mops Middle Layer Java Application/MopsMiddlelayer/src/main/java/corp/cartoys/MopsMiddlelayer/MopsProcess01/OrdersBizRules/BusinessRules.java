package corp.cartoys.MopsMiddlelayer.MopsProcess01.OrdersBizRules;

/**
 * Interface that declares all the business rule functions.
 * @author jjude
 */
public interface BusinessRules {
	
	/**
	 * Function that checks if total amount is greater than Max Total amount.
	 * @param Nothing.
	 * @return Nothing.
	 */
	public void checkTotalAmount();
	
	/**
	 * Function that sets the Email, Firstname, Lastname and Address.
	 * @param Nothing.
	 * @return Nothing.
	 */
	public void setBuyerDetails();
	
	/**
	 * Function that sets the confidential city value.
	 * @param Nothing.
	 * @return Nothing.
	 */
	public void setCity();
	
	/**
	 * Function that sets the confidential state value.
	 * @param Nothing.
	 * @return Nothing.
	 */
	public void setState();
	
	/**
	 * Function that sets the confidential postal code value.
	 * @param Nothing.
	 * @return Nothing.
	 */
	public void setPostalCode();
	
	/**
	 * Function that checks the length of address.
	 * @param Nothing.
	 * @return Nothing.
	 */
	public void checkAddressLength();
	
	/**
	 * Function that sets the Address2 and Location code.
	 * @param Nothing.
	 * @return Nothing.
	 */
	public void setAddress();
	
	/**
	 * Function that splits ship to name.
	 * @param shipToName - String.
	 * @return Nothing.
	 */
	public void splitShipToName(String shipToName);
	
	/**
	 * Function that sets the last name if buyer name has only one name.
	 * @param BuyerName - String.
	 * @return Nothing.
	 */
	public void setLastName(String BuyerName);
	
	/**
	 * Function that formats the phone number.
	 * @param BuyerPhoneNumber - String.
	 * @return Nothing.
	 */
	public void setBuyerPhoneNumber(String BuyerPhoneNumber);
	
	/**
	 * Function that sets the error message for mutiple sku orders.
	 * @param Nothing.
	 * @return Nothing.
	 */
	public void setMultipleSkuWarning();
	
	/**
	 * Function that sets the state code corresponding to a state.
	 * @param State - String.
	 * @return stateCode - String.
	 */
	public String getStateCode(String State);
	
	/**
	 * Function that sets validation error messages for need attention orders.
	 * @param errMsg - String.
	 * @param monsoonOrderId - Int.
	 * @return Nothing.
	 */
	public void updateErrMsg(String errMsg, int monsoonOrderId);
	
	/**
	 * Function that removes validation error messages for corrected orders.
	 * @param errMsg - String.
	 * @param monsoonOrderId - Int.
	 * @return Nothing.
	 */
	public void removeErrMsg(String errMsg, int monsoonOrderId);
	
	/**
	 * Function that inserts Gers XML values into DB..
	 * @param monsoonOrderId - Int.
	 * @param sku - String.
	 * @return Nothing.
	 */
	public void persistGersXml(int monsoonOrderId, String sku);
	
}
