package corp.cartoys.MopsMiddlelayer.MopsProcess04;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

import corp.cartoys.MopsMiddlelayer.HibernateManager;

/**
 * Fetches the order import details from database, prepares and writes the data to order import file.
 * @author jjude
 */
public class OrderImportFileGenerator {
	
	String newLineChar = System.getProperty("line.separator"); //To get the newline character of corresponding platform
	static Logger log  = Logger.getLogger(OrderImportFileGenerator.class.getName());
	
	/**
	* Gets the order details from database and generates the order import file.
	* @param Nothing.
	* @return Nothing.
	*/
	public void generateOrderImportFile()
	{
		String timeStamp      = new java.text.SimpleDateFormat("yyyyMMdd_hmmss").format(new Date());
		String newLineChar    = System.getProperty("line.separator"); //To get the newline character of corresponding platform
		String fileHeaderData = "MonsoonOP" + Process04Launcher.dataSplitDelimiter + "MonsoonOrderId" + Process04Launcher.dataSplitDelimiter + "MarketOrderItemId" + Process04Launcher.dataSplitDelimiter + "OrderStatus" + Process04Launcher.dataSplitDelimiter + "SKU" + Process04Launcher.dataSplitDelimiter + "TrackingNumber" + newLineChar;
		String logMessage     = "";
		
		Session session = HibernateManager.getSessionFactory().openSession();
		// The query that fetches the data for order import file
		/*String tsvSql = "SELECT DISTINCT h.MonsoonOrderId,d.MarketOrderItemId,d.SKU,"
					+"IF(t.ManualTrackingNumber IS NOT NULL,t.ManualTrackingNumber,t.TrackingNumber) AS TrackingNumber "
					+"FROM mnsn_order_header AS h "
					+"INNER JOIN mnsn_order_details AS d ON  h.MonsoonOrderHdId  =  d.MonsoonOrderHdId " 
					+"INNER JOIN gers_weblink_status AS gws ON gws.order_number = h.MonsoonOrderId " 
					+"INNER JOIN mnsn_order_tracking t ON t.GersInvoice  = gws.gers_invoice COLLATE utf8_general_ci " 
					+"WHERE t.UpdateMnsn = 0;";*/
		String tsvSql          = "call get_order_import_data;";
		SQLQuery query         = session.createSQLQuery(tsvSql);
		String importStatusSql = "";

		List<Object[]> entities = query.list();
		int i;
		String fileData = fileHeaderData;
	    for (Object[] entity : entities) {
	    	i = 0;
	        for (Object entityCol : entity) {
	        	if(i == 0) //First element of query result object is MoonsoonOrderId
	        	{
	        		fileData = fileData + "m" + Process04Launcher.dataSplitDelimiter + entityCol;
	        		//Set the UpdateMnsn field as 1 for records for which order import file will be generated.
	        		importStatusSql = "UPDATE mnsn_order_tracking SET UpdateMnsn = 1 WHERE OrderNumber=" + entityCol + ";";
	        		SQLQuery importStatusQuery = session.createSQLQuery(importStatusSql);
	        		importStatusQuery.executeUpdate();
	        	}
	        	else if(i == 2)
	        	{
	        		fileData = fileData + Process04Launcher.dataSplitDelimiter + "Shipped" + Process04Launcher.dataSplitDelimiter + entityCol;
	        	}
	        	else
	        	{
	        		fileData = fileData + Process04Launcher.dataSplitDelimiter + entityCol;
	        	} 
	            i++;
	        }
	        fileData = fileData + newLineChar;
	    }
	    session.close();
	    
	    //Generate file only if the query returns records
		if(!fileData.equalsIgnoreCase(fileHeaderData))
		{
			//Writing Tsv to file
			try 
			{
				File file             = new File( Process04Launcher.outputFolderPath + "/" + Process04Launcher.fileName + timeStamp + ".txt");
				FileWriter fileWriter = new FileWriter(file);
		        fileWriter.write(fileData);
		        fileWriter.close();
			} 
			catch (IOException e) 
			{
				//Logging
				logMessage = newLineChar
							+ "DB polling done at " + new java.text.SimpleDateFormat("yyyy-MM-dd h:mm:ss").format(new Date()) + newLineChar
							+ "File cannot be created due to an exception:" + newLineChar
							+ e;
				log.info(logMessage);
			}
			//Logging
			logMessage = newLineChar
						+ "DB polling done at " + new java.text.SimpleDateFormat("yyyy-MM-dd h:mm:ss").format(new Date()) + newLineChar
						+ "File successfully generated at path \'" + Process04Launcher.outputFolderPath  + "/" + Process04Launcher.fileName + timeStamp + ".txt" +"\'" + newLineChar;
			log.info(logMessage);
		}
		else
		{
			//Logging
			logMessage = newLineChar
						+ "DB polling done at " + new java.text.SimpleDateFormat("yyyy-MM-dd h:mm:ss").format(new Date()) + newLineChar
						+ "Nothing to generate!";
			log.info(logMessage);
		}
	}
}
