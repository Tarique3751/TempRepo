package corp.cartoys.MopsMiddlelayer.MopsProcess05;

import org.apache.log4j.Logger;

/**
 * Camel route that calls webservice and generate the inventory files.
 * @author jjude
 */
public class MopsProcess05RouteBuilder extends org.apache.camel.builder.RouteBuilder{
	String newLineChar = System.getProperty("line.separator"); //To get the newline character of corresponding platform
	static Logger log  = Logger.getLogger(MopsProcess05RouteBuilder.class.getName());
	
	public void configure() throws Exception
	{
		try
		{
			//Camel Route 1 : Call the webservice based on a timer specified in the AppConfig and generate the gers inventory files.
			from("timer://foo?period=" + Process05Launcher.webServicePollingTime).
			bean(new GersInventoryFileGenerator(),"generateInventoryTsv").
			to("mock:result");
		}
		catch(Exception e)
		{
			String logMessage = newLineChar
					+ "Something went wrong.Please ensure that the input and output folder paths are configured correctly in AppConfig.properties file." + newLineChar
					+ "Exception : " + e + newLineChar
					+ newLineChar;
			log.info(logMessage);
		} 
	}
}