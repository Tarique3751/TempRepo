package corp.cartoys.MopsMiddlelayer.MopsProcess01.XmlModels;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

@XmlRegistry
public class ObjectFactory {
	private final static QName _SO_QNAME = new QName("", "SO");

	public ObjectFactory() {
	}

	public SOType createSOType() {
		return new SOType();
	}

	public SOLNSType createSOLNSType() {
		return new SOLNSType();
	}

	public CUSTType createCUSTType() {
		return new CUSTType();
	}

	public SOLNType createSOLNType() {
		return new SOLNType();
	}

	@XmlElementDecl(namespace = "", name = "SO")
	public JAXBElement<SOType> createSO(SOType value) {
		return new JAXBElement<SOType>(_SO_QNAME, SOType.class, null, value);
	}
}
