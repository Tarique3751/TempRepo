package corp.cartoys.MopsMiddlelayer.MopsProcess01.XmlModels;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CUSTType", propOrder = { "CustCd", "SrtCd", "Title", "Fname", "Init", "Lname", "Addr1", "Addr2",
		"City", "Stcd", "Zipcd", "HomePhone", "BusPhone", "Ext", "CorpName", "CustTpCd", "AltCustCd", "EmailAddr",
		"EmailAddrShipTo" })
public class CUSTType {

	@XmlElement(name = "CUST_CD", required = true)
	private int CustCd;
	@XmlElement(name = "SRT_CD", required = true)
	private String SrtCd;
	@XmlElement(name = "TITLE", required = true)
	private String Title;
	@XmlElement(name = "FNAME", required = true)
	private String Fname;
	@XmlElement(name = "INIT", required = true)
	private String Init;
	@XmlElement(name = "LNAME", required = true)
	private String Lname;
	@XmlElement(name = "ADDR1", required = true)
	private String Addr1;
	@XmlElement(name = "ADDR2", required = true)
	private String Addr2;
	@XmlElement(name = "CITY", required = true)
	private String City;
	@XmlElement(name = "ST_CD", required = true)
	private String Stcd;
	@XmlElement(name = "ZIP_CD", required = true)
	private String Zipcd;
	@XmlElement(name = "HOME_PHONE", required = true)
	private String HomePhone;
	@XmlElement(name = "BUS_PHONE", required = true)
	private String BusPhone;
	@XmlElement(name = "EXT", required = true)
	private String Ext;
	@XmlElement(name = "CORP_NAME", required = true)
	private String CorpName;
	@XmlElement(name = "CUST_TP_CD", required = true)
	private String CustTpCd;
	@XmlElement(name = "ALT_CUST_CD", required = true)
	private String AltCustCd;
	@XmlElement(name = "EMAIL_ADDR", required = true)
	private String EmailAddr;
	@XmlElement(name = "EMAIL_ADDR_SHIP_TO", required = true)
	private String EmailAddrShipTo;
	public int getCustCd() {
		return CustCd;
	}
	public void setCustCd(int custCd) {
		CustCd = custCd;
	}
	public String getSrtCd() {
		return SrtCd;
	}
	public void setSrtCd(String srtCd) {
		SrtCd = srtCd;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public String getFname() {
		return Fname;
	}
	public void setFname(String fname) {
		Fname = fname;
	}
	public String getInit() {
		return Init;
	}
	public void setInit(String init) {
		Init = init;
	}
	public String getLname() {
		return Lname;
	}
	public void setLname(String lname) {
		Lname = lname;
	}
	public String getAddr1() {
		return Addr1;
	}
	public void setAddr1(String addr1) {
		Addr1 = addr1;
	}
	public String getAddr2() {
		return Addr2;
	}
	public void setAddr2(String addr2) {
		Addr2 = addr2;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getStcd() {
		return Stcd;
	}
	public void setStcd(String stcd) {
		Stcd = stcd;
	}
	public String getZipcd() {
		return Zipcd;
	}
	public void setZipcd(String zipcd) {
		Zipcd = zipcd;
	}
	public String getHomePhone() {
		return HomePhone;
	}
	public void setHomePhone(String homePhone) {
		HomePhone = homePhone;
	}
	public String getBusPhone() {
		return BusPhone;
	}
	public void setBusPhone(String busPhone) {
		BusPhone = busPhone;
	}
	public String getExt() {
		return Ext;
	}
	public void setExt(String ext) {
		Ext = ext;
	}
	public String getCorpName() {
		return CorpName;
	}
	public void setCorpName(String corpName) {
		CorpName = corpName;
	}
	public String getCustTpCd() {
		return CustTpCd;
	}
	public void setCustTpCd(String custTpCd) {
		CustTpCd = custTpCd;
	}
	public String getAltCustCd() {
		return AltCustCd;
	}
	public void setAltCustCd(String altCustCd) {
		AltCustCd = altCustCd;
	}
	public String getEmailAddr() {
		return EmailAddr;
	}
	public void setEmailAddr(String emailAddr) {
		EmailAddr = emailAddr;
	}
	public String getEmailAddrShipTo() {
		return EmailAddrShipTo;
	}
	public void setEmailAddrShipTo(String emailAddrShipTo) {
		EmailAddrShipTo = emailAddrShipTo;
	}

}
