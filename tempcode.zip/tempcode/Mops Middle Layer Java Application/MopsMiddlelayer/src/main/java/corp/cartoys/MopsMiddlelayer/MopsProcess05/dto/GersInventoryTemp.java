package corp.cartoys.MopsMiddlelayer.MopsProcess05.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

/**
 * The data transfer object for gers_inv_temp table.
 * @author jjude
 */
@Entity
@Table(name = "gers_inv_temp")
@NamedNativeQueries({
	@NamedNativeQuery(
	name        = "GersInventoryTemp.TruncateTable",
	query       = "TRUNCATE TABLE gers_inv_temp",
	resultClass = GersInventoryTemp.class
	),
	@NamedNativeQuery(
	name        = "GersInventoryTemp.GersInventorySp",
	query       = "CALL gers_inv_qty_insert_update",
	resultClass = GersInventoryTemp.class
	)
})
public class GersInventoryTemp {
	@Id
	private String MonsoonOP;
	private String sku;
	private Double Qty;
	
	public String getMonsoonOP() {
		return MonsoonOP;
	}
	public void setMonsoonOP(String monsoonOP) {
		MonsoonOP = monsoonOP;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public Double getQty() {
		return Qty;
	}
	public void setQty(Double qty) {
		Qty = qty;
	}
}
