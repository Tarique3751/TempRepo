package corp.cartoys.MopsMiddlelayer.MopsProcess05;

import java.io.File;
import java.io.FileWriter;
import java.util.Date;
import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;

import corp.cartoys.MopsMiddlelayer.HibernateManager;
import corp.cartoys.MopsMiddlelayer.MopsProcess05.dto.GersInventory;
import corp.cartoys.MopsMiddlelayer.MopsProcess05.dto.GersInventoryAllItemList;
import corp.cartoys.MopsMiddlelayer.MopsProcess05.dto.GersInventoryTemp;

/**
 * Calls the gers inventory webservice, inserts into the database and generates the gers inventory file.
 * @author jjude
 */
public class GersInventoryFileGenerator {
	
	String newLineChar = System.getProperty("line.separator"); //To get the newline character of corresponding platform
	static Logger log  = Logger.getLogger(GersInventoryFileGenerator.class.getName());
	String timeStamp   = new java.text.SimpleDateFormat("yyyy-MM-dd h:mm:ss").format(new Date());
	
	/**
	* Calls the gers inventory webservice, inserts into the database and generates the gers inventory file.
	* @param Nothing.
	* @return Nothing.
	*/
	public void generateInventoryTsv()
	{
		String logMessage         = newLineChar + "Webservice called at " + timeStamp + newLineChar;
		Client client             = ClientBuilder.newClient();
		String gersInvFileHeader  = "MonsoonOP" + Process05Launcher.dataSplitDelimiter + "SKU" + Process05Launcher.dataSplitDelimiter + "Quantity" + newLineChar;
		String gersInvFileContent = gersInvFileHeader;
		try
		{
			WebTarget target   = client.target(Process05Launcher.webServiceUrl);
			int responseStatus = target.request(MediaType.APPLICATION_JSON).get().getStatus();
			
			if(responseStatus == 200) // generate gers inventory only if webservice return status is 200
			{
				GersInventory[] response = target.request(MediaType.APPLICATION_JSON).get(GersInventory[].class);
				
				Session session = HibernateManager.getSessionFactory().openSession();
				session.beginTransaction();
				// Truncate the table gers_inv_temp before insertion.
				Query truncateGersInv = session.getNamedQuery("GersInventoryTemp.TruncateTable");
				truncateGersInv.executeUpdate();
				for (GersInventory res : response) 
				{
					Session invSession = HibernateManager.getSessionFactory().openSession();
					GersInventoryTemp gersInventoryTemp = new GersInventoryTemp();
					
					gersInventoryTemp.setMonsoonOP(res.getMonsoonop());
					gersInventoryTemp.setSku(res.getSku());
					gersInventoryTemp.setQty(Double.parseDouble(res.getQuantity()));
					invSession.save(gersInventoryTemp);
					invSession.flush();
					try
					{
						invSession.getTransaction().commit();
					}
					catch(Exception e)
					{
						invSession.getTransaction().rollback();
					}
					invSession.close();
				}
				// Call gers_inv_qty_insert_update stored procedure after insertion into gers_inv_temp
				Query gersInvSp = session.getNamedQuery("GersInventoryTemp.GersInventorySp");
				gersInvSp.executeUpdate();
				session.close();
				
				//Generate the gers inventory file
				session = HibernateManager.getSessionFactory().openSession();;
				Query query = session.getNamedQuery("GersInventoryAllItemList.GetInvDetails");
				List<GersInventoryAllItemList> resultsList = query.list();
				if(!resultsList.isEmpty())
				{
					for (GersInventoryAllItemList res : resultsList) 
					{
						gersInvFileContent = gersInvFileContent + res.getGers_inv_mnsn_op() + Process05Launcher.dataSplitDelimiter + res.getGers_inv_item_code() + Process05Launcher.dataSplitDelimiter + res.getGers_inv_qty() + newLineChar;
					}
				}
				session.close();
				
				//Generate gers inventory file only if data is fetched from db.
				if(!gersInvFileContent.equalsIgnoreCase(gersInvFileHeader)) //Checks whether content is not empty.
				{
					try
					{
						File file             = new File( Process05Launcher.outputFolderPath + "/" + Process05Launcher.fileName + new java.text.SimpleDateFormat("yyyyMMdd_hmmss").format(new Date()) + ".txt");
						FileWriter fileWriter = new FileWriter(file);
				        fileWriter.write(gersInvFileContent);
				        fileWriter.close();
				        
				        logMessage = logMessage + "Gers inventory file generated at path \'" + Process05Launcher.outputFolderPath + "/" + Process05Launcher.fileName + new java.text.SimpleDateFormat("yyyyMMdd_hmmss").format(new Date()) + ".txt" + "\'" + newLineChar;
					}
					catch(Exception e)
					{
						logMessage = logMessage + "Gers inventory file generation failed." + newLineChar + "Exception : " + e;
						
					}
				}
				
				//create the gers inventory log.
				GersInventoryLog gersInventoryLog = new GersInventoryLog();
				gersInventoryLog.generateLog();
			}
			else
			{
				logMessage = logMessage + "Error occured while fetching gers inventory. Webservice response status :" + responseStatus + newLineChar;
			}
		}
		catch(Exception e)
		{
			logMessage = logMessage + "Could not connect to webservice." + newLineChar;
		}
		
		log.info(logMessage);
	}
	
	
}
