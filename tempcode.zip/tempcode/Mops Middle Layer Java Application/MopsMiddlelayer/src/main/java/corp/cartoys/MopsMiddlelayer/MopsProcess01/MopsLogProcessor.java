package corp.cartoys.MopsMiddlelayer.MopsProcess01;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.apache.log4j.Logger;

/**
 * Log the processed files and check whether the processed files are valid order files.
 * @author jjude
 */
public class MopsLogProcessor implements Processor {
	
	String newLineChar                 = System.getProperty("line.separator"); //To get the newline character of corresponding platform
	public static int fileRecordsCount = 1;
	static Logger log                  = Logger.getLogger(MopsLogProcessor.class.getName());
	
	public void process(Exchange exchange) throws Exception {
		int validOrderFile = 1;
		String fileStatus  = "";
		String filePath    = exchange.getIn().getBody().toString();
		filePath           = filePath.substring(filePath.indexOf("[") + 1, filePath.indexOf("]"));
		String fileContent = exchange.getIn().getBody(String.class);
		Path p             = Paths.get(filePath);
		String fileName    = p.getFileName().toString();
		
		//Check if the file is valid order file
		try
		{
			String[] fileContentArr     = fileContent.split("\n");
			fileRecordsCount            = fileContentArr.length - 1; // Store how many records are present in an incoming file
			String validOrderFileHeader =   "MonsoonOrderId" + Process01Launcher.dataSplitDelimiter 
											+ "OrderStatus" + Process01Launcher.dataSplitDelimiter 
											+ "MarketName" + Process01Launcher.dataSplitDelimiter 
											+ "MarketOrderId" + Process01Launcher.dataSplitDelimiter 
											+ "ShipMethod" + Process01Launcher.dataSplitDelimiter 
											+ "OrderDate" + Process01Launcher.dataSplitDelimiter 
											+ "ShipDate" + Process01Launcher.dataSplitDelimiter 
											+ "OrderNote"+ Process01Launcher.dataSplitDelimiter 
											+ "TrackingNumber"+ Process01Launcher.dataSplitDelimiter 
											+ "CarrierCode"+ Process01Launcher.dataSplitDelimiter 
											+ "BuyerEmail"+ Process01Launcher.dataSplitDelimiter 
											+ "BuyerName"+ Process01Launcher.dataSplitDelimiter 
											+ "ShipToName"+ Process01Launcher.dataSplitDelimiter 
											+ "Address1"+ Process01Launcher.dataSplitDelimiter 
											+ "Address2"+ Process01Launcher.dataSplitDelimiter 
											+ "City"+ Process01Launcher.dataSplitDelimiter 
											+ "State"+ Process01Launcher.dataSplitDelimiter 
											+ "PostalCode"+ Process01Launcher.dataSplitDelimiter 
											+ "Country"+ Process01Launcher.dataSplitDelimiter 
											+ "BuyerPhoneNumber"+ Process01Launcher.dataSplitDelimiter 
											+ "SKU"+ Process01Launcher.dataSplitDelimiter 
											+ "ASIN"+ Process01Launcher.dataSplitDelimiter
											+ "UPC"+ Process01Launcher.dataSplitDelimiter
											+ "Condition"+ Process01Launcher.dataSplitDelimiter
											+ "SkuOnMarket"+ Process01Launcher.dataSplitDelimiter
											+ "LocatorCode"+ Process01Launcher.dataSplitDelimiter
											+ "OrderedQuantity"+ Process01Launcher.dataSplitDelimiter
											+ "ShippedQuantity"+ Process01Launcher.dataSplitDelimiter
											+ "Price"+ Process01Launcher.dataSplitDelimiter
											+ "ShippingFee"+ Process01Launcher.dataSplitDelimiter
											+ "MarketPrice"+ Process01Launcher.dataSplitDelimiter
											+ "MarketShippingFee"+ Process01Launcher.dataSplitDelimiter
											+ "RefundAmount"+ Process01Launcher.dataSplitDelimiter
											+ "MarketRefundAmount"+ Process01Launcher.dataSplitDelimiter
											+ "Tax"+ Process01Launcher.dataSplitDelimiter
											+ "ShippingTax"+ Process01Launcher.dataSplitDelimiter
											+ "MarketOrderItemId"+ Process01Launcher.dataSplitDelimiter
											+ "FulfillmentType"+ Process01Launcher.dataSplitDelimiter
											+ "ManufacturerPartNum"+ Process01Launcher.dataSplitDelimiter
											+ "ShippingSurcharge"+ Process01Launcher.dataSplitDelimiter
											+ "PromotionalShippingDiscount";
			String orderFileHeader      = fileContentArr[0].trim();
			
			if(!orderFileHeader.equalsIgnoreCase(validOrderFileHeader))
			{
				validOrderFile = 0;
			}
		}
		catch(Exception e)
		{
			validOrderFile = 0;
		}
		
		if(validOrderFile == 1)
		{
			fileStatus = "Successfully Processed.";
		}
		else
		{
			fileStatus = "Invalid Order File. File has been moved to error directory.";
		}
		
		//Creating log
		String logMessage = newLineChar
				+ "Processed File - " + fileName + newLineChar
				+ "Processed File Path - " + filePath + newLineChar
				+ "Processed File Content - " + newLineChar + fileContent + newLineChar
				+ "Processed File Status - " + fileStatus + newLineChar
				+ newLineChar;
		log.info(logMessage);
		
		//Pass the ValidOrderFile bit in the camel message exchange header 
		Message newMessage = exchange.getIn(); 
		newMessage.setHeader("ValidOrderFile",validOrderFile);
	}

}
