package corp.cartoys.MopsMiddlelayer.MopsProcess01.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;

/**
 * The Data transfer object for gers_xml table.
 * @author jjude
 */
@Entity
@Table(name = "gers_xml")
@NamedQueries({
	@NamedQuery(
	name  = "GersXml.GetRecordsForXml",
	query = "FROM GersXml gx WHERE gx.TrnId = :TrnId"
	)
})
public class GersXml {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int GersXmlId;
	private int TrnId;
	private String OriginCd;
	private String CauseCd;
	private String EmpCdOp;
	private String EmpCdKeyer;
	private String FinCustCd;
	private String ShipToStCd;
	private String ShipToZoneCd;
	private String TaxCd;
	private String OrdTpCd;
	private String OrdSrtCd;
	private String SoStoreCd;
	private String PuDelStoreCd;
	private String SoEmpSlspCd1;
	private String SoWrDt;
	private String ShipToTitle;
	private String ShipToFname;
	private String ShipToLname;
	private String ShipToAddr1;
	private String ShipToAddr2;
	private String ShipToZipCd;
	private String ShipToHphone;
	private String ShipToBphone;
	private String ShipToExt;
	private String ShipToCity;
	private String ShipToCorp;
	private String PctOfSale1;
	private String PuDel;
	private String PuDelDt;
	private String DelChg;
	private String SetupChg;
	private String TaxChg;
	private String OrigDelDocNum;
	private String OrigFiAmt;
	private String ApprovalCd;
	private String RequestedFiAmount;
	private String AltDocNum;
	private String AltCustCd;
	public int getGersXmlId() {
		return GersXmlId;
	}
	public void setGersXmlId(int gersXmlId) {
		GersXmlId = gersXmlId;
	}
	public int getTrnId() {
		return TrnId;
	}
	public void setTrnId(int trnId) {
		TrnId = trnId;
	}
	public String getOriginCd() {
		return OriginCd;
	}
	public void setOriginCd(String originCd) {
		OriginCd = originCd;
	}
	public String getCauseCd() {
		return CauseCd;
	}
	public void setCauseCd(String causeCd) {
		CauseCd = causeCd;
	}
	public String getEmpCdOp() {
		return EmpCdOp;
	}
	public void setEmpCdOp(String empCdOp) {
		EmpCdOp = empCdOp;
	}
	public String getEmpCdKeyer() {
		return EmpCdKeyer;
	}
	public void setEmpCdKeyer(String empCdKeyer) {
		EmpCdKeyer = empCdKeyer;
	}
	public String getFinCustCd() {
		return FinCustCd;
	}
	public void setFinCustCd(String finCustCd) {
		FinCustCd = finCustCd;
	}
	public String getShipToStCd() {
		return ShipToStCd;
	}
	public void setShipToStCd(String shipToStCd) {
		ShipToStCd = shipToStCd;
	}
	public String getShipToZoneCd() {
		return ShipToZoneCd;
	}
	public void setShipToZoneCd(String shipToZoneCd) {
		ShipToZoneCd = shipToZoneCd;
	}
	public String getTaxCd() {
		return TaxCd;
	}
	public void setTaxCd(String taxCd) {
		TaxCd = taxCd;
	}
	public String getOrdTpCd() {
		return OrdTpCd;
	}
	public void setOrdTpCd(String ordTpCd) {
		OrdTpCd = ordTpCd;
	}
	public String getOrdSrtCd() {
		return OrdSrtCd;
	}
	public void setOrdSrtCd(String ordSrtCd) {
		OrdSrtCd = ordSrtCd;
	}
	public String getSoStoreCd() {
		return SoStoreCd;
	}
	public void setSoStoreCd(String soStoreCd) {
		SoStoreCd = soStoreCd;
	}
	public String getPuDelStoreCd() {
		return PuDelStoreCd;
	}
	public void setPuDelStoreCd(String puDelStoreCd) {
		PuDelStoreCd = puDelStoreCd;
	}
	public String getSoEmpSlspCd1() {
		return SoEmpSlspCd1;
	}
	public void setSoEmpSlspCd1(String soEmpSlspCd1) {
		SoEmpSlspCd1 = soEmpSlspCd1;
	}
	public String getSoWrDt() {
		return SoWrDt;
	}
	public void setSoWrDt(String soWrDt) {
		SoWrDt = soWrDt;
	}
	public String getShipToTitle() {
		return ShipToTitle;
	}
	public void setShipToTitle(String shipToTitle) {
		ShipToTitle = shipToTitle;
	}
	public String getShipToFname() {
		return ShipToFname;
	}
	public void setShipToFname(String shipToFname) {
		ShipToFname = shipToFname;
	}
	public String getShipToLname() {
		return ShipToLname;
	}
	public void setShipToLname(String shipToLname) {
		ShipToLname = shipToLname;
	}
	public String getShipToAddr1() {
		return ShipToAddr1;
	}
	public void setShipToAddr1(String shipToAddr1) {
		ShipToAddr1 = shipToAddr1;
	}
	public String getShipToAddr2() {
		return ShipToAddr2;
	}
	public void setShipToAddr2(String shipToAddr2) {
		ShipToAddr2 = shipToAddr2;
	}
	public String getShipToZipCd() {
		return ShipToZipCd;
	}
	public void setShipToZipCd(String shipToZipCd) {
		ShipToZipCd = shipToZipCd;
	}
	public String getShipToHphone() {
		return ShipToHphone;
	}
	public void setShipToHphone(String shipToHphone) {
		ShipToHphone = shipToHphone;
	}
	public String getShipToBphone() {
		return ShipToBphone;
	}
	public void setShipToBphone(String shipToBphone) {
		ShipToBphone = shipToBphone;
	}
	public String getShipToExt() {
		return ShipToExt;
	}
	public void setShipToExt(String shipToExt) {
		ShipToExt = shipToExt;
	}
	public String getShipToCity() {
		return ShipToCity;
	}
	public void setShipToCity(String shipToCity) {
		ShipToCity = shipToCity;
	}
	public String getShipToCorp() {
		return ShipToCorp;
	}
	public void setShipToCorp(String shipToCorp) {
		ShipToCorp = shipToCorp;
	}
	public String getPctOfSale1() {
		return PctOfSale1;
	}
	public void setPctOfSale1(String pctOfSale1) {
		PctOfSale1 = pctOfSale1;
	}
	public String getPuDel() {
		return PuDel;
	}
	public void setPuDel(String puDel) {
		PuDel = puDel;
	}
	public String getPuDelDt() {
		return PuDelDt;
	}
	public void setPuDelDt(String puDelDt) {
		PuDelDt = puDelDt;
	}
	public String getDelChg() {
		return DelChg;
	}
	public void setDelChg(String delChg) {
		DelChg = delChg;
	}
	public String getSetupChg() {
		return SetupChg;
	}
	public void setSetupChg(String setupChg) {
		SetupChg = setupChg;
	}
	public String getTaxChg() {
		return TaxChg;
	}
	public void setTaxChg(String taxChg) {
		TaxChg = taxChg;
	}
	public String getOrigDelDocNum() {
		return OrigDelDocNum;
	}
	public void setOrigDelDocNum(String origDelDocNum) {
		OrigDelDocNum = origDelDocNum;
	}
	public String getOrigFiAmt() {
		return OrigFiAmt;
	}
	public void setOrigFiAmt(String origFiAmt) {
		OrigFiAmt = origFiAmt;
	}
	public String getApprovalCd() {
		return ApprovalCd;
	}
	public void setApprovalCd(String approvalCd) {
		ApprovalCd = approvalCd;
	}
	public String getRequestedFiAmount() {
		return RequestedFiAmount;
	}
	public void setRequestedFiAmount(String requestedFiAmount) {
		RequestedFiAmount = requestedFiAmount;
	}
	public String getAltDocNum() {
		return AltDocNum;
	}
	public void setAltDocNum(String altDocNum) {
		AltDocNum = altDocNum;
	}
	public String getAltCustCd() {
		return AltCustCd;
	}
	public void setAltCustCd(String altCustCd) {
		AltCustCd = altCustCd;
	}
}
