package corp.cartoys.MopsMiddlelayer.MopsProcess02;

import corp.cartoys.MopsMiddlelayer.MopsProcess02.Process02Launcher;

import org.apache.log4j.Logger;

/**
 * Camel route that reads the Gers pass or fail file and inserts the data into database.
 * @author jjude
 */
public class MopsProcess02RouteBuilder extends org.apache.camel.builder.RouteBuilder{
	
	String newLineChar = System.getProperty("line.separator"); //To get the newline character of corresponding platform
	static Logger log  = Logger.getLogger(MopsProcess02RouteBuilder.class.getName());
	
	public void configure() throws Exception
	{
		try
		{
			//Camel Route 1 : Pick up file and check whether its a pass file or fail file.
			from("file:"+Process02Launcher.inputFolderPath+"?readLock=changed&move=./processed&include="+Process02Launcher.acceptedFileListRegExp).
			process(new MopsFileProcessor()).
			choice().
				when(header("FileType").isEqualTo("pass")).
					to("direct:PassFileQueue").
				when(header("FileType").isEqualTo("fail")).
					to("direct:FailFileQueue").
				when(header("FileType").isEqualTo("already_processed")).
					to("direct:Process02AlreadyProcessedFileQueue").
				otherwise().
					to("direct:Process02InvalidFileQueue").
			end();
			
			//Camel Route 2 : To Process the pass files
			from("direct:PassFileQueue").
			split().tokenize("\n",1). //Use camel splitter to forward each csv row sepeartely to the bean.
			choice().
				when(simple("${property.CamelSplitIndex} > 0")). //Avoid the csv headers.
					doTry().
						bean(new InsertCsvToDatabase(),"processPassFile").
					doCatch(Exception.class).
						process(new InvalidDataLogger()). //Exception occured when a row was processed ,hence it was not inserted in to DB.
					end().
			end();
			
			//Camel Route 3 : To Process the fail files
			from("direct:FailFileQueue").
			split().tokenize("\n",1). //Use camel splitter to forward each csv row sepeartely to the bean.
			choice().
				when(simple("${property.CamelSplitIndex} > 0")). //Avoid the csv headers.
					doTry().
						bean(new InsertCsvToDatabase(),"processFailFile").
					doCatch(Exception.class).
						process(new InvalidDataLogger()). //Exception occured when a row was processed ,hence it was not inserted in to DB.
					end().
			end();
			
			//Camel Route 4 : To Process the already processed files
			from("direct:Process02AlreadyProcessedFileQueue").
			to("file:" + Process02Launcher.inputFolderPath + "/already-processed");
			
			//Camel Route 5 : To Process the invalid files
			from("direct:Process02InvalidFileQueue").
			to("file:" + Process02Launcher.inputFolderPath + "/invalid");
		}
		catch(Exception e)
		{
			String logMessage = newLineChar
					+ "Something went wrong.Please ensure that the input and output folder paths are configured correctly in AppConfig.properties file." + newLineChar
					+ "Exception : " + e + newLineChar
					+ newLineChar;
			log.info(logMessage);
		} 
	}
}