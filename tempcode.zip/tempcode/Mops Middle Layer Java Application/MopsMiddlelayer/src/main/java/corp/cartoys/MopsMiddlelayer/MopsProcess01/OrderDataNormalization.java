package corp.cartoys.MopsMiddlelayer.MopsProcess01;

import org.hibernate.Query;
import org.hibernate.Session;

import corp.cartoys.MopsMiddlelayer.HibernateManager;

/**
 * Normalize the data in temporary table and insert into tables mnsn_order_header and mnsn_order_details
 * @author jjude
 */
public class OrderDataNormalization {
	
	/**
	 * Calls the Normalization stored procedure to split the orders into header and order details.
	 * @param Nothing.
	 * @return Nothing.
	 */
	public void normalizeOrderData()
	{
		//Call the Normalization SP to insert data into mnsn_order_header and mnsn_order_details tables
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		
		Query normalizeOrderDataQry = session.getNamedQuery("MnsnOrderForWeblink.OrderDataNormalizationSP");
		normalizeOrderDataQry.executeUpdate();
		
		session.close();
	}
}
