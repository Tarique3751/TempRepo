package corp.cartoys.MopsMiddlelayer.MopsProcess01.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;

/**
 * The Data transfer object for directory_country_region table.
 * @author jjude
 */
@Entity
@Table(name = "directory_country_region")
@NamedQueries({
	@NamedQuery(
	name  = "DirectoryCountryRegion.GetStateCode",
	query = "FROM DirectoryCountryRegion dcr WHERE dcr.default_name = :DefaultName"
	)
})
public class DirectoryCountryRegion {
	@Id
	private int region_id;
	private String country_id;
	private String code;
	private String default_name;
	public int getRegion_id() {
		return region_id;
	}
	public void setRegion_id(int region_id) {
		this.region_id = region_id;
	}
	public String getCountry_id() {
		return country_id;
	}
	public void setCountry_id(String country_id) {
		this.country_id = country_id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDefault_name() {
		return default_name;
	}
	public void setDefault_name(String default_name) {
		this.default_name = default_name;
	}
}
