package corp.cartoys.MopsMiddlelayer.MopsProcess01.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;

/**
 * The Data transfer object for mnsn_order_details table.
 * @author jjude
 */
@Entity
@Table(name = "mnsn_order_details")
@NamedQueries({
	@NamedQuery(
	name  = "MnsnOrderDetails.GetOrderDetailsForXml",
	query = "FROM MnsnOrderDetails mod WHERE mod.MonsoonOrderId = :MonsoonOrderId"
	)
})
public class MnsnOrderDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int MonsoonOrderDtId;
	private int MonsoonOrderHdId;
	private int MonsoonOrderId;
	private String SKU;
	private String ASIN;
	private String UPC;
	private String Conditions;
	private String SkuOnMarket;
	private String LocatorCode;
	private int OrderedQuantity;
	private int ShippedQuantity;
	private String Price;
	private String ShippingFee;
	private String MarketPrice;
	private String MarketShippingFee;
	private String RefundAmount;
	private String MarketRefundAmount;
	private String Tax;
	private String ShippingTax;
	private String MarketOrderItemId;
	private String FulfillmentType;
	private String ManufacturerPartNum;
	private String ShippingSurcharge;
	private Double PromotionalShippingDiscount;
	
	public int getMonsoonOrderDtId() {
		return MonsoonOrderDtId;
	}
	public void setMonsoonOrderDtId(int monsoonOrderDtId) {
		MonsoonOrderDtId = monsoonOrderDtId;
	}
	public int getMonsoonOrderHdId() {
		return MonsoonOrderHdId;
	}
	public void setMonsoonOrderHdId(int monsoonOrderHdId) {
		MonsoonOrderHdId = monsoonOrderHdId;
	}
	public int getMonsoonOrderId() {
		return MonsoonOrderId;
	}
	public void setMonsoonOrderId(int monsoonOrderId) {
		MonsoonOrderId = monsoonOrderId;
	}
	public String getSKU() {
		return SKU;
	}
	public void setSKU(String sKU) {
		SKU = sKU;
	}
	public String getASIN() {
		return ASIN;
	}
	public void setASIN(String aSIN) {
		ASIN = aSIN;
	}
	public String getUPC() {
		return UPC;
	}
	public void setUPC(String uPC) {
		UPC = uPC;
	}
	public String getConditions() {
		return Conditions;
	}
	public void setConditions(String conditions) {
		Conditions = conditions;
	}
	public String getSkuOnMarket() {
		return SkuOnMarket;
	}
	public void setSkuOnMarket(String skuOnMarket) {
		SkuOnMarket = skuOnMarket;
	}
	public String getLocatorCode() {
		return LocatorCode;
	}
	public void setLocatorCode(String locatorCode) {
		LocatorCode = locatorCode;
	}
	public int getOrderedQuantity() {
		return OrderedQuantity;
	}
	public void setOrderedQuantity(int orderedQuantity) {
		OrderedQuantity = orderedQuantity;
	}
	public int getShippedQuantity() {
		return ShippedQuantity;
	}
	public void setShippedQuantity(int shippedQuantity) {
		ShippedQuantity = shippedQuantity;
	}
	public String getPrice() {
		return Price;
	}
	public void setPrice(String price) {
		Price = price;
	}
	public String getShippingFee() {
		return ShippingFee;
	}
	public void setShippingFee(String shippingFee) {
		ShippingFee = shippingFee;
	}
	public String getMarketPrice() {
		return MarketPrice;
	}
	public void setMarketPrice(String marketPrice) {
		MarketPrice = marketPrice;
	}
	public String getMarketShippingFee() {
		return MarketShippingFee;
	}
	public void setMarketShippingFee(String marketShippingFee) {
		MarketShippingFee = marketShippingFee;
	}
	public String getRefundAmount() {
		return RefundAmount;
	}
	public void setRefundAmount(String refundAmount) {
		RefundAmount = refundAmount;
	}
	public String getMarketRefundAmount() {
		return MarketRefundAmount;
	}
	public void setMarketRefundAmount(String marketRefundAmount) {
		MarketRefundAmount = marketRefundAmount;
	}
	public String getTax() {
		return Tax;
	}
	public void setTax(String tax) {
		Tax = tax;
	}
	public String getShippingTax() {
		return ShippingTax;
	}
	public void setShippingTax(String shippingTax) {
		ShippingTax = shippingTax;
	}
	public String getMarketOrderItemId() {
		return MarketOrderItemId;
	}
	public void setMarketOrderItemId(String marketOrderItemId) {
		MarketOrderItemId = marketOrderItemId;
	}
	public String getFulfillmentType() {
		return FulfillmentType;
	}
	public void setFulfillmentType(String fulfillmentType) {
		FulfillmentType = fulfillmentType;
	}
	public String getManufacturerPartNum() {
		return ManufacturerPartNum;
	}
	public void setManufacturerPartNum(String manufacturerPartNum) {
		ManufacturerPartNum = manufacturerPartNum;
	}
	public String getShippingSurcharge() {
		return ShippingSurcharge;
	}
	public void setShippingSurcharge(String shippingSurcharge) {
		ShippingSurcharge = shippingSurcharge;
	}
	public Double getPromotionalShippingDiscount() {
		return PromotionalShippingDiscount;
	}
	public void setPromotionalShippingDiscount(Double promotionalShippingDiscount) {
		PromotionalShippingDiscount = promotionalShippingDiscount;
	}
}
