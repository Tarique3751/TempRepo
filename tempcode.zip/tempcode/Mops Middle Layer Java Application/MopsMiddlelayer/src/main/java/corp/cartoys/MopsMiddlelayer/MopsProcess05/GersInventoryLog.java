package corp.cartoys.MopsMiddlelayer.MopsProcess05;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;

import corp.cartoys.MopsMiddlelayer.HibernateManager;

/**
 * Creates the gers inventory log file.
 * @author jjude
 */
public class GersInventoryLog {
	String newLineChar = System.getProperty("line.separator"); //To get the newline character of corresponding platform
	static Logger log = Logger.getLogger(GersInventoryLog.class.getName());
	/**
	* Generates the gers inventory log file.
	* @param Nothing.
	* @return Nothing.
	*/
	public void generateLog()
	{
		String logFileContent = newLineChar;
		System.out.println("Data : " + new java.text.SimpleDateFormat("yyyy-MM-dd").format(new Date()));
		
		Session session = HibernateManager.getSessionFactory().openSession();
		// The query that fetches the data for log file
		String tsvSql = "SELECT gers_inv_history_created_date,gers_inv_history_description FROM gers_inv_history "
					+ "WHERE gers_inv_history_created_date > STR_TO_DATE('"+ new java.text.SimpleDateFormat("yyyy-MM-dd").format(new Date()) + "','%Y-%m-%d') " 
					+ "ORDER BY gers_inv_history_created_date DESC;";
		SQLQuery query = session.createSQLQuery(tsvSql);
		
		List<Object[]> entities = query.list();
		for (Object[] entity : entities) {
			for (Object entityCol : entity) {
				logFileContent = logFileContent + entityCol + Process05Launcher.dataSplitDelimiter;
			}
			logFileContent = logFileContent + newLineChar;
		}
		log.info(logFileContent);
	}
}
