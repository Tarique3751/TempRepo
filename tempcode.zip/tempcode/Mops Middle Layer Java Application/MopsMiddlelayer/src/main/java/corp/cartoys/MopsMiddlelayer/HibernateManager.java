package corp.cartoys.MopsMiddlelayer;

import java.io.File;
import org.hibernate.*;
import org.hibernate.cfg.*;

/**
 * Create the Session Factory Singleton Object for Hibernate.
 * @author jjude
 */
public class HibernateManager // Hibernate utility class
{
  private static final SessionFactory sessionFactory;
  
  static 
  {    //create sessionFactory object only once    
    try
    {          
    	File file      = new File("./HibernateConfig/hibernate.cfg.xml"); //Path where the hibernate config file is kept
    	sessionFactory = new Configuration().configure(file).buildSessionFactory();
    } 
    catch (Throwable ex) 
    {
    	System.err.println("Application terminated. Could not connect to database.");
    	System.exit(0);
    	throw new ExceptionInInitializerError(ex);
    }
  }
  public static SessionFactory getSessionFactory() {
     return sessionFactory;
  }
} 