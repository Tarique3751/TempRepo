package corp.cartoys.MopsMiddlelayer.MopsProcess01;

import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;

import corp.cartoys.MopsMiddlelayer.HibernateManager;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.OrdersBizRules.AmazonCtoBusinessRules;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.OrdersBizRules.AmazonFbaBusinessRules;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.OrdersBizRules.EbayCtoBusinessRules;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.OrdersBizRules.EbayFbaBusinessRules;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.dto.MnsnOrderDetails;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.dto.MnsnOrderHeader;

/**
 * Fetch the normalized records from Db and apply the corresponding business rules to them.
 * @author jjude
 */
public class ExtractNormalizedData {

	public static int monsoonOrderHdId;
	public static int monsoonOrderId;
	public static String orderStatus;
	public static String marketName;
	public static String marketOrderId;
	public static String shipMethod;
	public static String orderDate;
	public static String shipDate;
	public static String orderNote;
	public static String trackingNumber;
	public static String carrierCode;
	public static String buyerEmail;
	public static String buyerName;
	public static String firstName;
	public static String lastName;
	public static String shipToName;
	public static String address1;
	public static String address2;
	public static String city;
	public static String state;
	public static String postalCode;
	public static String country;
	public static String buyerPhoneNumber;
	public static String createdDate;
	public static String returns;
	public static String locationCode;
	public static String automaticImportErrorDetails;
	public static String company;
	public static int alreadyExists;
	
	public static String sku;
	public static String asin;
	public static String upc;
	public static String conditn;
	public static String skuOnMarket;
	public static String locatorCode;
	public static int orderedQuantity;
	public static int shippedQuantity;
	public static String price;
	public static String shippingFee;
	public static String marketPrice;
	public static String marketShippingFee;
	public static String refundAmount;
	public static String marketRefundAmount;
	public static String tax;
	public static String shippingTax;
	public static String marketOrderItemId;
	public static String fulfillmentType;
	public static String manufacturerPartNum;
	public static String shippingSurcharge;
	public static Double promotionalShippingDiscount;
	
	public int STATUS_ID_FOR_XML_GENERATION        = Integer.parseInt(Process01Launcher.STATUS_ID_FOR_XML_GENERATION);
	public int STATUS_ID_FOR_XML_GENERATED_RECORDS = Integer.parseInt(Process01Launcher.STATUS_ID_FOR_XML_GENERATED_RECORDS);
	public String AMAZON_MARKET_NAME               = Process01Launcher.AMAZON_MARKET_NAME;
	public String EBAY_MARKET_NAME                 = Process01Launcher.EBAY_MARKET_NAME;
	public static Double totalAmount;
	public static int lengthOfAddress;
	public static int multipleSkuWrn;
	public static Double taxChg;
	
	 /**
	 * Fetch the data from mnsn_order_header and mnsn_order_details table and apply business rules to the data.
	 * @param Nothing.
	 * @return Nothing.
	 */
	public void fetchNormalizedRecords() throws Exception{
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		//Fetch only the records with ImportStatus 0 and AutomaticImportStatus 1 (newly inserted orders)
		Query query = session.getNamedQuery("MnsnOrderHeader.GetRecordsForXml").setString("ImportStatus", "0").setString("AutomaticImportStatus", "1");
		List<MnsnOrderHeader> resultsList = query.list();
		
		for (MnsnOrderHeader res : resultsList) 
		{
			monsoonOrderHdId            = res.getMonsoonOrderHdId();
			monsoonOrderId              = res.getMonsoonOrderId();
			orderStatus                 = res.getOrderStatus();
			marketName                  = res.getMarketName();
			marketOrderId               = res.getMarketOrderId();
			shipMethod                  = res.getShipMethod();
			orderDate                   = res.getOrderDate();
			shipDate                    = res.getShipMethod();
			orderNote                   = res.getOrderNote();
			trackingNumber              = res.getTrackingNumber();
			carrierCode                 = res.getCarrierCode();
			buyerEmail                  = res.getBuyerEmail();
			buyerName                   = res.getBuyerName();
			firstName                   = res.getFirstName();
			lastName                    = res.getLastName();
			shipToName                  = res.getShipToName();
			address1                    = res.getAddress1();
			address2                    = res.getAddress2();
			city                        = res.getCity();
			state                       = res.getState();
			postalCode                  = res.getPostalCode();
			country                     = res.getCountry();
			buyerPhoneNumber            = res.getBuyerPhoneNumber();
			createdDate                 = res.getCreatedDate();
			returns                     = res.getReturns();
			locationCode                = res.getLocationCode();
			automaticImportErrorDetails = res.getAutomaticImportErrorDetails();
			company                     = res.getCompany();
			alreadyExists               = res.getAlreadyExist();
			
			totalAmount                 = 0.00;
			lengthOfAddress             = address1.length();
			multipleSkuWrn              = 0;
			String[] skuList;
			taxChg                      = 0.00;
			
			//Fetch the order details for a particular MonsoonOrderId
			Session orderDetailsSession = HibernateManager.getSessionFactory().openSession();
			orderDetailsSession.beginTransaction();
			
			Query orderDetailsQuery                 = orderDetailsSession.getNamedQuery("MnsnOrderDetails.GetOrderDetailsForXml").setLong("MonsoonOrderId", res.getMonsoonOrderId());
			List<MnsnOrderDetails> orderDetailsList = orderDetailsQuery.list();
			
			for (MnsnOrderDetails orderDetail : orderDetailsList)
			{
				//Calculate the total amount of all orders of a particular MonsoonOrderId
				marketPrice = orderDetail.getMarketPrice();
				shippingFee = orderDetail.getShippingFee();
				tax         = orderDetail.getTax();
				shippingTax = orderDetail.getShippingTax();
				
				if(marketPrice.equals(""))
				{
					marketPrice = "0.00";
				}
				if(shippingFee.equals(""))
				{
					shippingFee = "0.00";
				}
				if(tax.equals(""))
				{
					tax = "0.00";
				}
				if(shippingTax.equals(""))
				{
					shippingTax = "0.00";
				}
				totalAmount = totalAmount + Double.parseDouble(marketPrice) + Double.parseDouble(shippingFee) + Double.parseDouble(tax) +  Double.parseDouble(shippingTax);
				//Calculate taxChg
				taxChg      = taxChg + Double.parseDouble(tax) + Double.parseDouble(shippingTax);
			}
			//Check if same sku value is present for the same monsoon order
			Set<String> keys = DbInsertion.monsoonOrderSKUs.keySet();
	        // iterate through the key set
			for (String key : keys)
			{
				if(key.equalsIgnoreCase(String.valueOf(monsoonOrderId)))
				{
					skuList = DbInsertion.monsoonOrderSKUs.get(key).toString().substring(DbInsertion.monsoonOrderSKUs.get(key).toString().indexOf("[") + 1, DbInsertion.monsoonOrderSKUs.get(key).toString().indexOf("]")).split(",");
					for (int i = 0; i < skuList.length; i++) 
					{ 
						for (int j = i + 1 ; j < skuList.length; j++) 
						{ 
							if ((skuList[i].trim()).equalsIgnoreCase(skuList[j].trim())  && (i != j)) 
							{ 
								// got the duplicate sku
								multipleSkuWrn = 1;
							}
						} 
					}
					
				}
			}
			for (MnsnOrderDetails orderDetail : orderDetailsList)
			{
				sku                         = orderDetail.getSKU();
				asin                        = orderDetail.getASIN();
				upc                         = orderDetail.getUPC();
				conditn                     = orderDetail.getConditions();
				skuOnMarket                 = orderDetail.getSkuOnMarket();
				locatorCode                 = orderDetail.getLocatorCode();
				orderedQuantity             = orderDetail.getOrderedQuantity();
				shippedQuantity             = orderDetail.getShippedQuantity();
				price                       = orderDetail.getPrice();
				shippingFee                 = orderDetail.getShippingFee();
				marketPrice                 = orderDetail.getMarketPrice();
				marketShippingFee           = orderDetail.getMarketShippingFee();
				refundAmount                = orderDetail.getRefundAmount();
				marketRefundAmount          = orderDetail.getMarketRefundAmount();
				tax                         = orderDetail.getTax();
				shippingTax                 = orderDetail.getShippingTax();
				marketOrderItemId           = orderDetail.getMarketOrderItemId();
				fulfillmentType             = orderDetail.getFulfillmentType();
				manufacturerPartNum         = orderDetail.getManufacturerPartNum();
				shippingSurcharge           = orderDetail.getShippingSurcharge();
				promotionalShippingDiscount = orderDetail.getPromotionalShippingDiscount();
				
				//Apply the business rules to the order data and update the database
				if(marketName.equalsIgnoreCase(AMAZON_MARKET_NAME))
				{	
					if(fulfillmentType.equalsIgnoreCase("Local"))
					{
						String[] amazonCtoRuleList = {"./OrdersBusinessRules/Amazon/AmzCtoBizRulesForOrders.drl","./GersXmlBusinessRules/Amazon/AmzCtoBizRulesForGers.drl"};
						AmazonCtoBusinessRules amazonCtoBusinessRules = new AmazonCtoBusinessRules(monsoonOrderHdId, monsoonOrderId, orderStatus, marketName, marketOrderId, shipMethod, orderDate, shipDate, orderNote, trackingNumber, carrierCode, buyerEmail, buyerName, firstName, lastName, shipToName, address1, address2, city, state, postalCode, country, buyerPhoneNumber, createdDate, returns, locationCode, automaticImportErrorDetails, company, alreadyExists, totalAmount, lengthOfAddress, fulfillmentType, sku, price, orderedQuantity, multipleSkuWrn, taxChg);
						amazonCtoBusinessRules.executeRules(amazonCtoRuleList,amazonCtoBusinessRules);
					}
					else if(fulfillmentType.equalsIgnoreCase("FBA"))
					{
						String[] amazonFbaRuleList = {"./OrdersBusinessRules/Amazon/AmzFbaBizRulesForOrders.drl","./GersXmlBusinessRules/Amazon/AmzFbaBizRulesForGers.drl"};
						AmazonFbaBusinessRules amazonFbaBusinessRules = new AmazonFbaBusinessRules(monsoonOrderHdId, monsoonOrderId, orderStatus, marketName, marketOrderId, shipMethod, orderDate, shipDate, orderNote, trackingNumber, carrierCode, buyerEmail, buyerName, firstName, lastName, shipToName, address1, address2, city, state, postalCode, country, buyerPhoneNumber, createdDate, returns, locationCode, automaticImportErrorDetails, company, alreadyExists, totalAmount, lengthOfAddress, fulfillmentType, sku, price, orderedQuantity, multipleSkuWrn, taxChg);
						amazonFbaBusinessRules.executeRules(amazonFbaRuleList,amazonFbaBusinessRules);
					}
				}
				else if(marketName.equalsIgnoreCase(EBAY_MARKET_NAME))
				{
					if(fulfillmentType.equalsIgnoreCase("Local"))
					{
						String[] ebayCtoRuleList = {"./OrdersBusinessRules/Ebay/EbayCtoBizRulesForOrders.drl","./GersXmlBusinessRules/Ebay/EbayCtoBizRulesForGers.drl"};
						EbayCtoBusinessRules ebayCtoBusinessRules = new EbayCtoBusinessRules(monsoonOrderHdId, monsoonOrderId, orderStatus, marketName, marketOrderId, shipMethod, orderDate, shipDate, orderNote, trackingNumber, carrierCode, buyerEmail, buyerName, firstName, lastName, shipToName, address1, address2, city, state, postalCode, country, buyerPhoneNumber, createdDate, returns, locationCode, automaticImportErrorDetails, company, alreadyExists, totalAmount, lengthOfAddress, fulfillmentType, sku, price, orderedQuantity, multipleSkuWrn, taxChg);
						ebayCtoBusinessRules.executeRules(ebayCtoRuleList,ebayCtoBusinessRules);
					}
					else if(fulfillmentType.equalsIgnoreCase("FBA"))
					{
						String[] ebayFbaRuleList = {"./OrdersBusinessRules/Ebay/EbayFbaBizRulesForOrders.drl","./GersXmlBusinessRules/Ebay/EbayFbaBizRulesForGers.drl"};
						EbayFbaBusinessRules ebayFbaBusinessRules = new EbayFbaBusinessRules(monsoonOrderHdId, monsoonOrderId, orderStatus, marketName, marketOrderId, shipMethod, orderDate, shipDate, orderNote, trackingNumber, carrierCode, buyerEmail, buyerName, firstName, lastName, shipToName, address1, address2, city, state, postalCode, country, buyerPhoneNumber, createdDate, returns, locationCode, automaticImportErrorDetails, company, alreadyExists, totalAmount, lengthOfAddress, fulfillmentType, sku, price, orderedQuantity, multipleSkuWrn,taxChg);
						ebayFbaBusinessRules.executeRules(ebayFbaRuleList,ebayFbaBusinessRules);
					}
				}
			}
			orderDetailsSession.close();
		}
		//Clear out the SKU hashmap
		DbInsertion.monsoonOrderSKUs.clear();
		session.close();
	}
}
