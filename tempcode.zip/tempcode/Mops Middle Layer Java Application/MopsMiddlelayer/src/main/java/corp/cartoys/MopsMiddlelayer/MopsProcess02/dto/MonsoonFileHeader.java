package corp.cartoys.MopsMiddlelayer.MopsProcess02.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;

/**
 * The Data transfer object for mnsn_file_header table.
 * @author jjude
 */
@Entity
@Table(name = "mnsn_file_header")
@NamedQueries({
	@NamedQuery(
	name  = "Process02MonsoonFileHeader.CheckFileNameExists",
	query = "FROM MonsoonFileHeader mfh WHERE mfh.FileName = :FileName"
	)
})
public class MonsoonFileHeader {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int FileId;
	private String FileName;
	private String CreatedBy;
	private String CreatedOn;
	private String UpdatedBy;
	private String UpdatedOn;
	private String CreatedFrom;
	private int active;
	
	public int getFileId() {
		return FileId;
	}
	public void setFileId(int fileId) {
		FileId = fileId;
	}
	public String getFileName() {
		return FileName;
	}
	public void setFileName(String fileName) {
		FileName = fileName;
	}
	public String getCreatedBy() {
		return CreatedBy;
	}
	public void setCreatedBy(String createdBy) {
		CreatedBy = createdBy;
	}
	public String getCreatedOn() {
		return CreatedOn;
	}
	public void setCreatedOn(String createdOn) {
		CreatedOn = createdOn;
	}
	public String getUpdatedBy() {
		return UpdatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		UpdatedBy = updatedBy;
	}
	public String getUpdatedOn() {
		return UpdatedOn;
	}
	public void setUpdatedOn(String updatedOn) {
		UpdatedOn = updatedOn;
	}
	public String getCreatedFrom() {
		return CreatedFrom;
	}
	public void setCreatedFrom(String createdFrom) {
		CreatedFrom = createdFrom;
	}
	public int getActive() {
		return active;
	}
	public void setActive(int active) {
		this.active = active;
	}
}
