package corp.cartoys.MopsMiddlelayer.MopsProcess01;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;

import corp.cartoys.MopsMiddlelayer.AppLauncher;

import java.util.*;

import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

/**
 * Log the records in files that couldn't be inserted into database due to some error.
 * @author jjude
 */
public class InvalidDataLogger implements Processor{
	
	String newLineChar = System.getProperty("line.separator"); //To get the newline character of corresponding platform
	static Logger log  = Logger.getLogger(InvalidDataLogger.class.getName());
	
	public void process(Exchange exchange) throws Exception {
		String fileContent = exchange.getIn().getBody(String.class);
		String timeStamp = new java.text.SimpleDateFormat("yyyy-MM-dd h:mm:ss").format(new Date());
		String logMessage  = newLineChar
				+"The following record could not be inserted into the Db :"
				+ newLineChar
				+ fileContent
				+ newLineChar;
		log.info(logMessage);
		
		//Send an email with the data that could not be inserted into the Db due to exception.
		try
		{
			final String username = AppLauncher.FROM_EMAIL;
	        final String password = AppLauncher.FROM_EMAIL_PASSWORD;
	
	        Properties props = new Properties();
	        props.put("mail.smtp.auth", "true");
	        props.put("mail.smtp.starttls.enable", "true");
	        props.put("mail.smtp.host", AppLauncher.MAIL_SMTP_HOST);
	        props.put("mail.smtp.port", AppLauncher.MAIL_SMTP_PORT);
	
	        Session session = Session.getInstance(props,
	          new javax.mail.Authenticator() {
	            protected PasswordAuthentication getPasswordAuthentication() {
	                return new PasswordAuthentication(username, password);
	            }
	          });
	
	        Message message = new MimeMessage(session);
	        message.setFrom(new InternetAddress(AppLauncher.FROM_EMAIL));
	        message.setRecipients(Message.RecipientType.TO,
	            InternetAddress.parse(AppLauncher.TO_EMAIL));
	        message.setSubject("MOPS MIDDLWARE JAVA APPLICATION WAS UNABLE TO PROCESS THIS ORDER DATA!");
	        message.setText("Hi,\n" 
	        				+ logMessage 
	        				+ newLineChar + "This occured due to an SQL exception or ArrayOutOfBound exception. Please check that all the column sizes of table \'mnsn_order_for_weblink\' are sufficient to insert this order data and there are no additional data in this record row."
	        				+ newLineChar + "Exception timestamp: " + timeStamp);
	
	        Transport.send(message);
		}
		catch(Exception e)
		{
			System.out.println("Unable to send email.");
		}
	}
}
