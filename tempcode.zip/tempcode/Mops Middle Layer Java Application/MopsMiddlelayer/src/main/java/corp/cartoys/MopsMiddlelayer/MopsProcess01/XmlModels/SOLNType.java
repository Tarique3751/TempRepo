package corp.cartoys.MopsMiddlelayer.MopsProcess01.XmlModels;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SOLNType", propOrder = { "DelDocLnNum", "ItmCd", "StoreCd", "LocCd", "SerNum", "UnitPrc", "Qty",
		"SolnCmnt", "ActivationDt", "ActivationPhone", "ShipGroup" })
public class SOLNType {
	@XmlElement(name = "DEL_DOC_LN_NUM", required = true)
	private int DelDocLnNum;
	@XmlElement(name = "ITM_CD", required = true)
	private String ItmCd;
	@XmlElement(name = "STORE_CD", required = true)
	private String StoreCd;
	@XmlElement(name = "LOC_CD", required = true)
	private String LocCd;
	@XmlElement(name = "SER_NUM", required = true)
	private String SerNum;
	@XmlElement(name = "UNIT_PRC", required = true)
	private String UnitPrc;
	@XmlElement(name = "QTY", required = true)
	private int Qty;
	@XmlElement(name = "SO_LN_CMNT", required = true)
	private String SolnCmnt;
	@XmlElement(name = "ACTIVATION_DT", required = true)
	private String ActivationDt;
	@XmlElement(name = "ACTIVATION_PHONE", required = true)
	private String ActivationPhone;
	@XmlElement(name = "SHIP_GROUP", required = true)
	private String ShipGroup;
	
	public int getDelDocLnNum() {
		return DelDocLnNum;
	}
	public void setDelDocLnNum(int delDocLnNum) {
		DelDocLnNum = delDocLnNum;
	}
	public String getItmCd() {
		return ItmCd;
	}
	public void setItmCd(String itmCd) {
		ItmCd = itmCd;
	}
	public String getStoreCd() {
		return StoreCd;
	}
	public void setStoreCd(String storeCd) {
		StoreCd = storeCd;
	}
	public String getLocCd() {
		return LocCd;
	}
	public void setLocCd(String locCd) {
		LocCd = locCd;
	}
	public String getSerNum() {
		return SerNum;
	}
	public void setSerNum(String serNum) {
		SerNum = serNum;
	}
	public String getUnitPrc() {
		return UnitPrc;
	}
	public void setUnitPrc(String unitPrc) {
		UnitPrc = unitPrc;
	}
	public int getQty() {
		return Qty;
	}
	public void setQty(int qty) {
		Qty = qty;
	}
	public String getSolnCmnt() {
		return SolnCmnt;
	}
	public void setSolnCmnt(String solnCmnt) {
		SolnCmnt = solnCmnt;
	}
	public String getActivationDt() {
		return ActivationDt;
	}
	public void setActivationDt(String activationDt) {
		ActivationDt = activationDt;
	}
	public String getActivationPhone() {
		return ActivationPhone;
	}
	public void setActivationPhone(String activationPhone) {
		ActivationPhone = activationPhone;
	}
	public String getShipGroup() {
		return ShipGroup;
	}
	public void setShipGroup(String shipGroup) {
		ShipGroup = shipGroup;
	}
}
