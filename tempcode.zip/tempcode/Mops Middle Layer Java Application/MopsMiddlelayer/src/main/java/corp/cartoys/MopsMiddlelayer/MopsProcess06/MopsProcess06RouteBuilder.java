package corp.cartoys.MopsMiddlelayer.MopsProcess06;

import org.apache.log4j.Logger;

/**
 * Camel route that calls the webservice and inserts the inventory data into mysql db.
 * @author jjude
 */
public class MopsProcess06RouteBuilder extends org.apache.camel.builder.RouteBuilder{
	String newLineChar = System.getProperty("line.separator"); //To get the newline character of corresponding platform
	static Logger log  = Logger.getLogger(MopsProcess06RouteBuilder.class.getName());
	
	public void configure() throws Exception
	{
		try
		{
			//Camel Route 1 : Call the webservice based on a timer specified in the AppConfig and insert them into database.
			from("timer://foo?period=" + Process06Launcher.webServicePollingTime).
			bean(new MnsnInventoryInsertion(),"insertAllInventoryToMysql").
			to("mock:result");
		}
		catch(Exception e)
		{
			String logMessage = newLineChar
					+ "Something went wrong.Please ensure that the input and output folder paths are configured correctly in AppConfig.properties file." + newLineChar
					+ "Exception : " + e + newLineChar
					+ newLineChar;
			log.info(logMessage);
		} 
	}
}