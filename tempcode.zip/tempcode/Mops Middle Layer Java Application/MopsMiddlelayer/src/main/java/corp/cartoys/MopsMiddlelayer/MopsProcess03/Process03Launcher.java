package corp.cartoys.MopsMiddlelayer.MopsProcess03;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import corp.cartoys.MopsMiddlelayer.AppConfigValidator;

/**
 * MopsProcess03 - Process the incoming tracking file.
 * @author jjude
 */
public class Process03Launcher {
	public static Properties prop = new Properties();
	public static String inputFolderPath;
	public static String acceptedFileListRegExp;
	public static String dataSplitDelimiter;
	static String configFilePath = "./MopsProcess03Config/AppConfig.properties";
	
	/**
	 * Read the AppConfig properties file and fetch the application configurations.
	 * @param Nothing.
	 * @return Nothing.
	 */
	public static void readAppConfigurations()
	{
		try
		{
			prop.load(new FileInputStream(configFilePath));
		}
		catch(IOException e)
		{
			System.out.println("Exception :" + e);
		}
		//Setting the app config variables
		inputFolderPath = prop.getProperty("InputFolderPath"); //Input directory path
		acceptedFileListRegExp = prop.getProperty("AcceptedFileListRegExp"); //List of file types that shpuld be parsed
		dataSplitDelimiter = prop.getProperty("DataSplitDelimiter");//Delimiter to split out the values from file
		
		//Validate the configurations
		AppConfigValidator.checkFolderExists(inputFolderPath,configFilePath);
	}
}
