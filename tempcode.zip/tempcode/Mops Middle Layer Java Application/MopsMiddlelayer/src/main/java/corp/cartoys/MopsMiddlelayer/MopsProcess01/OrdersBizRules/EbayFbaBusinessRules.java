package corp.cartoys.MopsMiddlelayer.MopsProcess01.OrdersBizRules;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Date;
import java.util.List;

import org.drools.compiler.compiler.DroolsParserException;
import org.drools.compiler.compiler.PackageBuilder;
import org.drools.core.RuleBase;
import org.drools.core.RuleBaseFactory;
import org.drools.core.WorkingMemory;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import corp.cartoys.MopsMiddlelayer.HibernateManager;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.Process01Launcher;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.dto.DirectoryCountryRegion;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.dto.GersXml;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.dto.GersXmlCust;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.dto.GersXmlSolns;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.dto.MnsnOrderDetails;
import corp.cartoys.MopsMiddlelayer.MopsProcess01.dto.MnsnOrderHeader;

/**
 * Business rules for Ebay FBA order data.
 * @author jjude
 */
public class EbayFbaBusinessRules implements BusinessRules{

	// Header details fields
	public MnsnOrderHeader moh;
		
	public Double MAX_TOTAL_AMOUNT_NEED_ATTENTION  = Double.parseDouble(Process01Launcher.MAX_TOTAL_AMOUNT_NEED_ATTENTION);
	public String AMAZON_FBA_EMAIL_VAL             = Process01Launcher.AMAZON_FBA_EMAIL_VAL;
	public String AMAZON_FBA_FNAME_VAL             = Process01Launcher.AMAZON_FBA_FNAME_VAL;
	public String AMAZON_FBA_LNAME_VAL             = Process01Launcher.AMAZON_FBA_LNAME_VAL;
	public String AMAZON_FBA_ADDR1_VAL             = Process01Launcher.AMAZON_FBA_ADDR1_VAL;
	public String AMAZON_FBA_ADDR2_VAL             = Process01Launcher.AMAZON_FBA_ADDR2_VAL;
	public String EBAY_FBA_ADDR2_VAL               = Process01Launcher.EBAY_FBA_ADDR2_VAL;
	public String AMAZON_FBA_LOCATION_CODE_VAL     = Process01Launcher.AMAZON_FBA_LOCATION_CODE_VAL;
	public String EBAY_FBA_LOCATION_CODE_VAL       = Process01Launcher.EBAY_FBA_LOCATION_CODE_VAL;
	public String CONFIDENTIAL_CITY_VAL            = Process01Launcher.CONFIDENTIAL_CITY_VAL;
	public String CONFIDENTIAL_STATE_VAL           = Process01Launcher.CONFIDENTIAL_STATE_VAL;
	public String CONFIDENTIAL_POSTAL_CODE         = Process01Launcher.CONFIDENTIAL_POSTAL_CODE;
	public int MAX_ADDR_LEN_NEED_ATTENTION         = Integer.parseInt(Process01Launcher.MAX_ADDR_LEN_NEED_ATTENTION);
	public String EBAY_FBA_EMAIL_VAL               = Process01Launcher.EBAY_FBA_EMAIL_VAL;
	public String EBAY_FBA_FNAME_VAL               = Process01Launcher.EBAY_FBA_FNAME_VAL;
	public String EBAY_FBA_LNAME_VAL               = Process01Launcher.EBAY_FBA_LNAME_VAL;
	public String EBAY_FBA_ADDR1_VAL               = Process01Launcher.EBAY_FBA_ADDR1_VAL;
	public int STATUS_ID_FOR_XML_GENERATION        = Integer.parseInt(Process01Launcher.STATUS_ID_FOR_XML_GENERATION);
	public int STATUS_ID_FOR_XML_GENERATED_RECORDS = Integer.parseInt(Process01Launcher.STATUS_ID_FOR_XML_GENERATED_RECORDS);
	public String EBAY_MARKET_NAME                 = Process01Launcher.EBAY_MARKET_NAME;
	public String FIN_CUST_CD_FOR_EBAY             = Process01Launcher.FIN_CUST_CD_FOR_EBAY;
	public String FBA_ORDER_SRT_CD                 = Process01Launcher.FBA_ORDER_SRT_CD;
	public String FBA_PU_DEL                       = Process01Launcher.FBA_PU_DEL;
	public String PHONENUMBER_LENGTH               = Process01Launcher.PHONENUMBER_LENGTH;
	public String PHN_NUM_WITH_CODE_LENGTH         = Process01Launcher.PHN_NUM_WITH_CODE_LENGTH;
	public String ERR_MSG_FOR_PHONENUM             = Process01Launcher.ERR_MSG_FOR_PHONENUM;
	public String ERR_MSG_FOR_CITY                 = Process01Launcher.ERR_MSG_FOR_CITY;
	public String ERR_MSG_FOR_STATE                = Process01Launcher.ERR_MSG_FOR_STATE;
	
	public Double totalAmount; 
	public int lengthOfAddress;
	public int multipleSkuWrn;
	public Double taxChg;
	public String fulfillmentType;
	public String sku;
	public String price;
	public int orderedQuantity;
	public String timeStamp = new java.text.SimpleDateFormat("yyyy-MM-dd h:mm:ss").format(new Date());
	
	//XML fields
	public GersXml gx;
	public GersXmlSolns gxs;
	public GersXmlCust gxc;
	
	//XML Business rule fields
	public static String FIN_CUST_CD     = "";
	public static String ORD_SRT_CD      = "";
	public static String PU_DEL          = "";
	public static String LOC_CD          = "";
	public static String STORE_CD        = "";
	public static String SHIP_TO_ZONE_CD = "";
	
	public EbayFbaBusinessRules()
	{
		
	}
	
	/**
	 * Constructor that assignes the Ebay FBA order data into member variables.
	 * @param monsoonOrderHdId - Int.
	 * @param monsoonOrderId - Int.
	 * @param orderStatus - String.
	 * @param marketName - String.
	 * @param marketOrderId - String.
	 * @param shipMethod - String.
	 * @param orderDate - String.
	 * @param shipDate - String.
	 * @param orderNote - String.
	 * @param trackingNumber - String.
	 * @param carrierCode - String.
	 * @param buyerEmail - String.
	 * @param buyerName - String.
	 * @param firstName - String.
	 * @param lastName - String.
	 * @param shipToName - String.
	 * @param address1 - String.
	 * @param address2 - String.
	 * @param city - String.
	 * @param state - String.
	 * @param postalCode - String.
	 * @param country - String.
	 * @param buyerPhoneNumber - String.
	 * @param createdDate - String.
	 * @param returns - String.
	 * @param locationCode - String.
	 * @param automaticImportErrorDetails - String.
	 * @param company - String.
	 * @param alreadyExists - Int.
	 * @param totalAmount - Double.
	 * @param lengthOfAddress - Int.
	 * @param fulfillmentType - String.
	 * @param sku - String.
	 * @param price - String.
	 * @param orderedQuantity - Int.
	 * @param multipleSkuWrn - Int.
	 * @param taxChg - Double.
	 * @return Nothing.
	 */
	public EbayFbaBusinessRules(int monsoonOrderHdId, int monsoonOrderId, String orderStatus, String marketName, String marketOrderId, String shipMethod, String orderDate, String shipDate,
			String orderNote, String trackingNumber, String carrierCode, String buyerEmail, String buyerName, String firstName, String lastName, String shipToName, String address1, String address2,
			String city, String state, String postalCode, String country, String buyerPhoneNumber, String createdDate, String returns, String locationCode, String automaticImportErrorDetails, 
			String company, int alreadyExists, Double totalAmount, int lengthOfAddress, String fulfillmentType, String sku, String price, int orderedQuantity, int multipleSkuWrn, Double taxChg)
	{
		this.moh = new MnsnOrderHeader();
		this.moh.setMonsoonOrderHdId(monsoonOrderHdId);
		this.moh.setMonsoonOrderId(monsoonOrderId);
		this.moh.setOrderStatus(orderStatus);
		this.moh.setMarketName(marketName);
		this.moh.setMarketOrderId(marketOrderId);
		this.moh.setShipMethod(shipMethod);
		this.moh.setOrderDate(orderDate);
		this.moh.setShipDate(shipDate);
		this.moh.setOrderNote(orderNote);
		this.moh.setTrackingNumber(trackingNumber);
		this.moh.setCarrierCode(carrierCode);
		this.moh.setBuyerEmail(buyerEmail);
		this.moh.setBuyerName(buyerName);
		this.moh.setFirstName(firstName);
		this.moh.setLastName(lastName);
		this.moh.setShipToName(shipToName);
		this.moh.setAddress1(address1);
		this.moh.setAddress2(address2);
		this.moh.setCity(city);
		this.moh.setState(state);
		this.moh.setPostalCode(postalCode);
		this.moh.setCountry(country);
		this.moh.setBuyerPhoneNumber(buyerPhoneNumber);
		this.moh.setCreatedDate(createdDate);
		this.moh.setReturns(returns);
		this.moh.setLocationCode(locationCode);
		this.moh.setAutomaticImportErrorDetails(automaticImportErrorDetails);
		this.moh.setCompany(company);
		this.moh.setAlreadyExist(alreadyExists);
		this.totalAmount = totalAmount;
		this.lengthOfAddress = lengthOfAddress;
		this.fulfillmentType = fulfillmentType;
		this.sku = sku;
		this.price = price;
		this.orderedQuantity = orderedQuantity;
		this.multipleSkuWrn = multipleSkuWrn;
		this.taxChg = taxChg;
	}
	
	//Business Rule Member Functions
	public void checkTotalAmount() {
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		Query query = session.getNamedQuery("MnsnOrderHeader.GetOrderHeaderDetails").setLong("MonsoonOrderId", moh.getMonsoonOrderId());
		List<MnsnOrderHeader> resultsList = query.list();
		for (MnsnOrderHeader res : resultsList) 
		{
			if(res.getAutomaticImportErrorDetails() == null)
			{
				Query automaticImportErrorDetailsQry = session.getNamedQuery("MnsnOrderHeader.UpdateAutomaticImportErrorDetails").setString("AutomaticImportErrorDetails", "Total Amount is greater than " + MAX_TOTAL_AMOUNT_NEED_ATTENTION + ".").setLong("MonsoonOrderId", moh.getMonsoonOrderId());
				automaticImportErrorDetailsQry.executeUpdate();
			}
			else if(!(res.getAutomaticImportErrorDetails().contains("Total Amount is greater than " + MAX_TOTAL_AMOUNT_NEED_ATTENTION + ".")))
			{
				Query automaticImportErrorDetailsQry = session.getNamedQuery("MnsnOrderHeader.UpdateAutomaticImportErrorDetails").setString("AutomaticImportErrorDetails", "Total Amount is greater than " + MAX_TOTAL_AMOUNT_NEED_ATTENTION + ".").setLong("MonsoonOrderId", moh.getMonsoonOrderId());
				automaticImportErrorDetailsQry.executeUpdate();
			}
		}
		session.close();
	}
	public void setBuyerDetails() {
		Session session = HibernateManager.getSessionFactory().openSession();
		Query buyerDetailsQry = session.getNamedQuery("MnsnOrderHeader.UpdateBuyerDetails").setString("BuyerEmail", EBAY_FBA_EMAIL_VAL).setString("FirstName", EBAY_FBA_FNAME_VAL).setString("LastName", EBAY_FBA_LNAME_VAL).setString("Address1", EBAY_FBA_ADDR1_VAL).setLong("MonsoonOrderId", moh.getMonsoonOrderId());
		buyerDetailsQry.executeUpdate();
		session.close();
	}
	public void setCity() {
		Session session = HibernateManager.getSessionFactory().openSession();
		Query cityDetailsQry = session.getNamedQuery("MnsnOrderHeader.UpdateCityDetails").setString("City", CONFIDENTIAL_CITY_VAL).setLong("MonsoonOrderId", moh.getMonsoonOrderId());
		cityDetailsQry.executeUpdate();
		session.close();
	}
	public void setState() {
		Session session = HibernateManager.getSessionFactory().openSession();
		Query stateDetailsQry = session.getNamedQuery("MnsnOrderHeader.UpdateStateDetails").setString("State", CONFIDENTIAL_STATE_VAL).setLong("MonsoonOrderId", moh.getMonsoonOrderId());
		stateDetailsQry.executeUpdate();
		session.close();
	}
	public void setPostalCode() {
		Session session = HibernateManager.getSessionFactory().openSession();
		Query postalCodeQry = session.getNamedQuery("MnsnOrderHeader.UpdatePostalCode").setString("PostalCode", CONFIDENTIAL_POSTAL_CODE).setLong("MonsoonOrderId", moh.getMonsoonOrderId());
		postalCodeQry.executeUpdate();
		session.close();
	}
	public void checkAddressLength() {
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		Query query = session.getNamedQuery("MnsnOrderHeader.GetOrderHeaderDetails").setLong("MonsoonOrderId", moh.getMonsoonOrderId());
		List<MnsnOrderHeader> resultsList = query.list();
		for (MnsnOrderHeader res : resultsList) 
		{
			if(res.getAutomaticImportErrorDetails() == null)
			{
				Query automaticImportErrorDetailsQry = session.getNamedQuery("MnsnOrderHeader.UpdateAutomaticImportErrorDetails").setString("AutomaticImportErrorDetails", "Total Address Length is greater than " + MAX_ADDR_LEN_NEED_ATTENTION + ".").setLong("MonsoonOrderId", moh.getMonsoonOrderId());
				automaticImportErrorDetailsQry.executeUpdate();
			}
			else if(!(res.getAutomaticImportErrorDetails().contains("Total Address Length is greater than " + MAX_ADDR_LEN_NEED_ATTENTION + ".")))
			{
				Query automaticImportErrorDetailsQry = session.getNamedQuery("MnsnOrderHeader.UpdateAutomaticImportErrorDetails").setString("AutomaticImportErrorDetails", "Total Address Length is greater than " + MAX_ADDR_LEN_NEED_ATTENTION + ".").setLong("MonsoonOrderId", moh.getMonsoonOrderId());
				automaticImportErrorDetailsQry.executeUpdate();
			}
		}
		session.close();
	}
	public void setAddress() {
		Session session = HibernateManager.getSessionFactory().openSession();
		Query addressQry = session.getNamedQuery("MnsnOrderHeader.UpdateAddress").setString("Address2", EBAY_FBA_ADDR2_VAL).setString("LocationCode", EBAY_FBA_LOCATION_CODE_VAL).setLong("MonsoonOrderId", moh.getMonsoonOrderId());
		addressQry.executeUpdate();
		session.close();
	}
	public void splitShipToName(String shipToName) {
		String[] shipToNameArray = shipToName.split("\\s+");
		String firstName = shipToNameArray[0];
		String lastName = shipToNameArray[shipToNameArray.length-1];
		Session session = HibernateManager.getSessionFactory().openSession();
		Query fnameLnameQry = session.getNamedQuery("MnsnOrderHeader.UpdateFnameLname").setString("FirstName", firstName).setString("LastName", lastName).setLong("MonsoonOrderId", moh.getMonsoonOrderId());
		fnameLnameQry.executeUpdate();
		session.close();
	}
	public void setLastName(String shipToName) {
		String firstName = "";
		String lastName = shipToName;
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		Query fnameLnameQry = session.getNamedQuery("MnsnOrderHeader.UpdateFnameLname").setString("FirstName", firstName).setString("LastName", lastName).setLong("MonsoonOrderId", moh.getMonsoonOrderId());
		fnameLnameQry.executeUpdate();
		
		Query query = session.getNamedQuery("MnsnOrderHeader.GetOrderHeaderDetails").setLong("MonsoonOrderId", moh.getMonsoonOrderId());
		List<MnsnOrderHeader> resultsList = query.list();
		for (MnsnOrderHeader res : resultsList) 
		{
			if(res.getAutomaticImportErrorDetails() == null)
			{
				Query automaticImportErrorDetailsQry = session.getNamedQuery("MnsnOrderHeader.UpdateAutomaticImportErrorDetails").setString("AutomaticImportErrorDetails", "Last Name was empty.").setLong("MonsoonOrderId", moh.getMonsoonOrderId());
				automaticImportErrorDetailsQry.executeUpdate();
			}
			else if(!(res.getAutomaticImportErrorDetails().contains("Last Name was empty.")))
			{
				Query automaticImportErrorDetailsQry = session.getNamedQuery("MnsnOrderHeader.UpdateAutomaticImportErrorDetails").setString("AutomaticImportErrorDetails", "Last Name was empty.").setLong("MonsoonOrderId", moh.getMonsoonOrderId());
				automaticImportErrorDetailsQry.executeUpdate();
			}
		}
		session.close();
	}
	public void setBuyerPhoneNumber(String buyerPhoneNumber)
	{
		Session session = HibernateManager.getSessionFactory().openSession();
		Query buyerPhnQry = session.getNamedQuery("MnsnOrderHeader.UpdateBuyerPhone").setString("BuyerPhoneNumber", buyerPhoneNumber).setLong("MonsoonOrderId", moh.getMonsoonOrderId());
		buyerPhnQry.executeUpdate();
		session.close();
	}
	public void setMultipleSkuWarning()
	{
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		Query query = session.getNamedQuery("MnsnOrderHeader.GetOrderHeaderDetails").setLong("MonsoonOrderId", moh.getMonsoonOrderId());
		List<MnsnOrderHeader> resultsList = query.list();
		for (MnsnOrderHeader res : resultsList) 
		{
			if(res.getAutomaticImportErrorDetails() == null)
			{
				Query automaticImportErrorDetailsQry = session.getNamedQuery("MnsnOrderHeader.UpdateAutomaticImportErrorDetails").setString("AutomaticImportErrorDetails", "Multiple Orders with same sku.").setLong("MonsoonOrderId", moh.getMonsoonOrderId());
				automaticImportErrorDetailsQry.executeUpdate();
			}
			else if(!(res.getAutomaticImportErrorDetails().contains("Multiple Orders with same sku.")))
			{
				Query automaticImportErrorDetailsQry = session.getNamedQuery("MnsnOrderHeader.UpdateAutomaticImportErrorDetails").setString("AutomaticImportErrorDetails", "Multiple Orders with same sku.").setLong("MonsoonOrderId", moh.getMonsoonOrderId());
				automaticImportErrorDetailsQry.executeUpdate();
			}
		}
		session.close();
	}
	//Function that fetches State code for a state 
	public String getStateCode(String state)
	{
		String stateCode = "";
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		Query stateCodeQry = session.getNamedQuery("DirectoryCountryRegion.GetStateCode").setString("DefaultName", state);
		List<DirectoryCountryRegion> resultsList = stateCodeQry.list();
		if(!resultsList.isEmpty())
		{
			stateCode = resultsList.get(0).getCode();
		}
		else
		{
			stateCode = state;
		}
		session.close();
		return stateCode;
	}
	
	//Function that updates the AutomaticImportErrorDetails with the given error message
	public void updateErrMsg(String errMsg, int monsoonOrderId)
	{
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		Query query = session.getNamedQuery("MnsnOrderHeader.GetOrderHeaderDetails").setLong("MonsoonOrderId", monsoonOrderId);
		List<MnsnOrderHeader> resultsList = query.list();
		for (MnsnOrderHeader res : resultsList) 
		{
			if(res.getAutomaticImportErrorDetails() == null)
			{
				Query automaticImportErrorDetailsQry = session.getNamedQuery("MnsnOrderHeader.UpdateAutomaticImportErrorDetails").setString("AutomaticImportErrorDetails", errMsg).setLong("MonsoonOrderId", monsoonOrderId);
				automaticImportErrorDetailsQry.executeUpdate();
			}
			else if(!(res.getAutomaticImportErrorDetails().contains(errMsg)))
			{
				Query automaticImportErrorDetailsQry = session.getNamedQuery("MnsnOrderHeader.UpdateAutomaticImportErrorDetails").setString("AutomaticImportErrorDetails", errMsg).setLong("MonsoonOrderId", monsoonOrderId);
				automaticImportErrorDetailsQry.executeUpdate();
			}
		}
		session.close();
	}
	//Function that removes the given error message from AutomaticImportErrorDetails field
	public void removeErrMsg(String errMsg, int monsoonOrderId)
	{
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		Query query = session.getNamedQuery("MnsnOrderHeader.GetOrderHeaderDetails").setLong("MonsoonOrderId", monsoonOrderId);
		List<MnsnOrderHeader> resultsList = query.list();
		String errorMessage = "";
		for (MnsnOrderHeader res : resultsList) 
		{
			errorMessage = res.getAutomaticImportErrorDetails();
			if(errorMessage != null)
			{
				if(errorMessage.contains(errMsg))
				{
					errorMessage = errorMessage.replaceAll(errMsg, "");
				}
			}
			Query automaticImportErrorDetailsQry = session.getNamedQuery("MnsnOrderHeader.SetAutomaticImportErrorDetails").setString("AutomaticImportErrorDetails", errorMessage).setLong("MonsoonOrderId", monsoonOrderId);
			automaticImportErrorDetailsQry.executeUpdate();
		}
		session.close();
	}
	
	//Function that saves the Gers XML values to DB
	public void persistGersXml(int monsoonOrderId, String sku)
	{
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		MnsnOrderHeader mnsnOrderHeader = new MnsnOrderHeader();
		mnsnOrderHeader = null;
		Criteria criteria = session.createCriteria(MnsnOrderHeader.class);
		criteria.add(Restrictions.eq("MonsoonOrderId", monsoonOrderId));
		criteria.add(Restrictions.eq("ImportStatus", STATUS_ID_FOR_XML_GENERATION));
		criteria.add(Restrictions.eq("AutomaticImportStatus", 1));
		mnsnOrderHeader = (MnsnOrderHeader) criteria.uniqueResult();
		session.close();
		if(mnsnOrderHeader != null)
		{
			this.gx = new GersXml();
			this.gx.setTrnId(monsoonOrderId);
			this.gx.setOriginCd(Process01Launcher.ORIGIN_CD);
			this.gx.setCauseCd(Process01Launcher.CAUSE_CD);
			this.gx.setEmpCdOp(Process01Launcher.EMP_CD_OP);
			this.gx.setEmpCdKeyer(Process01Launcher.EMP_CD_KEYER);
			this.gx.setFinCustCd(FIN_CUST_CD);
			this.gx.setShipToStCd(getStateCode(mnsnOrderHeader.getState()));
			this.gx.setShipToZoneCd(SHIP_TO_ZONE_CD);
			this.gx.setTaxCd(Process01Launcher.TAX_CD);
			this.gx.setOrdTpCd(Process01Launcher.ORDER_TP_CD);
			this.gx.setOrdSrtCd(ORD_SRT_CD);
			this.gx.setSoStoreCd(Process01Launcher.SO_STORE_CD);
			this.gx.setPuDelStoreCd(Process01Launcher.PU_DEL_STORE_CD);
			this.gx.setSoEmpSlspCd1(Process01Launcher.SO_EMP_SLSP_CD1);
			this.gx.setSoWrDt(mnsnOrderHeader.getOrderDate());
			this.gx.setShipToTitle(Process01Launcher.SHIP_TO_TITLE);
			this.gx.setShipToFname(mnsnOrderHeader.getFirstName());
			this.gx.setShipToLname(mnsnOrderHeader.getLastName());
			this.gx.setShipToAddr1(mnsnOrderHeader.getAddress1());
			this.gx.setShipToAddr2(mnsnOrderHeader.getAddress2());
			this.gx.setShipToZipCd(mnsnOrderHeader.getPostalCode());
			this.gx.setShipToHphone(mnsnOrderHeader.getBuyerPhoneNumber());
			this.gx.setShipToBphone(String.valueOf(monsoonOrderId));
			this.gx.setShipToExt(Process01Launcher.SHIP_TO_EXT);
			this.gx.setShipToCity(mnsnOrderHeader.getCity());
			this.gx.setShipToCorp(Process01Launcher.SHIP_TO_CORP);
			this.gx.setPctOfSale1(Process01Launcher.PCT_OF_SALE1);
			this.gx.setPuDel(PU_DEL);
			this.gx.setPuDelDt(mnsnOrderHeader.getOrderDate());
			this.gx.setDelChg(Process01Launcher.DEL_CHG);
			this.gx.setSetupChg(Process01Launcher.SETUP_CHG);
			this.gx.setTaxChg(String.valueOf(taxChg));
			this.gx.setOrigDelDocNum(Process01Launcher.ORIG_DEL_DOC_NUM);
			this.gx.setOrigFiAmt(String.valueOf(totalAmount));
			this.gx.setApprovalCd(String.valueOf(monsoonOrderId));
			this.gx.setRequestedFiAmount(String.valueOf(totalAmount));
			this.gx.setAltDocNum(String.valueOf(monsoonOrderId));
			this.gx.setAltCustCd(Process01Launcher.ALT_CUST_CD);
			
			int gersXmlId;
			session = HibernateManager.getSessionFactory().openSession();
			GersXml gersXmlObj = new GersXml();
			gersXmlObj = null;
			criteria = session.createCriteria(GersXml.class);
			criteria.add(Restrictions.eq("TrnId", monsoonOrderId));
			gersXmlObj = (GersXml) criteria.uniqueResult();
			if(gersXmlObj == null)
			{
				session.beginTransaction();
				session.save(this.gx);
				session.flush();
				gersXmlId = this.gx.getGersXmlId();
				try
				{
					session.getTransaction().commit();
				}
				catch(Exception e)
				{
					session.getTransaction().rollback();
				}
			}
			else
			{
				gersXmlId = gersXmlObj.getGersXmlId();
			}
			session.close();
			
			session = HibernateManager.getSessionFactory().openSession();
			MnsnOrderDetails mnsnOrderDetails = new MnsnOrderDetails();
			mnsnOrderDetails = null;
			criteria = session.createCriteria(MnsnOrderDetails.class);
			criteria.add(Restrictions.eq("MonsoonOrderId", monsoonOrderId));
			criteria.add(Restrictions.eq("SKU", sku));
			mnsnOrderDetails = (MnsnOrderDetails) criteria.uniqueResult();
			if(mnsnOrderDetails != null)
			{
				Double unitPric     = 0.00;
				String marketPrice  =  mnsnOrderDetails.getMarketPrice();
				int shippedQuantity = mnsnOrderDetails.getShippedQuantity();
				if(marketPrice.equals(""))
				{
					marketPrice = "0.00";
				}
				if(shippedQuantity != 0)
				{
					unitPric = Double.parseDouble(marketPrice)/shippedQuantity;
				}
				
				this.gxs = new GersXmlSolns();
				this.gxs.setGersXmlId(gersXmlId);
				this.gxs.setMonsoonOrderId(monsoonOrderId);
				this.gxs.setItemCd(mnsnOrderDetails.getSKU());
				this.gxs.setStoreCd("");
				this.gxs.setLocCd("");
				this.gxs.setSerNum(Process01Launcher.SER_NUM);
				this.gxs.setUnitPrc(String.valueOf(unitPric));
				this.gxs.setQty(mnsnOrderDetails.getShippedQuantity());
				this.gxs.setSoLnCmnt(Process01Launcher.SO_LN_CMNT);
				this.gxs.setActivationDt(Process01Launcher.ACTIVATION_DT);
				this.gxs.setActivationPhone(Process01Launcher.ACTIVATION_PHONE);
				this.gxs.setShipGroup(Process01Launcher.SHIP_GROUP);
				
				GersXmlSolns gersXmlSolns = new GersXmlSolns();
				gersXmlSolns = null;
				criteria = session.createCriteria(GersXmlSolns.class);
				criteria.add(Restrictions.eq("MonsoonOrderId", monsoonOrderId));
				criteria.add(Restrictions.eq("ItemCd", mnsnOrderDetails.getSKU()));
				gersXmlSolns = (GersXmlSolns) criteria.uniqueResult();
				if(gersXmlSolns == null)
				{
					session.beginTransaction();
					session.save(this.gxs);
					session.flush();
					try
					{
						session.getTransaction().commit();
					}
					catch(Exception e)
					{
						session.getTransaction().rollback();
					}
				}
			}
			session.close();
			
			this.gxc = new GersXmlCust();
			this.gxc.setGersXmlId(gersXmlId);
			this.gxc.setCustCd(monsoonOrderId);
			this.gxc.setSrtCd(Process01Launcher.SRT_CD);
			this.gxc.setTitle(Process01Launcher.TITLE);
			this.gxc.setFname(mnsnOrderHeader.getFirstName());
			this.gxc.setInit(Process01Launcher.INIT);
			this.gxc.setLname(mnsnOrderHeader.getLastName());
			this.gxc.setAddr1(mnsnOrderHeader.getAddress1());
			this.gxc.setAddr2(mnsnOrderHeader.getAddress2());
			this.gxc.setCity(mnsnOrderHeader.getCity());
			this.gxc.setStCd(mnsnOrderHeader.getState());
			this.gxc.setZipCd(mnsnOrderHeader.getPostalCode());
			this.gxc.setHomePhone(mnsnOrderHeader.getBuyerPhoneNumber());
			this.gxc.setBusPhone(Process01Launcher.BUS_PHONE);
			this.gxc.setExt(Process01Launcher.EXT);
			this.gxc.setCorpName(Process01Launcher.CORP_NAME);
			this.gxc.setCustTpCd(Process01Launcher.CUST_TP_CD);
			this.gxc.setAltCustCd(Process01Launcher.ALT_CUST_CD);
			this.gxc.setEmailAddr(mnsnOrderHeader.getBuyerEmail());
			this.gxc.setEmailAddrShipTo(mnsnOrderHeader.getBuyerEmail());
			
			session = HibernateManager.getSessionFactory().openSession();
			GersXmlCust gersXmlCust = new GersXmlCust();
			gersXmlCust = null;
			criteria = session.createCriteria(GersXmlCust.class);
			criteria.add(Restrictions.eq("GersXmlId", gersXmlId));
			gersXmlCust = (GersXmlCust) criteria.uniqueResult();
			if(gersXmlCust == null)
			{
				session.beginTransaction();
				session.save(this.gxc);
				session.flush();
				try
				{
					session.getTransaction().commit();
				}
				catch(Exception e)
				{
					session.getTransaction().rollback();
				}
			}
			session.close();
		}
	}
	
	/**
	 * Function that execute the Drools business rules.
	 * @param ruleList - String[].
	 * @param ebayFbaBusinessRulesObj - EbayFbaBusinessRules Object
	 * @return Nothing.
	 */
	public void executeRules(String[] ruleList,EbayFbaBusinessRules ebayFbaBusinessRulesObj) throws DroolsParserException, IOException{
		PackageBuilder packageBuilderEbayFba = new PackageBuilder();
		String[] ruleFiles = ruleList;
		//Convert rule file to InputStream
		for (String ruleFile : ruleFiles) 
		{
			InputStream resourceAsStream = new FileInputStream(ruleFile);
			Reader reader = new InputStreamReader(resourceAsStream);
			packageBuilderEbayFba.addPackageFromDrl(reader);
		}
		
		org.drools.core.rule.Package rulesPackageEbayFba = packageBuilderEbayFba.getPackage();		
		RuleBase ruleBaseEbayFba = RuleBaseFactory.newRuleBase();
		ruleBaseEbayFba.addPackage(rulesPackageEbayFba);
		
		//Create new WorkingMemory session for this RuleBase. By default the RuleBase retains a weak reference to returned WorkingMemory
		WorkingMemory workingMemoryEbayFba = ruleBaseEbayFba.newStatefulSession();
		
		//Updating the field ImportStatus for db records for which business rules were applied.
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		Query importStatusUpdateQry = session.getNamedQuery("MnsnOrderHeader.UpdateImportStatusQry").setLong("ImportStatus", STATUS_ID_FOR_XML_GENERATION).setLong("MonsoonOrderId", ebayFbaBusinessRulesObj.getMoh().getMonsoonOrderId());
		importStatusUpdateQry.executeUpdate();
		session.close();
				
		//Insert and fire all rules until its empty
		workingMemoryEbayFba.insert(ebayFbaBusinessRulesObj);
		workingMemoryEbayFba.fireAllRules();
		workingMemoryEbayFba.dispose();
		
		session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		Query query = session.getNamedQuery("MnsnOrderHeader.GetOrderHeaderDetails").setLong("MonsoonOrderId", ebayFbaBusinessRulesObj.getMoh().getMonsoonOrderId());
		List<MnsnOrderHeader> resultsList = query.list();
		//If AutomaticImportErrorDetails is not null it means there is an invalid data so set the ImportStatus and AutomaticImportStatus as 0
		if(resultsList.get(0).getAutomaticImportErrorDetails() != null && !resultsList.get(0).getAutomaticImportErrorDetails().equalsIgnoreCase("") && ((!resultsList.get(0).getAutomaticImportErrorDetails().contains(Process01Launcher.WRN_MSG_FOR_TOTAL_AMT) && !resultsList.get(0).getAutomaticImportErrorDetails().contains(Process01Launcher.WRN_MSG_FOR_ADDR_LEN) && !resultsList.get(0).getAutomaticImportErrorDetails().contains(Process01Launcher.WRN_MSG_FOR_LNAME_EMPTY) && !resultsList.get(0).getAutomaticImportErrorDetails().contains(Process01Launcher.WRN_MSG_FOR_MULTIPLE_SKU)) || (resultsList.get(0).getAutomaticImportErrorDetails().contains(ERR_MSG_FOR_PHONENUM) || resultsList.get(0).getAutomaticImportErrorDetails().contains(ERR_MSG_FOR_CITY) || resultsList.get(0).getAutomaticImportErrorDetails().contains(ERR_MSG_FOR_STATE))))
		{
			Query statusFlagsQry = session.getNamedQuery("MnsnOrderHeader.UpdateImportStatusAndAutomaticImportStatusQry").setLong("ImportStatus", 0).setLong("AutomaticImportStatus", 0).setLong("MonsoonOrderId", ebayFbaBusinessRulesObj.getMoh().getMonsoonOrderId());
			statusFlagsQry.executeUpdate();
		}
		else
		{
			Query statusFlagsQry = session.getNamedQuery("MnsnOrderHeader.UpdateImportStatusAndAutomaticImportStatusQry").setLong("ImportStatus", Integer.parseInt(Process01Launcher.STATUS_ID_FOR_XML_GENERATION)).setLong("AutomaticImportStatus", 1).setLong("MonsoonOrderId", ebayFbaBusinessRulesObj.getMoh().getMonsoonOrderId());
			statusFlagsQry.executeUpdate();
		}
		session.close();
		
		//Insert xml data into the database.
		ebayFbaBusinessRulesObj.persistGersXml(ebayFbaBusinessRulesObj.getMoh().getMonsoonOrderId(),ebayFbaBusinessRulesObj.getSku());
	}
	
	
	//Getters and Setters for the class member variables
	public MnsnOrderHeader getMoh() {
		if (moh == null) {
			moh = new MnsnOrderHeader();
		}
		return this.moh;
	}

	public void setMoh(MnsnOrderHeader moh) {
		this.moh = moh;
	}

	public Double getMAX_TOTAL_AMOUNT_NEED_ATTENTION() {
		return MAX_TOTAL_AMOUNT_NEED_ATTENTION;
	}

	public void setMAX_TOTAL_AMOUNT_NEED_ATTENTION(
			Double mAX_TOTAL_AMOUNT_NEED_ATTENTION) {
		MAX_TOTAL_AMOUNT_NEED_ATTENTION = mAX_TOTAL_AMOUNT_NEED_ATTENTION;
	}

	public String getAMAZON_FBA_EMAIL_VAL() {
		return AMAZON_FBA_EMAIL_VAL;
	}

	public void setAMAZON_FBA_EMAIL_VAL(String aMAZON_FBA_EMAIL_VAL) {
		AMAZON_FBA_EMAIL_VAL = aMAZON_FBA_EMAIL_VAL;
	}

	public String getAMAZON_FBA_FNAME_VAL() {
		return AMAZON_FBA_FNAME_VAL;
	}

	public void setAMAZON_FBA_FNAME_VAL(String aMAZON_FBA_FNAME_VAL) {
		AMAZON_FBA_FNAME_VAL = aMAZON_FBA_FNAME_VAL;
	}

	public String getAMAZON_FBA_LNAME_VAL() {
		return AMAZON_FBA_LNAME_VAL;
	}

	public void setAMAZON_FBA_LNAME_VAL(String aMAZON_FBA_LNAME_VAL) {
		AMAZON_FBA_LNAME_VAL = aMAZON_FBA_LNAME_VAL;
	}

	public String getAMAZON_FBA_ADDR1_VAL() {
		return AMAZON_FBA_ADDR1_VAL;
	}

	public void setAMAZON_FBA_ADDR1_VAL(String aMAZON_FBA_ADDR1_VAL) {
		AMAZON_FBA_ADDR1_VAL = aMAZON_FBA_ADDR1_VAL;
	}

	public String getAMAZON_FBA_ADDR2_VAL() {
		return AMAZON_FBA_ADDR2_VAL;
	}

	public void setAMAZON_FBA_ADDR2_VAL(String aMAZON_FBA_ADDR2_VAL) {
		AMAZON_FBA_ADDR2_VAL = aMAZON_FBA_ADDR2_VAL;
	}

	public String getEBAY_FBA_ADDR2_VAL() {
		return EBAY_FBA_ADDR2_VAL;
	}

	public void setEBAY_FBA_ADDR2_VAL(String eBAY_FBA_ADDR2_VAL) {
		EBAY_FBA_ADDR2_VAL = eBAY_FBA_ADDR2_VAL;
	}

	public String getAMAZON_FBA_LOCATION_CODE_VAL() {
		return AMAZON_FBA_LOCATION_CODE_VAL;
	}

	public void setAMAZON_FBA_LOCATION_CODE_VAL(String aMAZON_FBA_LOCATION_CODE_VAL) {
		AMAZON_FBA_LOCATION_CODE_VAL = aMAZON_FBA_LOCATION_CODE_VAL;
	}

	public String getEBAY_FBA_LOCATION_CODE_VAL() {
		return EBAY_FBA_LOCATION_CODE_VAL;
	}

	public void setEBAY_FBA_LOCATION_CODE_VAL(String eBAY_FBA_LOCATION_CODE_VAL) {
		EBAY_FBA_LOCATION_CODE_VAL = eBAY_FBA_LOCATION_CODE_VAL;
	}

	public String getCONFIDENTIAL_CITY_VAL() {
		return CONFIDENTIAL_CITY_VAL;
	}

	public void setCONFIDENTIAL_CITY_VAL(String cONFIDENTIAL_CITY_VAL) {
		CONFIDENTIAL_CITY_VAL = cONFIDENTIAL_CITY_VAL;
	}

	public String getCONFIDENTIAL_STATE_VAL() {
		return CONFIDENTIAL_STATE_VAL;
	}

	public void setCONFIDENTIAL_STATE_VAL(String cONFIDENTIAL_STATE_VAL) {
		CONFIDENTIAL_STATE_VAL = cONFIDENTIAL_STATE_VAL;
	}

	public String getCONFIDENTIAL_POSTAL_CODE() {
		return CONFIDENTIAL_POSTAL_CODE;
	}

	public void setCONFIDENTIAL_POSTAL_CODE(String cONFIDENTIAL_POSTAL_CODE) {
		CONFIDENTIAL_POSTAL_CODE = cONFIDENTIAL_POSTAL_CODE;
	}

	public int getMAX_ADDR_LEN_NEED_ATTENTION() {
		return MAX_ADDR_LEN_NEED_ATTENTION;
	}

	public void setMAX_ADDR_LEN_NEED_ATTENTION(int mAX_ADDR_LEN_NEED_ATTENTION) {
		MAX_ADDR_LEN_NEED_ATTENTION = mAX_ADDR_LEN_NEED_ATTENTION;
	}

	public String getEBAY_FBA_EMAIL_VAL() {
		return EBAY_FBA_EMAIL_VAL;
	}

	public void setEBAY_FBA_EMAIL_VAL(String eBAY_FBA_EMAIL_VAL) {
		EBAY_FBA_EMAIL_VAL = eBAY_FBA_EMAIL_VAL;
	}

	public String getEBAY_FBA_FNAME_VAL() {
		return EBAY_FBA_FNAME_VAL;
	}

	public void setEBAY_FBA_FNAME_VAL(String eBAY_FBA_FNAME_VAL) {
		EBAY_FBA_FNAME_VAL = eBAY_FBA_FNAME_VAL;
	}

	public String getEBAY_FBA_LNAME_VAL() {
		return EBAY_FBA_LNAME_VAL;
	}

	public void setEBAY_FBA_LNAME_VAL(String eBAY_FBA_LNAME_VAL) {
		EBAY_FBA_LNAME_VAL = eBAY_FBA_LNAME_VAL;
	}

	public String getEBAY_FBA_ADDR1_VAL() {
		return EBAY_FBA_ADDR1_VAL;
	}

	public void setEBAY_FBA_ADDR1_VAL(String eBAY_FBA_ADDR1_VAL) {
		EBAY_FBA_ADDR1_VAL = eBAY_FBA_ADDR1_VAL;
	}

	public int getSTATUS_ID_FOR_XML_GENERATION() {
		return STATUS_ID_FOR_XML_GENERATION;
	}

	public void setSTATUS_ID_FOR_XML_GENERATION(int sTATUS_ID_FOR_XML_GENERATION) {
		STATUS_ID_FOR_XML_GENERATION = sTATUS_ID_FOR_XML_GENERATION;
	}

	public int getSTATUS_ID_FOR_XML_GENERATED_RECORDS() {
		return STATUS_ID_FOR_XML_GENERATED_RECORDS;
	}

	public void setSTATUS_ID_FOR_XML_GENERATED_RECORDS(
			int sTATUS_ID_FOR_XML_GENERATED_RECORDS) {
		STATUS_ID_FOR_XML_GENERATED_RECORDS = sTATUS_ID_FOR_XML_GENERATED_RECORDS;
	}

	public String getEBAY_MARKET_NAME() {
		return EBAY_MARKET_NAME;
	}

	public void setEBAY_MARKET_NAME(String eBAY_MARKET_NAME) {
		EBAY_MARKET_NAME = eBAY_MARKET_NAME;
	}

	public String getFIN_CUST_CD_FOR_EBAY() {
		return FIN_CUST_CD_FOR_EBAY;
	}

	public void setFIN_CUST_CD_FOR_EBAY(String fIN_CUST_CD_FOR_EBAY) {
		FIN_CUST_CD_FOR_EBAY = fIN_CUST_CD_FOR_EBAY;
	}

	public String getFBA_ORDER_SRT_CD() {
		return FBA_ORDER_SRT_CD;
	}

	public void setFBA_ORDER_SRT_CD(String fBA_ORDER_SRT_CD) {
		FBA_ORDER_SRT_CD = fBA_ORDER_SRT_CD;
	}

	public String getFBA_PU_DEL() {
		return FBA_PU_DEL;
	}

	public void setFBA_PU_DEL(String fBA_PU_DEL) {
		FBA_PU_DEL = fBA_PU_DEL;
	}

	public String getPHONENUMBER_LENGTH() {
		return PHONENUMBER_LENGTH;
	}

	public void setPHONENUMBER_LENGTH(String pHONENUMBER_LENGTH) {
		PHONENUMBER_LENGTH = pHONENUMBER_LENGTH;
	}

	public String getPHN_NUM_WITH_CODE_LENGTH() {
		return PHN_NUM_WITH_CODE_LENGTH;
	}

	public void setPHN_NUM_WITH_CODE_LENGTH(String pHN_NUM_WITH_CODE_LENGTH) {
		PHN_NUM_WITH_CODE_LENGTH = pHN_NUM_WITH_CODE_LENGTH;
	}

	public String getERR_MSG_FOR_PHONENUM() {
		return ERR_MSG_FOR_PHONENUM;
	}

	public void setERR_MSG_FOR_PHONENUM(String eRR_MSG_FOR_PHONENUM) {
		ERR_MSG_FOR_PHONENUM = eRR_MSG_FOR_PHONENUM;
	}

	public String getERR_MSG_FOR_CITY() {
		return ERR_MSG_FOR_CITY;
	}

	public void setERR_MSG_FOR_CITY(String eRR_MSG_FOR_CITY) {
		ERR_MSG_FOR_CITY = eRR_MSG_FOR_CITY;
	}

	public String getERR_MSG_FOR_STATE() {
		return ERR_MSG_FOR_STATE;
	}

	public void setERR_MSG_FOR_STATE(String eRR_MSG_FOR_STATE) {
		ERR_MSG_FOR_STATE = eRR_MSG_FOR_STATE;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public int getLengthOfAddress() {
		return lengthOfAddress;
	}

	public void setLengthOfAddress(int lengthOfAddress) {
		this.lengthOfAddress = lengthOfAddress;
	}

	public int getMultipleSkuWrn() {
		return multipleSkuWrn;
	}

	public void setMultipleSkuWrn(int multipleSkuWrn) {
		this.multipleSkuWrn = multipleSkuWrn;
	}

	public Double getTaxChg() {
		return taxChg;
	}

	public void setTaxChg(Double taxChg) {
		this.taxChg = taxChg;
	}

	public String getFulfillmentType() {
		return fulfillmentType;
	}

	public void setFulfillmentType(String fulfillmentType) {
		this.fulfillmentType = fulfillmentType;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public int getOrderedQuantity() {
		return orderedQuantity;
	}

	public void setOrderedQuantity(int orderedQuantity) {
		this.orderedQuantity = orderedQuantity;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public GersXml getGx() {
		return gx;
	}

	public void setGx(GersXml gx) {
		this.gx = gx;
	}

	public GersXmlSolns getGxs() {
		return gxs;
	}

	public void setGxs(GersXmlSolns gxs) {
		this.gxs = gxs;
	}

	public GersXmlCust getGxc() {
		return gxc;
	}

	public void setGxc(GersXmlCust gxc) {
		this.gxc = gxc;
	}

	public static String getFIN_CUST_CD() {
		return FIN_CUST_CD;
	}

	public static void setFIN_CUST_CD(String fIN_CUST_CD) {
		FIN_CUST_CD = fIN_CUST_CD;
	}

	public static String getORD_SRT_CD() {
		return ORD_SRT_CD;
	}

	public static void setORD_SRT_CD(String oRD_SRT_CD) {
		ORD_SRT_CD = oRD_SRT_CD;
	}

	public static String getPU_DEL() {
		return PU_DEL;
	}

	public static void setPU_DEL(String pU_DEL) {
		PU_DEL = pU_DEL;
	}

	public static String getLOC_CD() {
		return LOC_CD;
	}

	public static void setLOC_CD(String lOC_CD) {
		LOC_CD = lOC_CD;
	}

	public static String getSTORE_CD() {
		return STORE_CD;
	}

	public static void setSTORE_CD(String sTORE_CD) {
		STORE_CD = sTORE_CD;
	}

	public static String getSHIP_TO_ZONE_CD() {
		return SHIP_TO_ZONE_CD;
	}

	public static void setSHIP_TO_ZONE_CD(String sHIP_TO_ZONE_CD) {
		SHIP_TO_ZONE_CD = sHIP_TO_ZONE_CD;
	}
}
