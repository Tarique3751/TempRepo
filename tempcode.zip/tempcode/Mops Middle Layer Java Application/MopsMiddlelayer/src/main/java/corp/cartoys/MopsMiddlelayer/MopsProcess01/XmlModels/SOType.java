package corp.cartoys.MopsMiddlelayer.MopsProcess01.XmlModels;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
@XmlType(name = "SOType", propOrder = { "TranId", "OriginCd", "CauseCd", "EmpCdOp", "EmpCdKeyer", "FinCustCd",
		"ShipToStCd", "ShipToZoneCd", "TaxCd", "OrdTpCd", "OrdSrtCd", "SoStoreCd", "PuDelStoreCd", "SoEmpSlspCd1",
		"SoWrDt", "ShipToTitle", "ShipToFname", "ShipToLname", "ShipToAddr1", "ShipToAddr2", "ShipToZipCd",
		"ShipToHphone", "ShipToBphone", "ShipToExt", "ShipToCity", "ShipToCorp", "PctOfSale1", "PuDel", "PuDelDt",
		"DelChg", "SetupChg", "TaxChg", "OrigDelDocNum", "OrigFiAmount", "ApprovalCd", "RequestedFiAmt", "AltDocNum",
		"AltCustCd", "SoLns", "Cust" })
public class SOType {
	@XmlElement(name = "TRN_ID", required = true)
	private int TranId;
	@XmlElement(name = "ORIGIN_CD", required = true)
	private String OriginCd;
	@XmlElement(name = "CAUSE_CD", required = true)
	private String CauseCd;
	@XmlElement(name = "EMP_CD_OP", required = true)
	private String EmpCdOp;
	@XmlElement(name = "EMP_CD_KEYER", required = true)
	private String EmpCdKeyer;
	@XmlElement(name = "FIN_CUST_CD", required = true)
	private String FinCustCd;
	@XmlElement(name = "SHIP_TO_ST_CD", required = true)
	private String ShipToStCd;
	@XmlElement(name = "SHIP_TO_ZONE_CD", required = true)
	private String ShipToZoneCd;
	@XmlElement(name = "TAX_CD", required = true)
	private String TaxCd;
	@XmlElement(name = "ORD_TP_CD", required = true)
	private String OrdTpCd;
	@XmlElement(name = "ORD_SRT_CD", required = true)
	private String OrdSrtCd;
	@XmlElement(name = "SO_STORE_CD", required = true)
	private String SoStoreCd;
	@XmlElement(name = "PU_DEL_STORE_CD", required = true)
	private String PuDelStoreCd;
	@XmlElement(name = "SO_EMP_SLSP_CD1", required = true)
	private String SoEmpSlspCd1;
	@XmlElement(name = "SO_WR_DT", required = true)
	private String SoWrDt;
	@XmlElement(name = "SHIP_TO_TITLE", required = true)
	private String ShipToTitle;
	@XmlElement(name = "SHIP_TO_F_NAME", required = true)
	private String ShipToFname;
	@XmlElement(name = "SHIP_TO_L_NAME", required = true)
	private String ShipToLname;
	@XmlElement(name = "SHIP_TO_ADDR1", required = true)
	private String ShipToAddr1;
	@XmlElement(name = "SHIP_TO_ADDR2", required = true)
	private String ShipToAddr2;
	@XmlElement(name = "SHIP_TO_ZIP_CD", required = true)
	private String ShipToZipCd;
	@XmlElement(name = "SHIP_TO_H_PHONE", required = true)
	private String ShipToHphone;
	@XmlElement(name = "SHIP_TO_B_PHONE", required = true)
	private String ShipToBphone;
	@XmlElement(name = "SHIP_TO_EXT", required = true)
	private String ShipToExt;
	@XmlElement(name = "SHIP_TO_CITY", required = true)
	private String ShipToCity;
	@XmlElement(name = "SHIP_TO_CORP", required = true)
	private String ShipToCorp;
	@XmlElement(name = "PCT_OF_SALE1", required = true)
	private String PctOfSale1;
	@XmlElement(name = "PU_DEL", required = true)
	private String PuDel;
	@XmlElement(name = "PU_DEL_DT", required = true)
	private String PuDelDt;
	@XmlElement(name = "DEL_CHG", required = true)
	private String DelChg;
	@XmlElement(name = "SETUP_CHG", required = true)
	private String SetupChg;
	@XmlElement(name = "TAX_CHG", required = true)
	private String TaxChg;
	@XmlElement(name = "ORIG_DEL_DOC_NUM", required = true)
	private String OrigDelDocNum;
	@XmlElement(name = "ORIG_FI_AMT", required = true)
	private String OrigFiAmount;
	@XmlElement(name = "APPROVAL_CD", required = true)
	private String ApprovalCd;
	@XmlElement(name = "REQUESTED_FI_AMT", required = true)
	private String RequestedFiAmt;
	@XmlElement(name = "ALT_DOC_NUM", required = true)
	private String AltDocNum;
	@XmlElement(name = "ALT_CUST_CD", required = true)
	private String AltCustCd;
	@XmlElement(name = "SO_LNS", required = true)
	protected SOLNSType SoLns;
	@XmlElement(name = "CUST", required = true)
	protected CUSTType Cust;
	
	public int getTranId() {
		return TranId;
	}
	public void setTranId(int tranId) {
		TranId = tranId;
	}
	public String getOriginCd() {
		return OriginCd;
	}
	public void setOriginCd(String originCd) {
		OriginCd = originCd;
	}
	public String getCauseCd() {
		return CauseCd;
	}
	public void setCauseCd(String causeCd) {
		CauseCd = causeCd;
	}
	public String getEmpCdOp() {
		return EmpCdOp;
	}
	public void setEmpCdOp(String empCdOp) {
		EmpCdOp = empCdOp;
	}
	public String getEmpCdKeyer() {
		return EmpCdKeyer;
	}
	public void setEmpCdKeyer(String empCdKeyer) {
		EmpCdKeyer = empCdKeyer;
	}
	public String getFinCustCd() {
		return FinCustCd;
	}
	public void setFinCustCd(String finCustCd) {
		FinCustCd = finCustCd;
	}
	public String getShipToStCd() {
		return ShipToStCd;
	}
	public void setShipToStCd(String shipToStCd) {
		ShipToStCd = shipToStCd;
	}
	public String getShipToZoneCd() {
		return ShipToZoneCd;
	}
	public void setShipToZoneCd(String shipToZoneCd) {
		ShipToZoneCd = shipToZoneCd;
	}
	public String getTaxCd() {
		return TaxCd;
	}
	public void setTaxCd(String taxCd) {
		TaxCd = taxCd;
	}
	public String getOrdTpCd() {
		return OrdTpCd;
	}
	public void setOrdTpCd(String ordTpCd) {
		OrdTpCd = ordTpCd;
	}
	public String getOrdSrtCd() {
		return OrdSrtCd;
	}
	public void setOrdSrtCd(String ordSrtCd) {
		OrdSrtCd = ordSrtCd;
	}
	public String getSoStoreCd() {
		return SoStoreCd;
	}
	public void setSoStoreCd(String soStoreCd) {
		SoStoreCd = soStoreCd;
	}
	public String getPuDelStoreCd() {
		return PuDelStoreCd;
	}
	public void setPuDelStoreCd(String puDelStoreCd) {
		PuDelStoreCd = puDelStoreCd;
	}
	public String getSoEmpSlspCd1() {
		return SoEmpSlspCd1;
	}
	public void setSoEmpSlspCd1(String soEmpSlspCd1) {
		SoEmpSlspCd1 = soEmpSlspCd1;
	}
	public String getSoWrDt() {
		return SoWrDt;
	}
	public void setSoWrDt(String soWrDt) {
		SoWrDt = soWrDt;
	}
	public String getShipToTitle() {
		return ShipToTitle;
	}
	public void setShipToTitle(String shipToTitle) {
		ShipToTitle = shipToTitle;
	}
	public String getShipToFname() {
		return ShipToFname;
	}
	public void setShipToFname(String shipToFname) {
		ShipToFname = shipToFname;
	}
	public String getShipToLname() {
		return ShipToLname;
	}
	public void setShipToLname(String shipToLname) {
		ShipToLname = shipToLname;
	}
	public String getShipToAddr1() {
		return ShipToAddr1;
	}
	public void setShipToAddr1(String shipToAddr1) {
		ShipToAddr1 = shipToAddr1;
	}
	public String getShipToAddr2() {
		return ShipToAddr2;
	}
	public void setShipToAddr2(String shipToAddr2) {
		ShipToAddr2 = shipToAddr2;
	}
	public String getShipToZipCd() {
		return ShipToZipCd;
	}
	public void setShipToZipCd(String shipToZipCd) {
		ShipToZipCd = shipToZipCd;
	}
	public String getShipToHphone() {
		return ShipToHphone;
	}
	public void setShipToHphone(String shipToHphone) {
		ShipToHphone = shipToHphone;
	}
	public String getShipToBphone() {
		return ShipToBphone;
	}
	public void setShipToBphone(String shipToBphone) {
		ShipToBphone = shipToBphone;
	}
	public String getShipToExt() {
		return ShipToExt;
	}
	public void setShipToExt(String shipToExt) {
		ShipToExt = shipToExt;
	}
	public String getShipToCity() {
		return ShipToCity;
	}
	public void setShipToCity(String shipToCity) {
		ShipToCity = shipToCity;
	}
	public String getShipToCorp() {
		return ShipToCorp;
	}
	public void setShipToCorp(String shipToCorp) {
		ShipToCorp = shipToCorp;
	}
	public String getPctOfSale1() {
		return PctOfSale1;
	}
	public void setPctOfSale1(String pctOfSale1) {
		PctOfSale1 = pctOfSale1;
	}
	public String getPuDel() {
		return PuDel;
	}
	public void setPuDel(String puDel) {
		PuDel = puDel;
	}
	public String getPuDelDt() {
		return PuDelDt;
	}
	public void setPuDelDt(String puDelDt) {
		PuDelDt = puDelDt;
	}
	public String getDelChg() {
		return DelChg;
	}
	public void setDelChg(String delChg) {
		DelChg = delChg;
	}
	public String getSetupChg() {
		return SetupChg;
	}
	public void setSetupChg(String setupChg) {
		SetupChg = setupChg;
	}
	public String getTaxChg() {
		return TaxChg;
	}
	public void setTaxChg(String taxChg) {
		TaxChg = taxChg;
	}
	public String getOrigDelDocNum() {
		return OrigDelDocNum;
	}
	public void setOrigDelDocNum(String origDelDocNum) {
		OrigDelDocNum = origDelDocNum;
	}
	public String getOrigFiAmount() {
		return OrigFiAmount;
	}
	public void setOrigFiAmount(String origFiAmount) {
		OrigFiAmount = origFiAmount;
	}
	public String getApprovalCd() {
		return ApprovalCd;
	}
	public void setApprovalCd(String approvalCd) {
		ApprovalCd = approvalCd;
	}
	public String getRequestedFiAmt() {
		return RequestedFiAmt;
	}
	public void setRequestedFiAmt(String requestedFiAmt) {
		RequestedFiAmt = requestedFiAmt;
	}
	public String getAltDocNum() {
		return AltDocNum;
	}
	public void setAltDocNum(String altDocNum) {
		AltDocNum = altDocNum;
	}
	public String getAltCustCd() {
		return AltCustCd;
	}
	public void setAltCustCd(String altCustCd) {
		AltCustCd = altCustCd;
	}
	public SOLNSType getSoLns() {
		return SoLns;
	}
	public void setSoLns(SOLNSType soLns) {
		SoLns = soLns;
	}
	public CUSTType getCust() {
		return Cust;
	}
	public void setCust(CUSTType cust) {
		Cust = cust;
	}
	
}
