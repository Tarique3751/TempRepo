package corp.cartoys.MopsMiddlelayer.MopsProcess04;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import corp.cartoys.MopsMiddlelayer.AppConfigValidator;

/**
 * MopsProcess04 - Check the database for specific time intervals, fetches order import details and generates the order import files.
 * @author jjude
 */
public class Process04Launcher {
	public static Properties prop = new Properties();
	public static String outputFolderPath;
	public static String dataSplitDelimiter;
	public static String dBPollingTime;
	public static String fileName;
	static String configFilePath = "./MopsProcess04Config/AppConfig.properties";
	
	/**
	 * Read the AppConfig properties file and fetch the application configurations.
	 * @param Nothing.
	 * @return Nothing.
	 */
	public static void readAppConfigurations()
	{
		try
		{
			prop.load(new FileInputStream(configFilePath));
		}
		catch(IOException e)
		{
			System.out.println("Exception :" + e);
		}
		//Setting the app config variables
		outputFolderPath   = prop.getProperty("OutputFolderPath"); //Output directory path
		dataSplitDelimiter = prop.getProperty("DataSplitDelimiter");//Delimiter to split out the values from file
		dBPollingTime      = prop.getProperty("DBPollingTime");//Database polling interval
		fileName           = prop.getProperty("FileName");//File name of generated file
		
		//Validate the configurations
		AppConfigValidator.checkFolderExists(outputFolderPath,configFilePath);
		AppConfigValidator.isNumeric("DBPollingTime",dBPollingTime,configFilePath);
	}
}
