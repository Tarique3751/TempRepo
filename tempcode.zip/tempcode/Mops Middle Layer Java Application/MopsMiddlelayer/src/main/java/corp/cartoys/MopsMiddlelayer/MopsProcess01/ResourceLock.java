package corp.cartoys.MopsMiddlelayer.MopsProcess01;

/**
 * Locks the Business rules and XML generation beans (ExtractNormalizedData and XmlGenerator) so that only one camel route has access to them at a time.
 * @author jjude
 */
public class ResourceLock {
	
	
	/**
	 * Sets the lockBizRulesAndXmlGen variable to 1 indicating that a camel route is currently using the beans ExtractNormalizedData and XmlGenerator and thereby blocking there access to other camel routes. 
	 * @param Nothing.
	 * @return Nothing.
	 */
	public void setLock() {
		Process01Launcher.lockBizRulesAndXmlGen = 1;
	}
	
	/**
	 * Sets the lockBizRulesAndXmlGen variable to 0, therby releasing the locks on ExtractNormalizedData and XmlGenerator beans.
	 * @param Nothing.
	 * @return Nothing.
	 */
	public void releaseLock() {
		Process01Launcher.lockBizRulesAndXmlGen = 0;
	}
	
	/**
	 * Checks the locks on ExtractNormalizedData and XmlGenerator beans.
	 * @param Nothing.
	 * @return lockBizRulesAndXmlGen - Int.
	 */
	public int checkLock()
	{
		return Process01Launcher.lockBizRulesAndXmlGen;
	}
 
}
