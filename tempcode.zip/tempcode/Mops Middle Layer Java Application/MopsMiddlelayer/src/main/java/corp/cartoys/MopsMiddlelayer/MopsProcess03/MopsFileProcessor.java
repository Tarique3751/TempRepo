package corp.cartoys.MopsMiddlelayer.MopsProcess03;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.hibernate.Query;
import org.hibernate.Session;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.apache.log4j.Logger;

import corp.cartoys.MopsMiddlelayer.HibernateManager;
import corp.cartoys.MopsMiddlelayer.MopsProcess03.dto.MonsoonFileHeader;

/**
 * Log the files that were processed and check whether the processed files are valid tracking files.
 * @author jjude
 */
public class MopsFileProcessor implements Processor {
	
	String newLineChar             = System.getProperty("line.separator"); //To get the newline character of corresponding platform
	public static String fileName;
	static Logger log              = Logger.getLogger(MopsFileProcessor.class.getName());
	
	public void process(Exchange exchange) throws Exception {
		String fileType    = "";
		String fileStatus  = "";
		String filePath    = exchange.getIn().getBody().toString();
		filePath           = filePath.substring(filePath.indexOf("[") + 1, filePath.indexOf("]"));
		String fileContent = exchange.getIn().getBody(String.class);
		Path p             = Paths.get(filePath);
		fileName           = p.getFileName().toString();
		
		
		try
		{
			String[] fileContentArr    = fileContent.split("\n");
			String headerContents      = fileContentArr[0].trim();
			String validTrackingHeader = "gers_invoice" + Process03Launcher.dataSplitDelimiter + "order_number" + Process03Launcher.dataSplitDelimiter + "tracking_number" + Process03Launcher.dataSplitDelimiter + "sku" + Process03Launcher.dataSplitDelimiter + "qty";
			fileType                   = "valid_file";
			if(!headerContents.equalsIgnoreCase(validTrackingHeader))
			{
				fileType = "invalid_file";
			}	
		}
		catch(Exception e)
		{
			fileType = "invalid_file";
		}
				
		//Check if the tracking file was already processed.
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		Query query = session.getNamedQuery("Process03MonsoonFileHeader.CheckFileNameExists").setString("FileName", fileName);
		List<MonsoonFileHeader> resultsList = query.list();
		session.close();
		if(!resultsList.isEmpty())
		{
			fileType = "already_processed";
		}
		
		if(fileType.equalsIgnoreCase("valid_file"))
		{
			fileStatus = "Tracking file was successfully processed.";
		}
		else if(fileType.equalsIgnoreCase("already_processed"))
		{
			fileStatus = "Tracking file was already processed.";
		}
		else
		{
			fileStatus = "Invalid File. File has been moved to error directory.";
		}
		
		//Creating log
		String logMessage = newLineChar
				+ "Processed File - " + fileName + newLineChar
				+ "Processed File Path - " + filePath + newLineChar
				+ "Processed File Content - " + newLineChar + fileContent + newLineChar
				+ "Processed File Status - " + fileStatus + newLineChar
				+ newLineChar;
		log.info(logMessage);
				
		//Pass the file type in header of the message exchange
		Message newMessage = exchange.getIn(); 
		newMessage.setHeader("FileType",fileType);
	}

}
