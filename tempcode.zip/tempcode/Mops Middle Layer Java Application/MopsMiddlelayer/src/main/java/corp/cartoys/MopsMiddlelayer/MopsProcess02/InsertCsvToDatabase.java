package corp.cartoys.MopsMiddlelayer.MopsProcess02;

import java.util.Date;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import corp.cartoys.MopsMiddlelayer.HibernateManager;
import corp.cartoys.MopsMiddlelayer.MopsProcess02.dto.GersWeblinkStatus;
import corp.cartoys.MopsMiddlelayer.MopsProcess02.dto.MonsoonFileHeader;

/**
 * Parses the data from gers pass/fail file and inserts them into database.
 * @author jjude
 */
public class InsertCsvToDatabase {
	
	String timeStamp = new java.text.SimpleDateFormat("yyyy-MM-dd h:mm:ss").format(new Date());
	
	/**
	 * Function that parses the data of gers pass file and inserts the data into database.
	 * @param body - String argument that accepts each row inside a gers pass file.
	 * @return Nothing.
	 */
	public void processPassFile(String body) throws Exception{
		String[] fileContentArr = body.split(Process02Launcher.dataSplitDelimiter);
		int fileId;
		
		//Insertion into mnsn_file_header table
		MonsoonFileHeader mnsnFileHeader = new MonsoonFileHeader();
		mnsnFileHeader.setFileName(MopsFileProcessor.fileName);
		mnsnFileHeader.setCreatedOn(timeStamp);
		Session session = HibernateManager.getSessionFactory().openSession();
		session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		
		MonsoonFileHeader mnsnFileHeaderFetchData = new MonsoonFileHeader();
		mnsnFileHeaderFetchData = null;
		Criteria criteria = session.createCriteria(MonsoonFileHeader.class);
		criteria.add(Restrictions.eq("FileName", MopsFileProcessor.fileName));
		mnsnFileHeaderFetchData = (MonsoonFileHeader) criteria.uniqueResult();
		//Insert into mnsn_file_header only if that file details are not already present.
		if(mnsnFileHeaderFetchData == null)
		{
			session.save(mnsnFileHeader);
			session.flush();
			fileId = mnsnFileHeader.getFileId();
			try
			{
				session.getTransaction().commit();
			}
			catch(Exception e)
			{
				session.getTransaction().rollback();
			}
		}
		else
		{
			fileId = mnsnFileHeaderFetchData.getFileId();
		}
		session.close();
		
		//Insertion into gers_weblink_status
		GersWeblinkStatus gersWeblinkStatusPass = new GersWeblinkStatus();
		gersWeblinkStatusPass.setOrder_number(Integer.parseInt(fileContentArr[0].trim()));
		gersWeblinkStatusPass.setGers_invoice(fileContentArr[1].trim());
		gersWeblinkStatusPass.setSku(fileContentArr[2].trim());
		gersWeblinkStatusPass.setQty(Integer.parseInt(fileContentArr[3].trim()));
		gersWeblinkStatusPass.setOrd_srt_cd(fileContentArr[4].trim());
		gersWeblinkStatusPass.setDel_doc_ln(fileContentArr[5].trim());
		gersWeblinkStatusPass.setCust_cd(fileContentArr[6].trim());
		gersWeblinkStatusPass.setStat(fileContentArr[7].trim());
		gersWeblinkStatusPass.setFile_name(MopsFileProcessor.fileName);
		gersWeblinkStatusPass.setCreation_time(timeStamp);
		gersWeblinkStatusPass.setFile_id(fileId);
		gersWeblinkStatusPass.setUpdateMops(0);
		
		session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		session.save(gersWeblinkStatusPass);
		session.flush();
		try
		{
			session.getTransaction().commit();
		}
		catch(Exception e)
		{
			session.getTransaction().rollback();
		}
		session.close();
		
		//Update the ImportStatus and UpdateMops fields after the gers data is inserted into db.
		CallUpdateMopsSp();
	}
	
	/**
	 * Function that parses the data of gers fail file and inserts the data into database.
	 * @param body - String argument that accepts each row inside a gers fail file.
	 * @return Nothing.
	 */
	public void processFailFile(String body) throws Exception{
		String[] fileContentArr = body.split(Process02Launcher.dataSplitDelimiter);
		int fileId;
		
		//Insertion into mnsn_file_header
		MonsoonFileHeader mnsnFileHeader = new MonsoonFileHeader();
		mnsnFileHeader.setFileName(MopsFileProcessor.fileName);
		mnsnFileHeader.setCreatedOn(timeStamp);
		Session session = HibernateManager.getSessionFactory().openSession();
		session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		
		MonsoonFileHeader mnsnFileHeaderFetchData = new MonsoonFileHeader();
		mnsnFileHeaderFetchData = null;
		Criteria criteria = session.createCriteria(MonsoonFileHeader.class);
		criteria.add(Restrictions.eq("FileName", MopsFileProcessor.fileName));
		mnsnFileHeaderFetchData = (MonsoonFileHeader) criteria.uniqueResult();
		//Insert into mnsn_file_header only if that file details are not already present.
		if(mnsnFileHeaderFetchData == null)
		{
			session.save(mnsnFileHeader);
			session.flush();
			fileId = mnsnFileHeader.getFileId();
			try
			{
				session.getTransaction().commit();
			}
			catch(Exception e)
			{
				session.getTransaction().rollback();
			}
		}
		else
		{
			fileId = mnsnFileHeaderFetchData.getFileId();
		}
		session.close();
		
		GersWeblinkStatus gersWeblinkStatusFail = new GersWeblinkStatus();
		gersWeblinkStatusFail.setOrder_number(Integer.parseInt(fileContentArr[0].trim()));
		gersWeblinkStatusFail.setGers_invoice(fileContentArr[1].trim());
		gersWeblinkStatusFail.setSku(fileContentArr[2].trim());
		gersWeblinkStatusFail.setQty(Integer.parseInt(fileContentArr[3].trim()));
		gersWeblinkStatusFail.setError_cd(fileContentArr[4].trim());
		gersWeblinkStatusFail.setError_msg(fileContentArr[5].trim());
		gersWeblinkStatusFail.setErr_table(fileContentArr[6].trim());
		gersWeblinkStatusFail.setStat(fileContentArr[7].trim());
		gersWeblinkStatusFail.setFile_name(MopsFileProcessor.fileName);
		gersWeblinkStatusFail.setCreation_time(timeStamp);
		gersWeblinkStatusFail.setFile_id(fileId);
		gersWeblinkStatusFail.setUpdateMops(0);
		
		session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();		
		session.save(gersWeblinkStatusFail);
		session.flush();
		try
		{
			session.getTransaction().commit();
		}
		catch(Exception e)
		{
			session.getTransaction().rollback();
		}
		session.close();
		
		//Update the ImportStatus and UpdateMops fields after the gers data is inserted into db.
		CallUpdateMopsSp();
	}
	
	/**
	 * Function that sets ImportStatus and UpdateMops fields for the MonsoonOrderIds for which the gers weblink details are inserted into db.
	 * @param Nothing.
	 * @return Nothing.
	 */
	public void CallUpdateMopsSp()
	{
		Session session = HibernateManager.getSessionFactory().openSession();
		session.beginTransaction();
		Query updateMopsSpQry = session.getNamedQuery("GersWeblinkStatus.UpdateMopsSP");
		updateMopsSpQry.executeUpdate();
		Query updateMopsFbaSpQry = session.getNamedQuery("GersWeblinkStatus.UpdateMopsFbaSP");
		updateMopsFbaSpQry.executeUpdate();
		session.close();
	}
}
