package corp.cartoys.MopsMiddlelayer.MopsProcess02Tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ FileTypeTestCase.class })
public class Process02TestSuite {

}
