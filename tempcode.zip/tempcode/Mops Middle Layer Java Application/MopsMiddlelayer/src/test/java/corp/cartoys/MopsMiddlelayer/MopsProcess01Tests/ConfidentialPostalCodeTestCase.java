package corp.cartoys.MopsMiddlelayer.MopsProcess01Tests;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Junit Test case that checks Confidential Postal Code Business Logic.
 * @author jjude
 */
public class ConfidentialPostalCodeTestCase {

	public String confidentialPostalCode = "97217";
	
	/**
	 * Function that implements the logic that sets the confidential postal code.
	 * @param postalcode - String.
	 * @return postalcode - String.
	 */
	public String setPostalCode(String postalcode)
	{
		if(postalcode.equalsIgnoreCase("CONFIDENTIAL"))
		{
			postalcode = confidentialPostalCode;
		}
		return postalcode;
	}
	
	@Test
	public void confidentialPostalCodeTest() {
		String postalCode = "CONFIDENTIAL";
		String result     = "";
		
		ConfidentialPostalCodeTestCase confidentialPostalCodeTestCaseObj = new ConfidentialPostalCodeTestCase();
		result = confidentialPostalCodeTestCaseObj.setPostalCode(postalCode);
		
		assertTrue( result.equalsIgnoreCase(confidentialPostalCode) );
	}
	
	@Test
	public void nonConfidentialPostalCodeTest() {
		String postalCode = "123456";
		String result     = "";
		
		ConfidentialPostalCodeTestCase confidentialPostalCodeTestCaseObj = new ConfidentialPostalCodeTestCase();
		result = confidentialPostalCodeTestCaseObj.setPostalCode(postalCode);
		
		assertTrue( result.equalsIgnoreCase(postalCode) );
	}

}
