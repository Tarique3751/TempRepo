package corp.cartoys.MopsMiddlelayer.MopsProcess01Tests;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Junit Test case that checks the ship to name split business rule.
 * @author jjude
 */
public class ShipToNameSplitTestCase {

	/**
	 * Function that implements the logic that splits the ship to name.
	 * @param shipToName - String.
	 * @return nameSplitedArr - String[].
	 */
	public String[] splitShipToName(String shipToName)
	{
		String fname            = "";
		String lname            = "";
		String[] nameSplitedArr = {fname,lname};
		
		if(shipToName.split("\\s+").length > 1)
		{
			String[] shipToNameArray = shipToName.split("\\s+");
			fname                    = shipToNameArray[0];
			lname                    = shipToNameArray[shipToNameArray.length-1];
		}
		else if(shipToName.split("\\s+").length == 1 )
		{
			lname = shipToName;
		}
		
		nameSplitedArr[0] = fname;
		nameSplitedArr[1] = lname;
		
		return nameSplitedArr;
	}
	
	@Test
	public void shipToNameTest() {
		String shipToName = "Test Name";
		String[] splitArr = null;
		int result        = 0;
		
		ShipToNameSplitTestCase shipToNameSplitTestCaseObj = new ShipToNameSplitTestCase();
		splitArr = shipToNameSplitTestCaseObj.splitShipToName(shipToName);
		
		if(splitArr[0].equalsIgnoreCase("Test") && splitArr[1].equalsIgnoreCase("Name"))
		{
			result = 1;
		}
		assertTrue( result == 1 );
	}
	
	@Test
	public void lnameEmptyBuyerNameTest() {
		String shipToName = "Test";
		String[] splitArr = null;
		int result        = 0;
		
		ShipToNameSplitTestCase shipToNameSplitTestCaseObj = new ShipToNameSplitTestCase();
		splitArr = shipToNameSplitTestCaseObj.splitShipToName(shipToName);
		
		if(splitArr[0].equalsIgnoreCase("") && splitArr[1].equalsIgnoreCase("Test"))
		{
			result = 1;
		}
		
		assertTrue( result == 1 );
	}
}
