package corp.cartoys.MopsMiddlelayer.MopsProcess03Tests;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Junit Test case that checks whether only valid tracking files are processed.
 * @author jjude
 */
public class FileTypeTestCase
{
	//Set these variables before running the test.
	String validTrackingFilePath   = "D:/jbdevstudio_workspace/MopsProcess03DataExchange/ValidTrackingFile.csv";
	String inValidTrackingFilePath = "D:/jbdevstudio_workspace/MopsProcess03DataExchange/InValidTrackingFile.csv";
	String fileContentDelimiter    = ",";
	
	/**
	 * Function that implements the logic that checks the file contents.
	 * @param filePath - String argument that accepts file path.
	 * @return fileType - String argyment which specifies whether the file is valid or not.
	 */
	public String checkFile(String filePath)
	{
		String fileContent = "";
		String fileHeader  = "";
		String fileName    = "";
		String fileType    = "";
		Path p             = Paths.get(filePath);
		fileName           = p.getFileName().toString();
		
		BufferedReader bufferedReader  = null;
		try 
		{
			bufferedReader = new BufferedReader(new FileReader(filePath));
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		
		try 
		{
			fileHeader = bufferedReader.readLine().trim(); // read only the first line of file.
			bufferedReader.close();
		} catch (IOException e)
		{
			e.printStackTrace();
		}
		
		try
		{
			String validTrackingHeader = "gers_invoice" + fileContentDelimiter + "order_number" + fileContentDelimiter + "tracking_number" + fileContentDelimiter + "sku" + fileContentDelimiter + "qty";
			fileType = "valid_file";
			if(!fileHeader.equalsIgnoreCase(validTrackingHeader))
			{
				fileType = "invalid_file";
			}	
		}
		catch(Exception e)
		{
			fileType = "invalid_file";
		}
		return fileType;
	}
	
	@Test
	public void validTrackingFileTest()
	{
		String fileType = checkFile(validTrackingFilePath);
		assertTrue( fileType.equalsIgnoreCase("valid_file"));
	}
	
	@Test
	public void inValidTrackingFileTest()
	{
		String fileType = checkFile(inValidTrackingFilePath);
		assertTrue( fileType.equalsIgnoreCase("invalid_file"));
	}
}
