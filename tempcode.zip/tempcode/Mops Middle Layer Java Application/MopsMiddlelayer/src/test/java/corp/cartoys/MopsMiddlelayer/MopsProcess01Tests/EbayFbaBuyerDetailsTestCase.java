package corp.cartoys.MopsMiddlelayer.MopsProcess01Tests;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Junit Test case that checks Email,FirstName,LastName,Address1 details of an Ebay fba order.
 * @author jjude
 */
public class EbayFbaBuyerDetailsTestCase {
	//Buyer details from mops
	public static String mOPSEmail     = "test@gmail.com";
	public static String mOPSFirstName = "Fname";
	public static String mOPSLastName  = "Lname";
	public static String mOPSAddress1  = "test address";
	
	//Buyer details that should be changed if its an Ebay FBA order
	public static String fBAEmail      = "NONE";
	public static String fBAFirstName  = "EBAY ORDER";
	public static String fBALastName   = "AMZ FBA FILLED";
	public static String fBAAddress1   = "DO NOT SHIP ORDER";

	/**
	 * Function that implements the logic that sets the buyer details.
	 * @param marketName - String.
	 * @return fullfillmenttype - String.
	 */
	public String[] setBuyerDetails(String marketName, String fullfillmenttype)
	{
		String[] buyerDetails = {mOPSEmail,mOPSFirstName,mOPSLastName,mOPSAddress1};
		
		if(marketName.equalsIgnoreCase("Ebay") && fullfillmenttype.equalsIgnoreCase("FBA"))
		{
			buyerDetails[0] = fBAEmail;
			buyerDetails[1] = fBAFirstName;
			buyerDetails[2] = fBALastName;
			buyerDetails[3] = fBAAddress1;
		}
		
		return buyerDetails;
	}
	
	@Test
	public void amzFbaOrderBuyerDetailsTest() {
		String marketName       = "Amazon";
		String fullfillmenttype = "FBA";
		String[] buyerDetails   = null;
		int result = 0;
		
		EbayFbaBuyerDetailsTestCase amzFbaBuyerDetailsTestCaseObj = new EbayFbaBuyerDetailsTestCase();
		buyerDetails = amzFbaBuyerDetailsTestCaseObj.setBuyerDetails(marketName,fullfillmenttype);
		
		if(buyerDetails[0].equalsIgnoreCase(fBAEmail) && buyerDetails[1].equalsIgnoreCase(fBAFirstName) && buyerDetails[2].equalsIgnoreCase(fBALastName) && buyerDetails[3].equalsIgnoreCase(fBAAddress1))
		{
			result = 1;
		}
		
		assertTrue( result == 0 );
	}
	
	@Test
	public void amzCtoOrderBuyerDetailsTest() {
		String marketName       = "Amazon";
		String fullfillmenttype = "Local";
		String[] buyerDetails   = null;
		int result = 0;
		
		EbayFbaBuyerDetailsTestCase amzFbaBuyerDetailsTestCaseObj = new EbayFbaBuyerDetailsTestCase();
		buyerDetails = amzFbaBuyerDetailsTestCaseObj.setBuyerDetails(marketName,fullfillmenttype);
		
		if(buyerDetails[0].equalsIgnoreCase(fBAEmail) && buyerDetails[1].equalsIgnoreCase(fBAFirstName) && buyerDetails[2].equalsIgnoreCase(fBALastName) && buyerDetails[3].equalsIgnoreCase(fBAAddress1))
		{
			result = 1;
		}
		
		assertTrue( result == 0 );
	}
	
	@Test
	public void ebayFbaOrderBuyerDetailsTest() {
		String marketName       = "Ebay";
		String fullfillmenttype = "FBA";
		String[] buyerDetails   = null;
		int result = 0;
		
		EbayFbaBuyerDetailsTestCase amzFbaBuyerDetailsTestCaseObj = new EbayFbaBuyerDetailsTestCase();
		buyerDetails = amzFbaBuyerDetailsTestCaseObj.setBuyerDetails(marketName,fullfillmenttype);
		
		if(buyerDetails[0].equalsIgnoreCase(fBAEmail) && buyerDetails[1].equalsIgnoreCase(fBAFirstName) && buyerDetails[2].equalsIgnoreCase(fBALastName) && buyerDetails[3].equalsIgnoreCase(fBAAddress1))
		{
			result = 1;
		}
		
		assertTrue( result == 1 );
	}
	
	@Test
	public void ebayCtoOrderBuyerDetailsTest() {
		String marketName       = "Ebay";
		String fullfillmenttype = "Local";
		String[] buyerDetails   = null;
		int result = 0;
		
		EbayFbaBuyerDetailsTestCase amzFbaBuyerDetailsTestCaseObj = new EbayFbaBuyerDetailsTestCase();
		buyerDetails = amzFbaBuyerDetailsTestCaseObj.setBuyerDetails(marketName,fullfillmenttype);
		
		if(buyerDetails[0].equalsIgnoreCase(fBAEmail) && buyerDetails[1].equalsIgnoreCase(fBAFirstName) && buyerDetails[2].equalsIgnoreCase(fBALastName) && buyerDetails[3].equalsIgnoreCase(fBAAddress1))
		{
			result = 1;
		}
		
		assertTrue( result == 0 );
	}

}
