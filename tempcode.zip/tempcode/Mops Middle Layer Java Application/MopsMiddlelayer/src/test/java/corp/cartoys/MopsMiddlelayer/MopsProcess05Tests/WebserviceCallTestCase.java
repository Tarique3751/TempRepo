package corp.cartoys.MopsMiddlelayer.MopsProcess05Tests;

import static org.junit.Assert.*;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

import org.junit.Test;

/**
 * Junit Test case that checks the response status of the webservice.
 * @author jjude
 */
public class WebserviceCallTestCase
{
	/**
	 * Function that implements the logic that calls the webservice.
	 * @param webServiceUrl - String.
	 * @return status - Int.
	 */
	public int checkWebservice(String webServiceUrl)
	{
		Client client      = ClientBuilder.newClient();
		WebTarget target   = client.target(webServiceUrl);
		int responseStatus = target.request(MediaType.APPLICATION_JSON).get().getStatus();
		
		if(responseStatus == 200)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	@Test
	public void validWebservice()
	{
		String webServiceUrl = "http://10.0.1.101:9001/v1/gers/inventory";
		int status           = checkWebservice(webServiceUrl);
		
		assertTrue( status == 1);
	}
	
	@Test
	public void invalidWebservice()
	{
		String webServiceUrl = "http://10.0.1.101:9001/v1/gers/inventory/invalid";
		int status           = checkWebservice(webServiceUrl);
		
		assertTrue( status == 0);
	}
}
