package corp.cartoys.MopsMiddlelayer.MopsProcess01Tests;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Junit Test case that checks the buyer phone number.
 * @author jjude
 */
public class BuyerPhoneNumberTestCase {

	final int PHONENUMBER_LENGTH = 10;
	final int PHN_NUM_WITH_CODE_LENGTH = 12;

	/**
	 * Function that implements the logic that checks the buyer phone number.
	 * @param PhoneNumber - String.
	 * @return status - Int.
	 */
	public int checkPhoneNumber(String phoneNumber)
	{
		if(phoneNumber.replaceAll("[\\D]", "").length() == PHONENUMBER_LENGTH || phoneNumber.replaceAll("[\\D]", "").length() == PHN_NUM_WITH_CODE_LENGTH)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	@Test
	public void validPhoneNumberTest() {
		String phn = "+91-8590343555";
		int result = 0;
		
		BuyerPhoneNumberTestCase buyerPhoneNumberTestCaseObj = new BuyerPhoneNumberTestCase();
		result = buyerPhoneNumberTestCaseObj.checkPhoneNumber(phn);
		
		assertTrue( result == 1 );
	}
	
	@Test
	public void inValidPhoneNumberTest() {
		String phn = "4q4q4q4q4q4q";
		int result = 0;
		
		BuyerPhoneNumberTestCase buyerPhoneNumberTestCaseObj = new BuyerPhoneNumberTestCase();
		result = buyerPhoneNumberTestCaseObj.checkPhoneNumber(phn);
		
		assertTrue( result == 0 );
	}

}
