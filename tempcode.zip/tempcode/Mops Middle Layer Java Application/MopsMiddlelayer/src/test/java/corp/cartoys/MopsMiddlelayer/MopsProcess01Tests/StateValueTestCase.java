package corp.cartoys.MopsMiddlelayer.MopsProcess01Tests;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Junit Test case that checks the state value.
 * @author jjude
 */
public class StateValueTestCase {

	/**
	 * Function that implements the logic that checks the state.
	 * @param State - String.
	 * @return status - Int..
	 */
	public int checkState(String state)
	{
		if(state.matches("[a-zA-Z ]*$"))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	@Test
	public void validStateTest() {
		String state = "CA";
		int result   = 0;
		
		StateValueTestCase stateValueTestCaseObj = new StateValueTestCase();
		result = stateValueTestCaseObj.checkState(state);
		
		assertTrue( result == 1 );
	}
	
	@Test
	public void inValidStateTest() {
		String state = "44##state";
		int result   = 0;
		
		StateValueTestCase stateValueTestCaseObj = new StateValueTestCase();
		result = stateValueTestCaseObj.checkState(state);
		
		assertTrue( result == 0 );
	}

}
