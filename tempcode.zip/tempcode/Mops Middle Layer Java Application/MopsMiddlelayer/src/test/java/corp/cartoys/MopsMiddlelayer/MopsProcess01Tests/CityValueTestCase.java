package corp.cartoys.MopsMiddlelayer.MopsProcess01Tests;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Junit Test case that checks invalid characters in city.
 * @author jjude
 */
public class CityValueTestCase {

	/**
	 * Function that implements the logic that checks the city value.
	 * @param city - String.
	 * @return status - Int.
	 */
	public int checkCity(String city)
	{
		if(city.matches("[a-zA-Z ]*$"))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	@Test
	public void validCityTest() {
		String city = "Test City";
		int result 	= 0;
		
		CityValueTestCase cityValueTestCaseObj = new CityValueTestCase();
		result = cityValueTestCaseObj.checkCity(city);
		
		assertTrue( result == 1 );
	}
	
	@Test
	public void inValidCityTest() {
		String city = "44##city";
		int result 	= 0;
		
		CityValueTestCase cityValueTestCaseObj = new CityValueTestCase();
		result = cityValueTestCaseObj.checkCity(city);
		
		assertTrue( result == 0 );
	}

}
