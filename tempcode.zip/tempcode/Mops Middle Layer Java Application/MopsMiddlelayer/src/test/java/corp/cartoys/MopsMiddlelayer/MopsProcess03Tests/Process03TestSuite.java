package corp.cartoys.MopsMiddlelayer.MopsProcess03Tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ FileTypeTestCase.class })
public class Process03TestSuite {

}
