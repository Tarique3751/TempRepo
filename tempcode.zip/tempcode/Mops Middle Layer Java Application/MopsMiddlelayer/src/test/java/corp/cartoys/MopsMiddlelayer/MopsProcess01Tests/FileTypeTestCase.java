package corp.cartoys.MopsMiddlelayer.MopsProcess01Tests;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Junit Test case that checks whether only valid order files are processed.
 * @author jjude
 */
public class FileTypeTestCase
{
	//Set these variables before running the test.
	String validOrderFilePath   = "D:/jbdevstudio_workspace/MopsProcess01DataExchange/Orders20160411-062553-468-test.txt";
	String inValidOrderFilePath = "D:/jbdevstudio_workspace/MopsProcess01DataExchange/InvalidOrderFile.txt";
	String fileContentDelimiter = "\t";
	
	/**
	 * Function that implements the logic that checks the file contents.
	 * @param filePath - String argument that accepts file path.
	 * @return fileType - String argyment which specifies whether the file is valid or not.
	 */
	public String checkFile(String filePath)
	{
		String fileContent = "";
		String fileHeader  = "";
		String fileName    = "";
		String fileType    = "";
		Path p             = Paths.get(filePath);
		fileName           = p.getFileName().toString();
		
		BufferedReader bufferedReader  = null;
		try 
		{
			bufferedReader = new BufferedReader(new FileReader(filePath));
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		
		try 
		{
			fileHeader = bufferedReader.readLine().trim(); // read only the first line of file.
			bufferedReader.close();
		} catch (IOException e)
		{
			e.printStackTrace();
		}
		
		try
		{
			String validOrderFileHeader =   "MonsoonOrderId" + fileContentDelimiter 
					+ "OrderStatus" + fileContentDelimiter 
					+ "MarketName" + fileContentDelimiter
					+ "MarketOrderId" + fileContentDelimiter
					+ "ShipMethod" + fileContentDelimiter 
					+ "OrderDate" + fileContentDelimiter 
					+ "ShipDate" + fileContentDelimiter 
					+ "OrderNote"+ fileContentDelimiter 
					+ "TrackingNumber"+ fileContentDelimiter 
					+ "CarrierCode"+ fileContentDelimiter 
					+ "BuyerEmail"+ fileContentDelimiter 
					+ "BuyerName"+ fileContentDelimiter 
					+ "ShipToName"+ fileContentDelimiter 
					+ "Address1"+ fileContentDelimiter 
					+ "Address2"+ fileContentDelimiter 
					+ "City"+ fileContentDelimiter 
					+ "State"+ fileContentDelimiter 
					+ "PostalCode"+ fileContentDelimiter 
					+ "Country"+ fileContentDelimiter 
					+ "BuyerPhoneNumber"+ fileContentDelimiter 
					+ "SKU"+ fileContentDelimiter 
					+ "ASIN"+ fileContentDelimiter
					+ "UPC"+ fileContentDelimiter
					+ "Condition"+ fileContentDelimiter
					+ "SkuOnMarket"+ fileContentDelimiter
					+ "LocatorCode"+ fileContentDelimiter
					+ "OrderedQuantity"+ fileContentDelimiter
					+ "ShippedQuantity"+ fileContentDelimiter
					+ "Price"+ fileContentDelimiter
					+ "ShippingFee"+ fileContentDelimiter
					+ "MarketPrice"+ fileContentDelimiter
					+ "MarketShippingFee"+ fileContentDelimiter
					+ "RefundAmount"+ fileContentDelimiter
					+ "MarketRefundAmount"+ fileContentDelimiter
					+ "Tax"+ fileContentDelimiter
					+ "ShippingTax"+ fileContentDelimiter
					+ "MarketOrderItemId"+ fileContentDelimiter
					+ "FulfillmentType"+ fileContentDelimiter
					+ "ManufacturerPartNum"+ fileContentDelimiter
					+ "ShippingSurcharge"+ fileContentDelimiter
					+ "PromotionalShippingDiscount";
			fileType = "valid_file";
			if(!fileHeader.equalsIgnoreCase(validOrderFileHeader))
			{
				fileType = "invalid_file";
			}	
		}
		catch(Exception e)
		{
			fileType = "invalid_file";
		}
		return fileType;
	}
	
	@Test
	public void validTrackingFileTest()
	{
		String fileType = checkFile(validOrderFilePath);
		assertTrue( fileType.equalsIgnoreCase("valid_file"));
	}
	
	@Test
	public void inValidTrackingFileTest()
	{
		String fileType = checkFile(inValidOrderFilePath);
		assertTrue( fileType.equalsIgnoreCase("invalid_file"));
	}
}
