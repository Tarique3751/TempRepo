package corp.cartoys.MopsMiddlelayer.MopsProcess06Tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ WebserviceCallTestCase.class })
public class Process06TestSuite {

}
