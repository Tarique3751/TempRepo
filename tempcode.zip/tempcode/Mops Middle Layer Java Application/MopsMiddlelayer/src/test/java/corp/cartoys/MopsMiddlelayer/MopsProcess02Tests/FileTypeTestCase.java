package corp.cartoys.MopsMiddlelayer.MopsProcess02Tests;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import static org.junit.Assert.*;
import org.junit.Test;


/**
 * Junit Test case that checks whether only valid tracking files are processed.
 * @author jjude
 */
public class FileTypeTestCase
{
	//Set these variables before running the test.
	String validPassFilePath    = "D:/jbdevstudio_workspace/MopsProcess02DataExchange/ValidGersPassFile.csv";
	String validFailFilePath    = "D:/jbdevstudio_workspace/MopsProcess02DataExchange/ValidGersFailFile.csv";
	String inValidGersFilePath  = "D:/jbdevstudio_workspace/MopsProcess02DataExchange/InValidGersFile.csv";
	String fileContentDelimiter = ",";
	
	/**
	 * Function that implements the logic that checks the file contents.
	 * @param filePath - String argument that accepts file path.
	 * @return fileType - String argyment which specifies whether the file is valid or not.
	 */
	public String checkFile(String filePath)
	{
		String fileContent = "";
		String fileHeader  = "";
		String fileName    = "";
		String fileType    = "";
		Path p             = Paths.get(filePath);
		fileName           = p.getFileName().toString();
		
		BufferedReader bufferedReader  = null;
		try 
		{
			bufferedReader = new BufferedReader(new FileReader(filePath));
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		
		try 
		{
			fileHeader = bufferedReader.readLine().trim(); // read only the first line of file.
			bufferedReader.close();
		} catch (IOException e)
		{
			e.printStackTrace();
		}
		
		try
		{
			if(fileName.toLowerCase().contains("pass"))
			{
				String validPassFileHeader = "order_number" + fileContentDelimiter + "gers_invoice" + fileContentDelimiter + "sku" + fileContentDelimiter + "qty" + fileContentDelimiter + "ord_srt_cd" + fileContentDelimiter + "del_doc_ln" + fileContentDelimiter + "cust_cd" + fileContentDelimiter + "stat";
				fileType = "pass";
				if(!fileHeader.equalsIgnoreCase(validPassFileHeader))
				{
					fileType = "invalid";
				}	
			}
			else if(fileName.toLowerCase().contains("fail"))
			{
				String validFailFileHeader = "order_number" + fileContentDelimiter + "gers_invoice" + fileContentDelimiter + "sku" + fileContentDelimiter + "qty" + fileContentDelimiter + "error_cd" + fileContentDelimiter + "error_msg" + fileContentDelimiter + "err_table" + fileContentDelimiter + "stat";
				fileType = "fail";
				if(!fileHeader.equalsIgnoreCase(validFailFileHeader))
				{
					fileType = "invalid";
				}
			}
			else
			{
				fileType = "invalid";
			}
		}
		catch(Exception e)
		{
			fileType = "invalid";
		}
		
		return fileType;
	}
	
	@Test
	public void validPassFileTest()
	{
		String fileType = checkFile(validPassFilePath);
		assertTrue( fileType.equalsIgnoreCase("pass"));
	}
	
	@Test
	public void validFailFileTest()
	{
		String fileType = checkFile(validFailFilePath);
		assertTrue( fileType.equalsIgnoreCase("fail"));
	}
	
	@Test
	public void invalidFileTest()
	{
		String fileType = checkFile(inValidGersFilePath);
		assertTrue( fileType.equalsIgnoreCase("invalid"));
	}
	
}
