package corp.cartoys.MopsMiddlelayer.MopsProcess01Tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ AddressLengthTestCase.class, AmzFbaBuyerDetailsTestCase.class,
		BuyerPhoneNumberTestCase.class, CityValueTestCase.class,
		ConfidentialCityTestCase.class, ConfidentialPostalCodeTestCase.class,
		ConfidentialStateTestCase.class, EbayFbaBuyerDetailsTestCase.class,
		FbaOrderAddressTestCase.class, FileTypeTestCase.class,
		ShipToNameSplitTestCase.class, StateValueTestCase.class,
		TotalAmountRuleTestCase.class })
public class Process01TestSuite {

}
