package corp.cartoys.MopsMiddlelayer.MopsProcess04Tests;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Junit Test case that checks that empty order import files are not generated.
 * @author jjude
 */
public class FileGenerationTestCase
{
	String dataSplitDelimiter = "\t";
	String newLineChar        = System.getProperty("line.separator"); //To get the newline character of corresponding platform
	String fileHeaderData     = "MonsoonOP" + dataSplitDelimiter + "MonsoonOrderId" + dataSplitDelimiter + "MarketOrderItemId" +dataSplitDelimiter + "OrderStatus" + dataSplitDelimiter + "SKU" + dataSplitDelimiter + "TrackingNumber" + newLineChar;
	/**
	 * Function that implements the logic that checks the file contents.
	 * @param fileContent - String argument that accepts file content.
	 * @return status - Int.
	 */
	public int checkFile(String fileContent)
	{
		String fileData = fileHeaderData;
		fileData        = fileData + fileContent;
		
		if(!fileData.equalsIgnoreCase(fileHeaderData))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	@Test
	public void validFileContent()
	{
		String fileContent = "m" + dataSplitDelimiter + "1013303" + dataSplitDelimiter + "00793441739002" + dataSplitDelimiter + "Shipped" + dataSplitDelimiter + "PS165" + dataSplitDelimiter + "1Z6ER2800347689695";
		int status         = checkFile(fileContent);
		
		assertTrue( status == 1);
	}
	
	@Test
	public void inValidFileContent()
	{
		String fileContent = "";
		int status         = checkFile(fileContent);
		
		assertTrue( status == 0);
	}
}
