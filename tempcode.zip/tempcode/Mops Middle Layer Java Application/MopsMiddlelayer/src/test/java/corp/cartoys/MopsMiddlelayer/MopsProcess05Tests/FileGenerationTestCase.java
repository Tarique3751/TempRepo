package corp.cartoys.MopsMiddlelayer.MopsProcess05Tests;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Junit Test case that checks that empty gers inventory files are not generated.
 * @author jjude
 */
public class FileGenerationTestCase
{
	String dataSplitDelimiter = "\t";
	String newLineChar        = System.getProperty("line.separator"); //To get the newline character of corresponding platform
	String fileHeaderData     = "MonsoonOP" + dataSplitDelimiter + "SKU" + dataSplitDelimiter + "Quantity";
	/**
	 * Function that implements the logic that checks the file contents.
	 * @param fileContent - String argument that accepts file content.
	 * @return status - Int.
	 */
	public int checkFile(String fileContent)
	{
		String fileData = fileHeaderData;
		fileData        = fileData + fileContent;
		if(!fileData.equalsIgnoreCase(fileHeaderData))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	@Test
	public void validFileContent()
	{
		String fileContent = "m" + dataSplitDelimiter + "00100384" + dataSplitDelimiter + "14.0";
		int status         = checkFile(fileContent);
		
		assertTrue( status == 1);
	}
	
	@Test
	public void inValidFileContent()
	{
		String fileContent = "";
		int status         = checkFile(fileContent);
		
		assertTrue( status == 0);
	}
}
