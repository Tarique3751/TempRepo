package corp.cartoys.MopsMiddlelayer.MopsProcess01Tests;

import static org.junit.Assert.assertTrue;
import org.junit.Test;

/**
 * Junit Test case that checks TotalAmount Business Logic.
 * @author jjude
 */
public class TotalAmountRuleTestCase {
	
	final Double MAX_TOTAL_AMOUNT_NEED_ATTENTION = 800.00;
	
	/**
	 * Function that implements the logic that checks the total amount.
	 * @param TotalAmount - Double.
	 * @param MAX_TOTAL_AMOUNT_NEED_ATTENTION - Double.
	 * @return status - Int.
	 */
	public int checkTotalAmount(Double totalAmount, Double MAX_TOTAL_AMOUNT_NEED_ATTENTION)
	{
		if(totalAmount > MAX_TOTAL_AMOUNT_NEED_ATTENTION)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	@Test
	public void totalAmtAboveLimitTest()
	{
		Double totalAmount = 900.00;
		int result         = 0;
		
		TotalAmountRuleTestCase totalAmountRuleTestCaseObj = new TotalAmountRuleTestCase();
		result = totalAmountRuleTestCaseObj.checkTotalAmount(totalAmount,MAX_TOTAL_AMOUNT_NEED_ATTENTION);
		
		assertTrue( result == 1 );
	}
	
	@Test
	public void totalAmtBelowLimitTest()
	{
		Double totalAmount = 700.00;
		int result         = 0;
		
		TotalAmountRuleTestCase totalAmountRuleTestCaseObj = new TotalAmountRuleTestCase();
		result = totalAmountRuleTestCaseObj.checkTotalAmount(totalAmount,MAX_TOTAL_AMOUNT_NEED_ATTENTION);
		
		assertTrue( result == 0 );
	}
}
