package corp.cartoys.MopsMiddlelayer.MopsProcess05Tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ FileGenerationTestCase.class, WebserviceCallTestCase.class })
public class Process05TestSuite {

}
