package corp.cartoys.MopsMiddlelayer.MopsProcess01Tests;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Junit Test case that checks Confidential City Business Logic.
 * @author jjude
 */
public class ConfidentialCityTestCase {

	public String confidentialCity = "PORTLAND";
	
	/**
	 * Function that implements the logic that sets the confidential city.
	 * @param city - String.
	 * @return status - Int.
	 */
	public String setCity(String city)
	{
		if(city.equalsIgnoreCase("CONFIDENTIAL"))
		{
			city = confidentialCity;
		}
		return city;
	}
	
	@Test
	public void confidentialCityTest() {
		String city 	= "CONFIDENTIAL";
		String result 	= "";
		
		ConfidentialCityTestCase confidentialCityTestCaseObj = new ConfidentialCityTestCase();
		result = confidentialCityTestCaseObj.setCity(city);
		
		assertTrue( result.equalsIgnoreCase(confidentialCity) );
	}
	
	@Test
	public void nonConfidentialCityTest() {
		String city 	= "Test City";
		String result 	= "";
		
		ConfidentialCityTestCase confidentialCityTestCaseObj = new ConfidentialCityTestCase();
		result = confidentialCityTestCaseObj.setCity(city);
		
		assertTrue( result.equalsIgnoreCase(city) );
	}

}
