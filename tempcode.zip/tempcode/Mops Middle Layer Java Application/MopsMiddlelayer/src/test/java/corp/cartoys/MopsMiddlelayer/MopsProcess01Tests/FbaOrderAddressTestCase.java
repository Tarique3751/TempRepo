package corp.cartoys.MopsMiddlelayer.MopsProcess01Tests;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Junit Test case that checks Address2 and Location Code details of an fba order.
 * @author jjude
 */
public class FbaOrderAddressTestCase {

	//Address details from mops
	public static String mOPSAddr2           = "test@gmail.com";
	public static String mOPSLocationCode    = "TESTLOC";
	
	//Address that should be changed if its an FBA order
	public static String fBAAddr2            = "";
	public static String fbaAmzLocationCode  = "Amazon";
	public static String fbaEbayLocationCode = "Ebay";
	
	/**
	 * Function that implements the logic that sets Address2 and location code.
	 * @param marketName - String.
	 * @return fullfillmenttype - String.
	 */
	public String[] setAddress(String marketName, String fullfillmenttype)
	{
		String address[] = {mOPSAddr2,mOPSLocationCode};
		
		if(marketName.equalsIgnoreCase("AMAZON") && fullfillmenttype.equalsIgnoreCase("FBA"))
		{
			address[0] = fBAAddr2;
			address[1] = fbaAmzLocationCode;
		}
		else if(marketName.equalsIgnoreCase("EBAY") && fullfillmenttype.equalsIgnoreCase("FBA"))
		{
			address[0] = fBAAddr2;
			address[1] = fbaEbayLocationCode;
		}
		
		return address;
	}
	
	@Test
	public void amzFbaAddressTest() {
		String marketName       = "Amazon";
		String fullfillmenttype = "FBA";
		String[] address        = null;
		int result              = 0;
		
		FbaOrderAddressTestCase fbaOrderAddressTestCaseObj = new FbaOrderAddressTestCase();
		address = fbaOrderAddressTestCaseObj.setAddress(marketName,fullfillmenttype);
		
		if(address[0].equalsIgnoreCase(fBAAddr2) && address[1].equalsIgnoreCase(fbaAmzLocationCode))
		{
			result = 1;
		}
		
		assertTrue( result == 1 );
	}
	@Test
	public void amzCtoAddressTest() {
		String marketName       = "Amazon";
		String fullfillmenttype = "Local";
		String[] address        = null;
		int result              = 0;
		
		FbaOrderAddressTestCase fbaOrderAddressTestCaseObj = new FbaOrderAddressTestCase();
		address = fbaOrderAddressTestCaseObj.setAddress(marketName,fullfillmenttype);
		
		if(address[0].equalsIgnoreCase(fBAAddr2) && address[1].equalsIgnoreCase(fbaAmzLocationCode))
		{
			result = 1;
		}
		
		assertTrue( result == 0 );
	}
	@Test
	public void ebayFbaAddressTest() {
		String marketName       = "EBAY";
		String fullfillmenttype = "FBA";
		String[] address        = null;
		int result              = 0;
		
		FbaOrderAddressTestCase fbaOrderAddressTestCaseObj = new FbaOrderAddressTestCase();
		address = fbaOrderAddressTestCaseObj.setAddress(marketName,fullfillmenttype);
		
		if(address[0].equalsIgnoreCase(fBAAddr2) && address[1].equalsIgnoreCase(fbaEbayLocationCode))
		{
			result = 1;
		}
		
		assertTrue( result == 1 );
	}
	@Test
	public void ebayCtoAddressTest() {
		String marketName       = "EBAY";
		String fullfillmenttype = "Local";
		String[] address        = null;
		int result              = 0;
		
		FbaOrderAddressTestCase fbaOrderAddressTestCaseObj = new FbaOrderAddressTestCase();
		address = fbaOrderAddressTestCaseObj.setAddress(marketName,fullfillmenttype);
		
		if(address[0].equalsIgnoreCase(fBAAddr2) && address[1].equalsIgnoreCase(fbaEbayLocationCode))
		{
			result = 1;
		}
		
		assertTrue( result == 0 );
	}
}
