package corp.cartoys.MopsMiddlelayer.MopsProcess01Tests;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Junit Test case that checks Confidential State Business Logic.
 * @author jjude
 */
public class ConfidentialStateTestCase {

	public String confidentialState = "OR";
	
	/**
	 * Function that implements the logic that sets the confidential state.
	 * @param state - String.
	 * @return state - String.
	 */
	public String SetState(String state)
	{
		if(state.equalsIgnoreCase("CONFIDENTIAL"))
		{
			state = confidentialState;
		}
		return state;
	}
	
	@Test
	public void confidentialStateTest() {
		String state  = "CONFIDENTIAL";
		String result = "";
		
		ConfidentialStateTestCase confidentialStateTestCaseObj = new ConfidentialStateTestCase();
		result = confidentialStateTestCaseObj.SetState(state);
		
		assertTrue( result.equalsIgnoreCase(confidentialState) );
	}
	
	@Test
	public void nonConfidentialCityTest() {
		String state  = "MICHIGAN";
		String result = "";
		
		ConfidentialStateTestCase confidentialStateTestCaseObj = new ConfidentialStateTestCase();
		result = confidentialStateTestCaseObj.SetState(state);
		
		assertTrue( result.equalsIgnoreCase(state) );
	}

}
