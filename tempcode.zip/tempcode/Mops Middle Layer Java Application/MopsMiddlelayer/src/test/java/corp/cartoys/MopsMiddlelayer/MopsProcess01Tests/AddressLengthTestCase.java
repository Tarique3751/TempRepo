package corp.cartoys.MopsMiddlelayer.MopsProcess01Tests;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * Junit Test case that checks the address length business rule.
 * @author jjude
 */
public class AddressLengthTestCase {

	final int MAX_ADDR_LEN_NEED_ATTENTION = 30;

	/**
	 * Function that implements the logic that checks the Address length.
	 * @param AddressLength - Int.
	 * @return status - Int.
	 */
	public int checkAddressLength(int addressLength)
	{
		if(addressLength > MAX_ADDR_LEN_NEED_ATTENTION)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	@Test
	public void belowMaxAddressLengthTest() {
		String address = "test address";
		int addrLen = address.length();
		int result = 0;
		
		AddressLengthTestCase addressLengthTestCaseObj = new AddressLengthTestCase();
		result = addressLengthTestCaseObj.checkAddressLength(addrLen);
		
		assertTrue( result == 0 );
	}
	
	@Test
	public void aboveMaxAddressLengthTest() {
		String address = "test address test address test address test address test address test address test address test address test address test address test address test address test address test address test address test address";
		int addrLen = address.length();
		int result = 0;
		
		AddressLengthTestCase addressLengthTestCaseObj = new AddressLengthTestCase();
		result = addressLengthTestCaseObj.checkAddressLength(addrLen);
		
		assertTrue( result == 1 );
	}

}
