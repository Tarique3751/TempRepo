SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dev_monsoon_gers_order`
--

CREATE DATABASE IF NOT EXISTS `dev_monsoon_gers_order` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `dev_monsoon_gers_order`;

-----------------------------------------------------------
-- TABLES
-----------------------------------------------------------

--
-- Table structure for table `directory_country_region`
--

CREATE TABLE IF NOT EXISTS `directory_country_region` (
  `region_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Region Id',
  `country_id` varchar(4) NOT NULL DEFAULT '0' COMMENT 'Country Id in ISO-2',
  `code` varchar(32) NOT NULL COMMENT 'Region code',
  `default_name` varchar(255) DEFAULT NULL COMMENT 'Region Name',
  PRIMARY KEY (`region_id`),
  KEY `IDX_DIRECTORY_COUNTRY_REGION_COUNTRY_ID` (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 COMMENT='Directory Country Region';

INSERT INTO `directory_country_region` (`region_id`, `country_id`, `code`, `default_name`) VALUES
(1, 'US', 'AL', 'Alabama'),
(2, 'US', 'AK', 'Alaska'),
(3, 'US', 'AS', 'American Samoa'),
(4, 'US', 'AZ', 'Arizona'),
(5, 'US', 'AR', 'Arkansas'),
(6, 'US', 'AF', 'Armed Forces Africa'),
(7, 'US', 'AA', 'Armed Forces Americas'),
(8, 'US', 'AC', 'Armed Forces Canada'),
(9, 'US', 'AE', 'Armed Forces Europe'),
(10, 'US', 'AM', 'Armed Forces Middle East'),
(11, 'US', 'AP', 'Armed Forces Pacific'),
(12, 'US', 'CA', 'California'),
(13, 'US', 'CO', 'Colorado'),
(14, 'US', 'CT', 'Connecticut'),
(15, 'US', 'DE', 'Delaware'),
(16, 'US', 'DC', 'District of Columbia'),
(17, 'US', 'FM', 'Federated States Of Micronesia'),
(18, 'US', 'FL', 'Florida'),
(19, 'US', 'GA', 'Georgia'),
(20, 'US', 'GU', 'Guam'),
(21, 'US', 'HI', 'Hawaii'),
(22, 'US', 'ID', 'Idaho'),
(23, 'US', 'IL', 'Illinois'),
(24, 'US', 'IN', 'Indiana'),
(25, 'US', 'IA', 'Iowa'),
(26, 'US', 'KS', 'Kansas'),
(27, 'US', 'KY', 'Kentucky'),
(28, 'US', 'LA', 'Louisiana'),
(29, 'US', 'ME', 'Maine'),
(30, 'US', 'MH', 'Marshall Islands'),
(31, 'US', 'MD', 'Maryland'),
(32, 'US', 'MA', 'Massachusetts'),
(33, 'US', 'MI', 'Michigan'),
(34, 'US', 'MN', 'Minnesota'),
(35, 'US', 'MS', 'Mississippi'),
(36, 'US', 'MO', 'Missouri'),
(37, 'US', 'MT', 'Montana'),
(38, 'US', 'NE', 'Nebraska'),
(39, 'US', 'NV', 'Nevada'),
(40, 'US', 'NH', 'New Hampshire'),
(41, 'US', 'NJ', 'New Jersey'),
(42, 'US', 'NM', 'New Mexico'),
(43, 'US', 'NY', 'New York'),
(44, 'US', 'NC', 'North Carolina'),
(45, 'US', 'ND', 'North Dakota'),
(46, 'US', 'MP', 'Northern Mariana Islands'),
(47, 'US', 'OH', 'Ohio'),
(48, 'US', 'OK', 'Oklahoma'),
(49, 'US', 'OR', 'Oregon'),
(50, 'US', 'PW', 'Palau'),
(51, 'US', 'PA', 'Pennsylvania'),
(52, 'US', 'PR', 'Puerto Rico'),
(53, 'US', 'RI', 'Rhode Island'),
(54, 'US', 'SC', 'South Carolina'),
(55, 'US', 'SD', 'South Dakota'),
(56, 'US', 'TN', 'Tennessee'),
(57, 'US', 'TX', 'Texas'),
(58, 'US', 'UT', 'Utah'),
(59, 'US', 'VT', 'Vermont'),
(60, 'US', 'VI', 'Virgin Islands'),
(61, 'US', 'VA', 'Virginia'),
(62, 'US', 'WA', 'Washington'),
(63, 'US', 'WV', 'West Virginia'),
(64, 'US', 'WI', 'Wisconsin'),
(65, 'US', 'WY', 'Wyoming');

--
-- Table structure for table `file_header`
--

CREATE TABLE IF NOT EXISTS `file_header` (
  `FileId` int(10) NOT NULL AUTO_INCREMENT,
  `FileName` varchar(255) DEFAULT NULL,
  `CreatedBy` varchar(15) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `UpdatedBy` varchar(15) DEFAULT NULL,
  `UpdatedDate` datetime DEFAULT NULL,
  `Active` int(5) DEFAULT NULL,
  PRIMARY KEY (`FileId`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

--
-- Table structure for table `gers_amz_mapping`
--

CREATE TABLE IF NOT EXISTS `gers_amz_mapping` (
  `MapId` int(10) NOT NULL AUTO_INCREMENT,
  `ProductId` varchar(30) DEFAULT NULL,
  `GersSku` varchar(30) DEFAULT NULL,
  `FileId` int(10) DEFAULT NULL,
  `CreatedBy` varchar(15) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `UpdatedBy` varchar(15) DEFAULT NULL,
  `UpdatedDate` datetime DEFAULT NULL,
  `Active` int(5) DEFAULT NULL,
  PRIMARY KEY (`MapId`)
) ENGINE=InnoDB AUTO_INCREMENT=2515 DEFAULT CHARSET=utf8;

--
-- Table structure for table `gers_inv_all_item_list`
--

CREATE TABLE IF NOT EXISTS `gers_inv_all_item_list` (
  `gers_inv_id` int(11) NOT NULL AUTO_INCREMENT,
  `gers_inv_mnsn_op` varchar(10) NOT NULL,
  `gers_inv_item_code` varchar(50) NOT NULL,
  `gers_inv_qty` decimal(18,0) NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`gers_inv_id`),
  UNIQUE KEY `gers_inv_item_code` (`gers_inv_item_code`)
) ENGINE=InnoDB AUTO_INCREMENT=1871 DEFAULT CHARSET=utf8;

--
-- Table structure for table `gers_inv_history`
--

CREATE TABLE IF NOT EXISTS `gers_inv_history` (
  `gers_inv_history_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `gers_inv_history_description` varchar(100) DEFAULT '0',
  `gers_inv_history_created_date` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`gers_inv_history_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5483 DEFAULT CHARSET=utf8;

--
-- Table structure for table `gers_inv_temp`
--

CREATE TABLE IF NOT EXISTS `gers_inv_temp` (
  `MonsoonOP` varchar(10) DEFAULT NULL,
  `SKU` varchar(50) DEFAULT NULL,
  `Qty` decimal(18,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `gers_weblink_status`
--

CREATE TABLE IF NOT EXISTS `gers_weblink_status` (
  `weblink_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` int(11) NOT NULL,
  `gers_invoice` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sku` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `ord_srt_cd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `del_doc_ln` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cust_cd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `error_cd` mediumtext COLLATE utf8_unicode_ci,
  `error_msg` mediumtext COLLATE utf8_unicode_ci,
  `err_table` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stat` mediumtext COLLATE utf8_unicode_ci,
  `file_name` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `weblink_process_status` tinyint(4) DEFAULT '0',
  `creation_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `file_id` int(10) DEFAULT NULL,
  `UpdateMops` int(5) DEFAULT '0',
  PRIMARY KEY (`weblink_id`),
  KEY `gers_invoice` (`gers_invoice`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Table structure for table `gers_xml`
--

CREATE TABLE IF NOT EXISTS `gers_xml` (
  `GersXmlId` int(10) NOT NULL AUTO_INCREMENT,
  `TrnId` int(10) DEFAULT NULL,
  `OriginCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CauseCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EmpCdOp` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EmpCdKeyer` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FinCustCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipToStCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipToZoneCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TaxCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OrdTpCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OrdSrtCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SoStoreCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PuDelStoreCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SoEmpSlspCd1` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SoWrDt` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipToTitle` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipToFname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipToLname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipToAddr1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipToAddr2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipToZipCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipToHphone` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipToBphone` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipToExt` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipToCity` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipToCorp` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PctOfSale1` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PuDel` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PuDelDt` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DelChg` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SetupChg` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `TaxChg` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OrigDelDocNum` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `OrigFiAmt` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ApprovalCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `RequestedFiAmount` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AltDocNum` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AltCustCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`GersXmlId`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Table structure for table `gers_xml_cust`
--

CREATE TABLE IF NOT EXISTS `gers_xml_cust` (
  `CustId` int(10) NOT NULL AUTO_INCREMENT,
  `GersXmlId` int(10) DEFAULT NULL,
  `CustCd` int(10) DEFAULT NULL,
  `SrtCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Title` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Fname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Init` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Lname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Addr1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Addr2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `City` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `StCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ZipCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HomePhone` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BusPhone` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Ext` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CorpName` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CustTpCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AltCustCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EmailAddr` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EmailAddrShipTo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`CustId`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Table structure for table `gers_xml_solns`
--

CREATE TABLE IF NOT EXISTS `gers_xml_solns` (
  `SoLnsId` int(10) NOT NULL AUTO_INCREMENT,
  `GersXmlId` int(10) NOT NULL,
  `MonsoonOrderId` int(10) NOT NULL,
  `ItemCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `StoreCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `LocCd` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SerNum` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `UnitPrc` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Qty` int(10) DEFAULT NULL,
  `SoLnCmnt` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ActivationDt` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ActivationPhone` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ShipGroup` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`SoLnsId`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Table structure for table `mnsn_file_header`
--

CREATE TABLE IF NOT EXISTS `mnsn_file_header` (
  `FileId` int(10) NOT NULL AUTO_INCREMENT,
  `FileName` varchar(255) DEFAULT NULL,
  `CreatedBy` varchar(15) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` varchar(15) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  `CreatedFrom` varchar(15) DEFAULT NULL,
  `active` int(5) DEFAULT NULL,
  PRIMARY KEY (`FileId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Table structure for table `mnsn_inv_ignore_list`
--

CREATE TABLE IF NOT EXISTS `mnsn_inv_ignore_list` (
  `ignore_list_id` int(10) NOT NULL AUTO_INCREMENT,
  `sku` varchar(150) NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ignore_list_id`)
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8;

--
-- Table structure for table `mnsn_order_details`
--

CREATE TABLE IF NOT EXISTS `mnsn_order_details` (
  `MonsoonOrderDtId` int(10) NOT NULL AUTO_INCREMENT,
  `MonsoonOrderHdId` int(10) DEFAULT NULL,
  `MonsoonOrderId` int(10) DEFAULT NULL,
  `SKU` varchar(20) DEFAULT NULL,
  `ASIN` varchar(30) DEFAULT NULL,
  `UPC` varchar(30) DEFAULT NULL,
  `Conditions` varchar(10) DEFAULT NULL,
  `SkuOnMarket` varchar(30) DEFAULT NULL,
  `LocatorCode` varchar(10) DEFAULT NULL,
  `OrderedQuantity` int(5) DEFAULT NULL,
  `ShippedQuantity` int(5) DEFAULT NULL,
  `Price` varchar(10) DEFAULT NULL,
  `ShippingFee` varchar(10) DEFAULT NULL,
  `MarketPrice` varchar(10) DEFAULT NULL,
  `MarketShippingFee` varchar(10) DEFAULT NULL,
  `RefundAmount` varchar(10) DEFAULT NULL,
  `MarketRefundAmount` varchar(10) DEFAULT NULL,
  `Tax` varchar(10) DEFAULT NULL,
  `ShippingTax` varchar(10) DEFAULT NULL,
  `MarketOrderItemId` varchar(30) DEFAULT NULL,
  `FulfillmentType` varchar(15) DEFAULT NULL,
  `ManufacturerPartNum` varchar(100) DEFAULT NULL,
  `ShippingSurcharge` varchar(10) DEFAULT NULL,
  `PromotionalShippingDiscount` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`MonsoonOrderDtId`),
  KEY `MonsoonOrderHdId` (`MonsoonOrderHdId`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8;

--
-- Table structure for table `mnsn_order_for_weblink`
--

CREATE TABLE IF NOT EXISTS `mnsn_order_for_weblink` (
  `MonsoonOrderId` int(10) DEFAULT NULL,
  `OrderStatus` varchar(30) DEFAULT NULL,
  `MarketName` varchar(50) DEFAULT NULL,
  `MarketOrderId` varchar(30) DEFAULT NULL,
  `ShipMethod` varchar(30) DEFAULT NULL,
  `OrderDate` varchar(30) DEFAULT NULL,
  `ShipDate` varchar(30) DEFAULT NULL,
  `OrderNote` varchar(50) DEFAULT NULL,
  `TrackingNumber` varchar(50) DEFAULT NULL,
  `CarrierCode` varchar(10) DEFAULT NULL,
  `BuyerEmail` varchar(50) DEFAULT NULL,
  `BuyerName` varchar(30) DEFAULT NULL,
  `ShipToName` varchar(30) DEFAULT NULL,
  `Address1` varchar(255) DEFAULT NULL,
  `Address2` varchar(255) DEFAULT NULL,
  `City` varchar(30) DEFAULT NULL,
  `State` varchar(30) DEFAULT NULL,
  `PostalCode` varchar(15) DEFAULT NULL,
  `Country` varchar(30) DEFAULT NULL,
  `BuyerPhoneNumber` varchar(15) DEFAULT NULL,
  `SKU` varchar(20) DEFAULT NULL,
  `ASIN` varchar(30) DEFAULT NULL,
  `UPC` varchar(30) DEFAULT NULL,
  `Conditions` varchar(10) DEFAULT NULL,
  `SkuOnMarket` varchar(30) DEFAULT NULL,
  `LocatorCode` varchar(10) DEFAULT NULL,
  `OrderedQuantity` int(5) DEFAULT NULL,
  `ShippedQuantity` int(5) DEFAULT NULL,
  `Price` varchar(10) DEFAULT NULL,
  `ShippingFee` varchar(10) DEFAULT NULL,
  `MarketPrice` varchar(10) DEFAULT NULL,
  `MarketShippingFee` varchar(10) DEFAULT NULL,
  `RefundAmount` varchar(10) DEFAULT NULL,
  `MarketRefundAmount` varchar(10) DEFAULT NULL,
  `Tax` varchar(10) DEFAULT NULL,
  `ShippingTax` varchar(10) DEFAULT NULL,
  `MarketOrderItemId` varchar(30) DEFAULT NULL,
  `FulfillmentType` varchar(15) DEFAULT NULL,
  `ManufacturerPartNum` varchar(100) DEFAULT NULL,
  `ShippingSurcharge` varchar(10) DEFAULT NULL,
  `PromotionalShippingDiscount` varchar(20) DEFAULT NULL,
  `RowNumber` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `mnsn_order_header`
--

CREATE TABLE IF NOT EXISTS `mnsn_order_header` (
  `MonsoonOrderHdId` int(10) NOT NULL AUTO_INCREMENT,
  `MonsoonOrderId` int(10) DEFAULT NULL,
  `OrderStatus` varchar(30) DEFAULT NULL,
  `MarketName` varchar(50) DEFAULT NULL,
  `MarketOrderId` varchar(30) DEFAULT NULL,
  `ShipMethod` varchar(30) DEFAULT NULL,
  `OrderDate` varchar(30) DEFAULT NULL,
  `ShipDate` varchar(30) DEFAULT NULL,
  `OrderNote` varchar(50) DEFAULT NULL,
  `TrackingNumber` varchar(50) DEFAULT NULL,
  `CarrierCode` varchar(10) DEFAULT NULL,
  `BuyerEmail` varchar(50) DEFAULT NULL,
  `BuyerName` varchar(50) DEFAULT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `ShipToName` varchar(50) DEFAULT NULL,
  `Address1` varchar(255) DEFAULT NULL,
  `Address2` varchar(255) DEFAULT NULL,
  `City` varchar(30) DEFAULT NULL,
  `State` varchar(30) DEFAULT NULL,
  `PostalCode` varchar(15) DEFAULT NULL,
  `Country` varchar(30) DEFAULT NULL,
  `BuyerPhoneNumber` varchar(15) DEFAULT NULL,
  `ImportStatus` int(11) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `Returns` varchar(255) DEFAULT NULL,
  `AutomaticImportStatus` int(11) DEFAULT NULL,
  `LocationCode` varchar(50) DEFAULT NULL,
  `AutomaticImportErrorDetails` tinytext,
  `Company` varchar(20) DEFAULT NULL,
  `AlreadyExist` int(11) DEFAULT '0',
  PRIMARY KEY (`MonsoonOrderHdId`),
  UNIQUE KEY `MonsoonOrderId` (`MonsoonOrderId`)
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8;

--
-- Table structure for table `mnsn_order_notes`
--

CREATE TABLE IF NOT EXISTS `mnsn_order_notes` (
  `NotesId` int(10) NOT NULL AUTO_INCREMENT,
  `Notes` text,
  `OrderId` int(10) DEFAULT NULL,
  `CreatedBy` varchar(15) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` varchar(15) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  `CreatedFrom` varchar(15) DEFAULT NULL,
  `active` int(5) DEFAULT NULL,
  PRIMARY KEY (`NotesId`)
) ENGINE=InnoDB AUTO_INCREMENT=1613 DEFAULT CHARSET=utf8;

--
-- Table structure for table `mnsn_order_status_type`
--

CREATE TABLE IF NOT EXISTS `mnsn_order_status_type` (
  `StatusId` int(10) NOT NULL AUTO_INCREMENT,
  `Status` varchar(30) DEFAULT NULL,
  `Value` int(10) DEFAULT NULL,
  `Active` int(5) DEFAULT NULL,
  `CreatedBy` varchar(15) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `ForSearch` int(5) DEFAULT '0',
  PRIMARY KEY (`StatusId`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

--
-- Table structure for table `mnsn_order_tracking`
--

CREATE TABLE IF NOT EXISTS `mnsn_order_tracking` (
  `TrackingId` int(10) NOT NULL AUTO_INCREMENT,
  `GersInvoice` varchar(100) DEFAULT NULL,
  `OrderNumber` int(10) DEFAULT NULL,
  `TrackingNumber` varchar(50) DEFAULT NULL,
  `sku` varchar(50) DEFAULT NULL,
  `qty` int(5) DEFAULT NULL,
  `CreatedBy` varchar(15) DEFAULT NULL,
  `CreatedOn` datetime DEFAULT NULL,
  `UpdatedBy` varchar(15) DEFAULT NULL,
  `UpdatedOn` datetime DEFAULT NULL,
  `CreatedFrom` varchar(15) DEFAULT NULL,
  `active` int(5) DEFAULT NULL,
  `FileId` int(5) DEFAULT NULL,
  `UpdateMops` int(5) DEFAULT '0',
  `UpdateMnsn` int(5) DEFAULT NULL,
  `ManualTrackingNumber` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`TrackingId`),
  KEY `OrderNumber` (`OrderNumber`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8;

--
-- Table structure for table `temp_msn_xml`
--

CREATE TABLE IF NOT EXISTS `temp_msn_xml` (
  `tXml` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

--
-- Table structure for table `walmart_temp`
--
CREATE TABLE IF NOT EXISTS `walmart_temp` (
  `PoNumber` varchar(255) DEFAULT NULL,
  `OrderNumber` varchar(255) DEFAULT NULL,
  `ShipBy` varchar(255) DEFAULT NULL,
  `CustomerName` varchar(255) DEFAULT NULL,
  `CustomerShippingInfo` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `LineNumber` varchar(255) DEFAULT NULL,
  `UPC` varchar(255) DEFAULT NULL,
  `Status` varchar(255) DEFAULT NULL,
  `ItemDescription` varchar(255) DEFAULT NULL,
  `RequestedCarrierMethod` varchar(255) DEFAULT NULL,
  `RequestedShippingMethod` varchar(255) DEFAULT NULL,
  `Qty` varchar(255) DEFAULT NULL,
  `SKU` varchar(255) DEFAULT NULL,
  `UpdateStatus` varchar(255) DEFAULT NULL,
  `UpdateQty` varchar(255) DEFAULT NULL,
  `ActualCarrierMethodUsed` varchar(255) DEFAULT NULL,
  `UpdateShippingMethod` varchar(255) DEFAULT NULL,
  `TrackingNumber` varchar(255) DEFAULT NULL,
  `TrackingUrl` varchar(255) DEFAULT NULL,
  `Price` double DEFAULT NULL,
  `Tax` double DEFAULT NULL,
  `RowNumber` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Table structure for table `walmart_order_header`
--
CREATE TABLE IF NOT EXISTS `walmart_order_header` (
  `WalmartOrderHdId` int(11) NOT NULL AUTO_INCREMENT,
  `PoNumber` varchar(50) DEFAULT NULL,
  `OrderNumber` varchar(50) DEFAULT NULL,
  `ShipBy` varchar(50) DEFAULT NULL,
  `CustomerName` varchar(50) DEFAULT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `CustomerShippingInfo` varchar(255) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `ImportStatus` int(11) DEFAULT NULL,
  `AutomaticImportStatus` int(11) DEFAULT NULL,
  `AutomaticImportErrorDetails` varchar(50) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `UpdatedDate` datetime DEFAULT NULL,
  `CreatedBy` varchar(50) DEFAULT NULL,
  `UpdatedBy` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`WalmartOrderHdId`),
  UNIQUE KEY `OrderNumber` (`OrderNumber`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Table structure for table `walmart_order_details`
--
CREATE TABLE IF NOT EXISTS `walmart_order_details` (
  `WalmartOrderDtId` int(11) NOT NULL AUTO_INCREMENT,
  `WalmartOrderHdId` int(11) DEFAULT NULL,
  `OrderNumber` varchar(50) DEFAULT NULL,
  `LineNumber` int(11) DEFAULT NULL,
  `UPC` varchar(50) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  `ItemDescription` varchar(250) DEFAULT NULL,
  `RequestedCarrierMethod` varchar(250) DEFAULT NULL,
  `RequestedShippingMethod` varchar(250) DEFAULT NULL,
  `Qty` int(11) DEFAULT NULL,
  `SKU` varchar(50) DEFAULT NULL,
  `UpdateStatus` varchar(50) DEFAULT NULL,
  `UpdateQty` varchar(50) DEFAULT NULL,
  `ActualCarrierMethodUsed` varchar(50) DEFAULT NULL,
  `UpdateShippingMethod` varchar(50) DEFAULT NULL,
  `TrackingNumber` varchar(50) DEFAULT NULL,
  `TrackingUrl` varchar(50) DEFAULT NULL,
  `Price` varchar(50) DEFAULT NULL,
  `Tax` varchar(50) DEFAULT NULL,
  `CreatedDate` datetime DEFAULT NULL,
  `UpdatedDate` datetime DEFAULT NULL,
  `CreatedBy` varchar(50) DEFAULT NULL,
  `UpdatedBy` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`WalmartOrderDtId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-----------------------------------------------------------
-- Procedures
-----------------------------------------------------------

DELIMITER $$
/*
* Stored procedure to insert inventory data and inventory history into database.
* author : sprakash
*/
CREATE DEFINER=`root`@`localhost` PROCEDURE `gers_inv_qty_insert_update` ()  BEGIN

DECLARE EXIT HANDLER FOR SQLEXCEPTION ROLLBACK;
SET autocommit=0;
START TRANSACTION;

    DELETE il FROM gers_inv_all_item_list il INNER JOIN mnsn_inv_ignore_list iil ON il.gers_inv_item_code = iil.sku;
    DELETE t FROM gers_inv_temp t INNER JOIN mnsn_inv_ignore_list iil ON t.SKU = iil.sku;
    
    UPDATE gers_inv_all_item_list SET gers_inv_qty = 0;
    
     SELECT IFNULL(COUNT(*),0) 
	   INTO @TOTAL_CNT
      FROM gers_inv_all_item_list a1;
      
      

    INSERT INTO gers_inv_all_item_list(gers_inv_mnsn_op,gers_inv_item_code,gers_inv_qty,created_date)
     SELECT  t.MonsoonOP,t.SKU,t.Qty,UTC_TIMESTAMP()
     FROM gers_inv_temp t
     ON DUPLICATE KEY UPDATE gers_inv_mnsn_op = t.MonsoonOP,
	                gers_inv_qty = t.Qty,
						 created_date = UTC_TIMESTAMP();
						 
SELECT IFNULL(COUNT(*),0) 
	   INTO @TOTAL_AFT_CNT
      FROM gers_inv_all_item_list a1;
		
	  SELECT IFNULL(COUNT(*),0) 
	   INTO @TOT_CNT
      FROM gers_inv_temp;					 
						 
	  	SET @NEW_CNT = IFNULL(@TOTAL_AFT_CNT,0) - 	IFNULL(@TOTAL_CNT,0);
	  	SET @NEW_CNT = IF(@NEW_CNT < 0,0,@NEW_CNT);
	  	SET @UP_CNT = IFNULL(@TOT_CNT,0) - 	IFNULL(@NEW_CNT,0);
		  			 
     INSERT INTO gers_inv_history (gers_inv_history_description,gers_inv_history_created_date) 
      VALUES(concat('Total items received from gers = ',@TOT_CNT,'. Updated items count = ',@UP_CNT,'.',if(@NEW_CNT <=0 ,'', concat(' New items count = ',@NEW_CNT))),UTC_TIMESTAMP());
COMMIT;
END$$

/*
* Stored procedure to update status fields of orders.
* author : sprakash
*/
CREATE DEFINER=`root`@`localhost` PROCEDURE `mnsn_order_tracking_update_mops_sp` ()  BEGIN
	UPDATE mnsn_order_header as h INNER JOIN mnsn_order_tracking as t ON h.MonsoonOrderId = t.OrderNumber
	SET h.ImportStatus = 2,t.UpdateMops = 1 WHERE t.UpdateMops = 0;
END$$

/*
* Stored procedure to split header and details from temporary table.
* author : sprakash
*/
CREATE DEFINER=`root`@`localhost` PROCEDURE `order_data_normalization_test` ()  BEGIN

CREATE TEMPORARY TABLE IF NOT EXISTS tempOrder_r( 
	MnsnRowNumber VARCHAR(100)			            
	) engine=memory;

	TRUNCATE TABLE tempOrder_r;
    SET SQL_SAFE_UPDATES = 0;	
	UPDATE mnsn_order_for_weblink w SET w.RowNumber = UUID();     
	
	SET @num := 0, @group_id := '';
	INSERT INTO tempOrder_r(MnsnRowNumber)
	SELECT RowNumber FROM (
	SELECT w.RowNumber, @num := if(@group_id = concat(w.MonsoonOrderId,w.SKU), @num + 1, 1) as row_number,
	@group_id := concat(w.MonsoonOrderId,w.SKU) as dummy 
	FROM mnsn_order_for_weblink w
	order by w.MonsoonOrderId,w.SKU
	) AS T
	WHERE T.row_number < 2; 
	
	
	
	DELETE wl FROM  mnsn_order_for_weblink wl 
	WHERE wl.RowNumber collate utf8_unicode_ci NOT IN (SELECT MnsnRowNumber FROM tempOrder_r);

		       
	INSERT INTO mnsn_order_header(MonsoonOrderId,OrderStatus,MarketName,MarketOrderId,ShipMethod,OrderDate,
		ShipDate,OrderNote,TrackingNumber,CarrierCode,BuyerEmail,BuyerName,ShipToName,
		Address1,Address2,City,State,PostalCode,Country,BuyerPhoneNumber,CreatedDate,FirstName,LastName,LocationCode,ImportStatus,AutomaticImportStatus,AlreadyExist)  
	SELECT wl.MonsoonOrderId,wl.OrderStatus,wl.MarketName,wl.MarketOrderId,wl.ShipMethod,wl.OrderDate,
		wl.ShipDate,wl.OrderNote,wl.TrackingNumber,wl.CarrierCode,wl.BuyerEmail,
		wl.BuyerName,wl.ShipToName,wl.Address1,wl.Address2,wl.City,wl.State,wl.PostalCode,'US',
		wl.BuyerPhoneNumber,UTC_TIMESTAMP(),wl.ShipToName,wl.ShipToName, '',0,
		1,0
		FROM mnsn_order_for_weblink wl LEFT JOIN directory_country_region cr ON wl.State = cr.default_name
		ON DUPLICATE KEY UPDATE 
			MonsoonOrderId       =    wl.MonsoonOrderId,
			OrderStatus          =    wl.OrderStatus,
			MarketName           =    wl.MarketName,
			MarketOrderId        =    wl.MarketOrderId,
			ShipMethod           =    wl.ShipMethod,
			OrderDate            =    wl.OrderDate,
			ShipDate             =    wl.ShipDate,
			OrderNote            =    wl.OrderNote,
			TrackingNumber       =    wl.TrackingNumber,
			CarrierCode          =    wl.CarrierCode,
			BuyerEmail           =    wl.BuyerEmail,
			BuyerName            =    wl.BuyerName,
			ShipToName           =    wl.ShipToName,
			Address1             =    wl.Address1,
			Address2             =    wl.Address2,
			City                 =    wl.City,
			State                =    wl.State,
			PostalCode           =    wl.PostalCode,
			Country              =    'US',
			BuyerPhoneNumber     =    wl.BuyerPhoneNumber,
						CreatedDate          =    UTC_TIMESTAMP(),
			FirstName            =    wl.ShipToName,
			LastName             =    wl.ShipToName,
			LocationCode         =    '',
			AutomaticImportStatus=    1,
			AlreadyExist			  =    1;	  
	

	DELETE od FROM  mnsn_order_details od INNER JOIN mnsn_order_for_weblink wl ON od.MonsoonOrderId = wl.MonsoonOrderId;         
	        
	INSERT INTO mnsn_order_details(MonsoonOrderHdId,MonsoonOrderId,SKU,ASIN,UPC,Conditions,
		SkuOnMarket,LocatorCode,OrderedQuantity,ShippedQuantity,Price,ShippingFee,MarketPrice,
		MarketShippingFee,RefundAmount,MarketRefundAmount,Tax,ShippingTax,MarketOrderItemId,FulfillmentType,
		ManufacturerPartNum,ShippingSurcharge,PromotionalShippingDiscount)  
		SELECT oh.MonsoonOrderHdId,wl.MonsoonOrderId,wl.SKU,wl.ASIN,wl.UPC,wl.Conditions,
		wl.SkuOnMarket,wl.LocatorCode,wl.OrderedQuantity,wl.ShippedQuantity,wl.Price,'' AS ShippingFee,wl.MarketPrice,wl.MarketShippingFee,
		wl.RefundAmount,wl.MarketRefundAmount,wl.Tax,wl.ShippingTax,wl.MarketOrderItemId,wl.FulfillmentType,wl.ManufacturerPartNum,wl.ShippingSurcharge,
		0 AS PromotionalShippingDiscount
		FROM mnsn_order_for_weblink wl INNER JOIN mnsn_order_header oh ON wl.MonsoonOrderId = oh.MonsoonOrderId;
	
	
	DELETE FROM mnsn_order_for_weblink;
    SET SQL_SAFE_UPDATES = 1;
	DROP TEMPORARY TABLE IF EXISTS tempOrder_r;
	SET SQL_SAFE_UPDATES = 0;
END$$

/*
* Stored procedure to update the status fields for fba orders.
* author : jjude
*/
CREATE DEFINER=`root`@`localhost` PROCEDURE `weblink_status_insert_update_mops_fba_sp` ()  BEGIN
	UPDATE mnsn_order_header as h JOIN gers_weblink_status as w ON h.MonsoonOrderId = w.order_number
	SET h.ImportStatus = 2,w.UpdateMops = 1 WHERE (w.error_cd IS NULL OR w.error_cd='') AND w.UpdateMops = '0' 
	AND h.OrderStatus = 'Shipped';
END$$

/*
* Stored procedure to update the status fields for cto orders.
* author : jjude
*/
CREATE DEFINER=`root`@`localhost` PROCEDURE `weblink_status_insert_update_mops_sp` ()  BEGIN
	UPDATE mnsn_order_header as h INNER JOIN gers_weblink_status as w ON h.MonsoonOrderId = w.order_number
	SET h.ImportStatus = 1,w.UpdateMops = 1 WHERE (w.error_cd IS NULL OR w.error_cd='') AND w.UpdateMops = '0' 
	AND h.OrderStatus != 'Shipped';
END$$

/*
* Stored procedure to get the order import details.
* author : jjude
*/
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_order_import_data` ()  BEGIN
	SELECT DISTINCT h.MonsoonOrderId,d.MarketOrderItemId,d.SKU,IF(t.ManualTrackingNumber IS NOT NULL,t.ManualTrackingNumber,t.TrackingNumber) AS TrackingNumber
	FROM mnsn_order_header AS h INNER JOIN mnsn_order_details AS d 
	ON  h.MonsoonOrderHdId  =  d.MonsoonOrderHdId 
	INNER JOIN gers_weblink_status AS gws ON gws.order_number = h.MonsoonOrderId 
	INNER JOIN mnsn_order_tracking t ON t.GersInvoice  = gws.gers_invoice COLLATE utf8_general_ci 
	WHERE t.UpdateMnsn = 0;
END$$

/*
* Stored procedure to split walmart header and details from walmart temporary table.
* author : sprakash
*/
DELIMITER //
CREATE DEFINER=`root`@`localhost` PROCEDURE `usp_order_data_normalization_for_walmart`()
BEGIN

--   Author      : Shijo K Prakash
--   Create date : 2016-June-08 12:01:44
--   Description : normalizing order data for walmart
  
    CREATE TEMPORARY TABLE IF NOT EXISTS tempOrder( 
          WalmartRowNumber VARCHAR(100)			            
    ) engine=memory;
    
	 TRUNCATE TABLE tempOrder;
	 UPDATE walmart_temp w SET w.RowNumber = UUID();     
          
  	 SET @num := 0, @group_id := '';
	 INSERT INTO tempOrder(WalmartRowNumber)
    SELECT RowNumber FROM (
    SELECT w.RowNumber, @num := if(@group_id = concat(w.OrderNumber,w.SKU), @num + 1, 1) as row_number,
      @group_id := concat(w.OrderNumber,w.SKU) as dummy 
		FROM walmart_temp w
      order by w.OrderNumber,w.SKU
    ) AS T
    WHERE T.row_number < 2; 
	     	   
    DELETE wl FROM  walmart_temp wl 
	 WHERE wl.RowNumber collate utf8_unicode_ci NOT IN (SELECT WalmartRowNumber FROM tempOrder);
	 
	 SELECT * FROM tempOrder;         

  	INSERT INTO walmart_order_header(PoNumber,OrderNumber,ShipBy,CustomerName,CustomerShippingInfo,Email,ImportStatus,
	        AutomaticImportStatus,AutomaticImportErrorDetails,CreatedDate,UpdatedDate,CreatedBy,UpdatedBy)  
     SELECT wl.PoNumber,wl.OrderNumber,DATE_FORMAT(wl.ShipBy,"%m/%d/%Y %k:%i:%s"),wl.CustomerName,wl.CustomerShippingInfo,wl.Email,0,
           1,'',UTC_TIMESTAMP(),UTC_TIMESTAMP(),'',''
           FROM walmart_temp wl
			  ON DUPLICATE KEY UPDATE 
			     PoNumber       			=    wl.PoNumber,
	           OrderNumber          	=    wl.OrderNumber,
	           ShipBy           		=    DATE_FORMAT(wl.ShipBy,"%m/%d/%Y %k:%i:%s"),
	           CustomerName       	=    wl.CustomerName,
	           CustomerShippingInfo	=    wl.CustomerShippingInfo,
	           Email						=	  wl.Email,
	           AutomaticImportStatus	=    1,
	           UpdatedDate          	=    UTC_TIMESTAMP();
			  
				  
	 DELETE od FROM  walmart_order_details od INNER JOIN walmart_temp wl ON od.OrderNumber = wl.OrderNumber;         
	                    
	 INSERT INTO walmart_order_details(WalmartOrderHdId,OrderNumber,LineNumber,UPC,Status,ItemDescription,RequestedCarrierMethod,
	        RequestedShippingMethod,Qty,SKU,UpdateStatus,UpdateQty,ActualCarrierMethodUsed,UpdateShippingMethod,
	        TrackingNumber,TrackingUrl,Price,Tax,CreatedDate,UpdatedDate,CreatedBy,UpdatedBy)  
    SELECT oh.WalmartOrderHdId,wl.OrderNumber,wl.LineNumber,wl.UPC,wl.Status,wl.ItemDescription,
           wl.RequestedCarrierMethod,wl.RequestedShippingMethod,wl.Qty,wl.SKU,wl.UpdateStatus,wl.UpdateQty,wl.ActualCarrierMethodUsed,wl.UpdateShippingMethod,
           wl.TrackingNumber,wl.TrackingUrl,wl.Price,wl.Tax,UTC_TIMESTAMP(),UTC_TIMESTAMP(),'',''
           FROM walmart_temp wl INNER JOIN walmart_order_header oh ON wl.OrderNumber = oh.OrderNumber;
   
	  DELETE FROM walmart_temp; 	
	  DROP TEMPORARY TABLE IF EXISTS tempOrder;
END//
DELIMITER ;