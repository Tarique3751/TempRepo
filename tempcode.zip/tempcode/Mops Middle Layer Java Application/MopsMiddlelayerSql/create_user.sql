-- Script to create a new user

CREATE USER '<user-name>'@'localhost' IDENTIFIED BY '<password>';
GRANT ALL PRIVILEGES ON dev_csvtoxmlconversion_fuseproj.* TO '<user-name>'@'localhost' WITH GRANT OPTION;
FLUSH PRIVILEGES;